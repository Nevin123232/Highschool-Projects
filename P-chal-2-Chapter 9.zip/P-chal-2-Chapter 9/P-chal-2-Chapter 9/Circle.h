#pragma once
//This Header File contains the Circle class declaration
#ifndef CIRCLE_H
#define CIRCLE_H
#include <cmath>


class Circle{


private: //radius and coordinates of the circle
	double radius;
	int centerX, centerY;
	
public: // default constructor with no parameters or default values
	Circle() {
		radius = 1.0;
		centerX = centerY = 0;

	}

	Circle(double r) { //constructor 2 that accepts radius
		radius = r;
		centerX = centerY = 0;

	}

	Circle(double r, int x, int y) { //constructor 3 that accepts radius and position
		radius = r;
		centerX = x;
		centerY = y;

	}

	void setRadius(double r) {

		radius = r;
	}


	int getXpos() {
		return centerX;
	}

	int getYpos() {

		return centerY;
	}

	double getRadius() {

		return radius;
	}

	double findArea() {

		return 3.14 * pow(radius, 2);
	}
}; //End Circle Class Declaration


#endif