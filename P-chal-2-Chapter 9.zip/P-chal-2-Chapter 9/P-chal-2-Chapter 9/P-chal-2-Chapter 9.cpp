// P-chal-2-Chapter 9.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <iomanip>
#include "Circle.h"



using namespace std;
// Programming challenge 11 page 657

const int NUM_CIRCLES = 7;

int main()
{
	Circle circle[NUM_CIRCLES]; //makes an array of circle objects 

	//Set circles with the following radii

	circle[0].setRadius(2.5);
	circle[1].setRadius(4.0);
	circle[2].setRadius(1.0);
	circle[3].setRadius(3.0);
	circle[4].setRadius(6.0);
	circle[5].setRadius(5.5);
	circle[6].setRadius(2.0);
	

	cout << "Radius and Area of Circles before sorting:\n\n";
	//output radius before sorting
	for (int u = 0; u < 7; u++) {
		cout << "\nCircle " << u + 1 << " Radius: " << circle[u].getRadius() << " Area: " << circle[u].findArea();


	}




	//Use bubble sort to sort values
	Circle temp;
	
	for (int o = 0; o < 7; o++) {

		for (int h = o + 1; h < 7; h++) {


			//swap values 
			if (circle[h].getRadius() < circle[o].getRadius()) {


				temp = circle[o];
				circle[o] = circle[h];
				circle[h] = temp;

			}

		}

	}





	cout << "\n\n\nRadius and Area of Circles after sorting:\n\n";
	//output radius and area after sorting
	for (int u = 0; u < 7; u++) {
		cout << "\nCircle " << u + 1 << " Radius: " << circle[u].getRadius() << " Area: " << circle[u].findArea();


	}

	system("pause");
	//Origonal Program Code
  /*
  
  //Initialize the radius of each object based on user input
  
  for(int index = 0; index < NUM_CIRCLES; index++){
  double r;
  cout << "Enter the radius for circle " << (index + 1)<< ":" << endl;

  cin >> r;

  circle[index].setRadius(r)

  }
  
  
  */
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
