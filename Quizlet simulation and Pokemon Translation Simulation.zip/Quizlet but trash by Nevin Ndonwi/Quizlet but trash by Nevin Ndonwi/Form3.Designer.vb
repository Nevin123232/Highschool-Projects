﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmquizlet
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmquizlet))
        Me.btnintro = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblanswer3 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.txtquestion = New System.Windows.Forms.TextBox()
        Me.btneraseallcards = New System.Windows.Forms.Button()
        Me.lblquestion3 = New System.Windows.Forms.Label()
        Me.lblquestion2 = New System.Windows.Forms.Label()
        Me.lblquestion4 = New System.Windows.Forms.Label()
        Me.lblanswer2 = New System.Windows.Forms.Label()
        Me.lblanswer4 = New System.Windows.Forms.Label()
        Me.lblanswer5 = New System.Windows.Forms.Label()
        Me.lblquestion5 = New System.Windows.Forms.Label()
        Me.lblanswer1 = New System.Windows.Forms.Label()
        Me.lblquestion1 = New System.Windows.Forms.Label()
        Me.txtanswer = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnclearquestion = New System.Windows.Forms.Button()
        Me.btnclearanswer = New System.Windows.Forms.Button()
        Me.btnclear1 = New System.Windows.Forms.Button()
        Me.btncard5 = New System.Windows.Forms.Button()
        Me.btncard4 = New System.Windows.Forms.Button()
        Me.btncard3 = New System.Windows.Forms.Button()
        Me.brncard2 = New System.Windows.Forms.Button()
        Me.btncard1 = New System.Windows.Forms.Button()
        Me.btnclear2 = New System.Windows.Forms.Button()
        Me.btnclear3 = New System.Windows.Forms.Button()
        Me.btnclear4 = New System.Windows.Forms.Button()
        Me.btnclear5 = New System.Windows.Forms.Button()
        Me.btnstudy = New System.Windows.Forms.Button()
        Me.btncreate = New System.Windows.Forms.Button()
        Me.lblstudyquestion1 = New System.Windows.Forms.Label()
        Me.lblstudyquestion2 = New System.Windows.Forms.Label()
        Me.lblstudyquestion3 = New System.Windows.Forms.Label()
        Me.lblstudyquestion4 = New System.Windows.Forms.Label()
        Me.lblstudyquestion5 = New System.Windows.Forms.Label()
        Me.lblstudyanswer1 = New System.Windows.Forms.Label()
        Me.lblstudyanswer3 = New System.Windows.Forms.Label()
        Me.lblstudyanswer2 = New System.Windows.Forms.Label()
        Me.lblstudyanswer4 = New System.Windows.Forms.Label()
        Me.lblstudyanswer5 = New System.Windows.Forms.Label()
        Me.btnflip1 = New System.Windows.Forms.Button()
        Me.btnflip5 = New System.Windows.Forms.Button()
        Me.btnflip4 = New System.Windows.Forms.Button()
        Me.btnflip3 = New System.Windows.Forms.Button()
        Me.btncardflip2 = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnintro
        '
        Me.btnintro.Location = New System.Drawing.Point(34, 468)
        Me.btnintro.Name = "btnintro"
        Me.btnintro.Size = New System.Drawing.Size(114, 32)
        Me.btnintro.TabIndex = 0
        Me.btnintro.Text = "Back to in&tro "
        Me.btnintro.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(436, 169)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Welcome to our quizlet-like service. You can make up to 5 flash cards,the right s" &
    "ide shows the cards that you have made so far."
        Me.Label1.UseWaitCursor = True
        '
        'lblanswer3
        '
        Me.lblanswer3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblanswer3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblanswer3.Location = New System.Drawing.Point(682, 302)
        Me.lblanswer3.Name = "lblanswer3"
        Me.lblanswer3.Size = New System.Drawing.Size(150, 80)
        Me.lblanswer3.TabIndex = 2
        Me.lblanswer3.Text = "Answer 3"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(431, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(153, 115)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 3
        Me.PictureBox1.TabStop = False
        '
        'txtquestion
        '
        Me.txtquestion.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.txtquestion.Location = New System.Drawing.Point(22, 199)
        Me.txtquestion.Multiline = True
        Me.txtquestion.Name = "txtquestion"
        Me.txtquestion.Size = New System.Drawing.Size(100, 100)
        Me.txtquestion.TabIndex = 5
        '
        'btneraseallcards
        '
        Me.btneraseallcards.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.btneraseallcards.Location = New System.Drawing.Point(590, 56)
        Me.btneraseallcards.Name = "btneraseallcards"
        Me.btneraseallcards.Size = New System.Drawing.Size(152, 59)
        Me.btneraseallcards.TabIndex = 7
        Me.btneraseallcards.Text = "Er&ase all cards"
        Me.btneraseallcards.UseVisualStyleBackColor = True
        '
        'lblquestion3
        '
        Me.lblquestion3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblquestion3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblquestion3.Location = New System.Drawing.Point(530, 307)
        Me.lblquestion3.Name = "lblquestion3"
        Me.lblquestion3.Size = New System.Drawing.Size(152, 80)
        Me.lblquestion3.TabIndex = 10
        Me.lblquestion3.Text = "Question 3 "
        '
        'lblquestion2
        '
        Me.lblquestion2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblquestion2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblquestion2.Location = New System.Drawing.Point(530, 211)
        Me.lblquestion2.Name = "lblquestion2"
        Me.lblquestion2.Size = New System.Drawing.Size(146, 88)
        Me.lblquestion2.TabIndex = 11
        Me.lblquestion2.Text = "Question 2"
        '
        'lblquestion4
        '
        Me.lblquestion4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblquestion4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblquestion4.Location = New System.Drawing.Point(530, 387)
        Me.lblquestion4.Name = "lblquestion4"
        Me.lblquestion4.Size = New System.Drawing.Size(152, 75)
        Me.lblquestion4.TabIndex = 12
        Me.lblquestion4.Text = "Question 4 "
        '
        'lblanswer2
        '
        Me.lblanswer2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblanswer2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblanswer2.Location = New System.Drawing.Point(682, 211)
        Me.lblanswer2.Name = "lblanswer2"
        Me.lblanswer2.Size = New System.Drawing.Size(145, 88)
        Me.lblanswer2.TabIndex = 13
        Me.lblanswer2.Text = "Answer 2"
        '
        'lblanswer4
        '
        Me.lblanswer4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblanswer4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblanswer4.Location = New System.Drawing.Point(686, 387)
        Me.lblanswer4.Name = "lblanswer4"
        Me.lblanswer4.Size = New System.Drawing.Size(141, 75)
        Me.lblanswer4.TabIndex = 14
        Me.lblanswer4.Text = "Answer 4 "
        '
        'lblanswer5
        '
        Me.lblanswer5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblanswer5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblanswer5.Location = New System.Drawing.Point(686, 462)
        Me.lblanswer5.Name = "lblanswer5"
        Me.lblanswer5.Size = New System.Drawing.Size(141, 67)
        Me.lblanswer5.TabIndex = 15
        Me.lblanswer5.Text = "Answer 5 "
        '
        'lblquestion5
        '
        Me.lblquestion5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblquestion5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblquestion5.Location = New System.Drawing.Point(530, 468)
        Me.lblquestion5.Name = "lblquestion5"
        Me.lblquestion5.Size = New System.Drawing.Size(152, 61)
        Me.lblquestion5.TabIndex = 16
        Me.lblquestion5.Text = "Question 5 "
        '
        'lblanswer1
        '
        Me.lblanswer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblanswer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblanswer1.Location = New System.Drawing.Point(682, 128)
        Me.lblanswer1.Name = "lblanswer1"
        Me.lblanswer1.Size = New System.Drawing.Size(145, 83)
        Me.lblanswer1.TabIndex = 17
        Me.lblanswer1.Text = "Answer 1"
        '
        'lblquestion1
        '
        Me.lblquestion1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblquestion1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblquestion1.Location = New System.Drawing.Point(530, 128)
        Me.lblquestion1.Name = "lblquestion1"
        Me.lblquestion1.Size = New System.Drawing.Size(146, 83)
        Me.lblquestion1.TabIndex = 18
        Me.lblquestion1.Text = "Question 1 "
        '
        'txtanswer
        '
        Me.txtanswer.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.txtanswer.Location = New System.Drawing.Point(200, 199)
        Me.txtanswer.Multiline = True
        Me.txtanswer.Name = "txtanswer"
        Me.txtanswer.Size = New System.Drawing.Size(100, 100)
        Me.txtanswer.TabIndex = 19
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(6, 183)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(142, 16)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "Input your question:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(179, 179)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(132, 16)
        Me.Label3.TabIndex = 21
        Me.Label3.Text = "Input your answer:"
        '
        'btnclearquestion
        '
        Me.btnclearquestion.Location = New System.Drawing.Point(34, 303)
        Me.btnclearquestion.Name = "btnclearquestion"
        Me.btnclearquestion.Size = New System.Drawing.Size(94, 25)
        Me.btnclearquestion.TabIndex = 22
        Me.btnclearquestion.Text = "Clear &Question"
        Me.btnclearquestion.UseVisualStyleBackColor = True
        '
        'btnclearanswer
        '
        Me.btnclearanswer.Location = New System.Drawing.Point(210, 302)
        Me.btnclearanswer.Name = "btnclearanswer"
        Me.btnclearanswer.Size = New System.Drawing.Size(101, 26)
        Me.btnclearanswer.TabIndex = 23
        Me.btnclearanswer.Text = "Clear &answer"
        Me.btnclearanswer.UseVisualStyleBackColor = True
        '
        'btnclear1
        '
        Me.btnclear1.Location = New System.Drawing.Point(449, 172)
        Me.btnclear1.Name = "btnclear1"
        Me.btnclear1.Size = New System.Drawing.Size(75, 23)
        Me.btnclear1.TabIndex = 25
        Me.btnclear1.Text = "c&lear card 1"
        Me.btnclear1.UseVisualStyleBackColor = True
        '
        'btncard5
        '
        Me.btncard5.Location = New System.Drawing.Point(431, 466)
        Me.btncard5.Name = "btncard5"
        Me.btncard5.Size = New System.Drawing.Size(99, 31)
        Me.btncard5.TabIndex = 26
        Me.btncard5.Text = "Formulate card &5"
        Me.btncard5.UseVisualStyleBackColor = True
        '
        'btncard4
        '
        Me.btncard4.Location = New System.Drawing.Point(431, 387)
        Me.btncard4.Name = "btncard4"
        Me.btncard4.Size = New System.Drawing.Size(96, 33)
        Me.btncard4.TabIndex = 27
        Me.btncard4.Text = "Formulate card &4"
        Me.btncard4.UseVisualStyleBackColor = True
        '
        'btncard3
        '
        Me.btncard3.Location = New System.Drawing.Point(431, 302)
        Me.btncard3.Name = "btncard3"
        Me.btncard3.Size = New System.Drawing.Size(96, 36)
        Me.btncard3.TabIndex = 28
        Me.btncard3.Text = "Formulate card &3"
        Me.btncard3.UseVisualStyleBackColor = True
        '
        'brncard2
        '
        Me.brncard2.Location = New System.Drawing.Point(431, 211)
        Me.brncard2.Name = "brncard2"
        Me.brncard2.Size = New System.Drawing.Size(96, 45)
        Me.brncard2.TabIndex = 29
        Me.brncard2.Text = "Formulate card &2"
        Me.brncard2.UseVisualStyleBackColor = True
        '
        'btncard1
        '
        Me.btncard1.Location = New System.Drawing.Point(431, 128)
        Me.btncard1.Name = "btncard1"
        Me.btncard1.Size = New System.Drawing.Size(93, 41)
        Me.btncard1.TabIndex = 30
        Me.btncard1.Text = "Formulate card &1"
        Me.btncard1.UseVisualStyleBackColor = True
        '
        'btnclear2
        '
        Me.btnclear2.Location = New System.Drawing.Point(452, 262)
        Me.btnclear2.Name = "btnclear2"
        Me.btnclear2.Size = New System.Drawing.Size(75, 23)
        Me.btnclear2.TabIndex = 31
        Me.btnclear2.Text = "cle&ar card 2"
        Me.btnclear2.UseVisualStyleBackColor = True
        '
        'btnclear3
        '
        Me.btnclear3.Location = New System.Drawing.Point(452, 344)
        Me.btnclear3.Name = "btnclear3"
        Me.btnclear3.Size = New System.Drawing.Size(75, 23)
        Me.btnclear3.TabIndex = 32
        Me.btnclear3.Text = "clea&r card 3"
        Me.btnclear3.UseVisualStyleBackColor = True
        '
        'btnclear4
        '
        Me.btnclear4.Location = New System.Drawing.Point(452, 423)
        Me.btnclear4.Name = "btnclear4"
        Me.btnclear4.Size = New System.Drawing.Size(75, 23)
        Me.btnclear4.TabIndex = 33
        Me.btnclear4.Text = "clear card 4"
        Me.btnclear4.UseVisualStyleBackColor = True
        '
        'btnclear5
        '
        Me.btnclear5.Location = New System.Drawing.Point(431, 503)
        Me.btnclear5.Name = "btnclear5"
        Me.btnclear5.Size = New System.Drawing.Size(99, 26)
        Me.btnclear5.TabIndex = 34
        Me.btnclear5.Text = "clear card 5 (fi&ve)"
        Me.btnclear5.UseVisualStyleBackColor = True
        '
        'btnstudy
        '
        Me.btnstudy.Location = New System.Drawing.Point(182, 468)
        Me.btnstudy.Name = "btnstudy"
        Me.btnstudy.Size = New System.Drawing.Size(115, 32)
        Me.btnstudy.TabIndex = 35
        Me.btnstudy.Text = "Study with the &cards"
        Me.btnstudy.UseVisualStyleBackColor = True
        '
        'btncreate
        '
        Me.btncreate.Location = New System.Drawing.Point(307, 468)
        Me.btncreate.Name = "btncreate"
        Me.btncreate.Size = New System.Drawing.Size(102, 58)
        Me.btncreate.TabIndex = 36
        Me.btncreate.Text = "Create more cards "
        Me.btncreate.UseVisualStyleBackColor = True
        Me.btncreate.Visible = False
        '
        'lblstudyquestion1
        '
        Me.lblstudyquestion1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblstudyquestion1.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!)
        Me.lblstudyquestion1.Location = New System.Drawing.Point(2, 0)
        Me.lblstudyquestion1.Name = "lblstudyquestion1"
        Me.lblstudyquestion1.Size = New System.Drawing.Size(146, 302)
        Me.lblstudyquestion1.TabIndex = 37
        Me.lblstudyquestion1.Visible = False
        '
        'lblstudyquestion2
        '
        Me.lblstudyquestion2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblstudyquestion2.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!)
        Me.lblstudyquestion2.Location = New System.Drawing.Point(163, 0)
        Me.lblstudyquestion2.Name = "lblstudyquestion2"
        Me.lblstudyquestion2.Size = New System.Drawing.Size(167, 299)
        Me.lblstudyquestion2.TabIndex = 38
        Me.lblstudyquestion2.Visible = False
        '
        'lblstudyquestion3
        '
        Me.lblstudyquestion3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblstudyquestion3.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!)
        Me.lblstudyquestion3.Location = New System.Drawing.Point(336, -5)
        Me.lblstudyquestion3.Name = "lblstudyquestion3"
        Me.lblstudyquestion3.Size = New System.Drawing.Size(163, 307)
        Me.lblstudyquestion3.TabIndex = 39
        Me.lblstudyquestion3.Visible = False
        '
        'lblstudyquestion4
        '
        Me.lblstudyquestion4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblstudyquestion4.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!)
        Me.lblstudyquestion4.Location = New System.Drawing.Point(506, -5)
        Me.lblstudyquestion4.Name = "lblstudyquestion4"
        Me.lblstudyquestion4.Size = New System.Drawing.Size(160, 307)
        Me.lblstudyquestion4.TabIndex = 40
        Me.lblstudyquestion4.Visible = False
        '
        'lblstudyquestion5
        '
        Me.lblstudyquestion5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblstudyquestion5.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!)
        Me.lblstudyquestion5.Location = New System.Drawing.Point(672, -1)
        Me.lblstudyquestion5.Name = "lblstudyquestion5"
        Me.lblstudyquestion5.Size = New System.Drawing.Size(160, 303)
        Me.lblstudyquestion5.TabIndex = 41
        Me.lblstudyquestion5.Visible = False
        '
        'lblstudyanswer1
        '
        Me.lblstudyanswer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblstudyanswer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!)
        Me.lblstudyanswer1.Location = New System.Drawing.Point(-1, 0)
        Me.lblstudyanswer1.Name = "lblstudyanswer1"
        Me.lblstudyanswer1.Size = New System.Drawing.Size(149, 302)
        Me.lblstudyanswer1.TabIndex = 42
        Me.lblstudyanswer1.Visible = False
        '
        'lblstudyanswer3
        '
        Me.lblstudyanswer3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblstudyanswer3.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!)
        Me.lblstudyanswer3.Location = New System.Drawing.Point(335, 5)
        Me.lblstudyanswer3.Name = "lblstudyanswer3"
        Me.lblstudyanswer3.Size = New System.Drawing.Size(164, 302)
        Me.lblstudyanswer3.TabIndex = 43
        Me.lblstudyanswer3.Visible = False
        '
        'lblstudyanswer2
        '
        Me.lblstudyanswer2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblstudyanswer2.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!)
        Me.lblstudyanswer2.Location = New System.Drawing.Point(163, -6)
        Me.lblstudyanswer2.Name = "lblstudyanswer2"
        Me.lblstudyanswer2.Size = New System.Drawing.Size(167, 304)
        Me.lblstudyanswer2.TabIndex = 44
        Me.lblstudyanswer2.Visible = False
        '
        'lblstudyanswer4
        '
        Me.lblstudyanswer4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblstudyanswer4.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!)
        Me.lblstudyanswer4.Location = New System.Drawing.Point(508, 0)
        Me.lblstudyanswer4.Name = "lblstudyanswer4"
        Me.lblstudyanswer4.Size = New System.Drawing.Size(158, 302)
        Me.lblstudyanswer4.TabIndex = 45
        Me.lblstudyanswer4.Visible = False
        '
        'lblstudyanswer5
        '
        Me.lblstudyanswer5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblstudyanswer5.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!)
        Me.lblstudyanswer5.Location = New System.Drawing.Point(672, -5)
        Me.lblstudyanswer5.Name = "lblstudyanswer5"
        Me.lblstudyanswer5.Size = New System.Drawing.Size(160, 312)
        Me.lblstudyanswer5.TabIndex = 46
        Me.lblstudyanswer5.Visible = False
        '
        'btnflip1
        '
        Me.btnflip1.Location = New System.Drawing.Point(18, 344)
        Me.btnflip1.Name = "btnflip1"
        Me.btnflip1.Size = New System.Drawing.Size(75, 23)
        Me.btnflip1.TabIndex = 47
        Me.btnflip1.Text = "&Flip card 1 "
        Me.btnflip1.UseVisualStyleBackColor = True
        Me.btnflip1.Visible = False
        '
        'btnflip5
        '
        Me.btnflip5.Location = New System.Drawing.Point(713, 344)
        Me.btnflip5.Name = "btnflip5"
        Me.btnflip5.Size = New System.Drawing.Size(75, 23)
        Me.btnflip5.TabIndex = 48
        Me.btnflip5.Text = "Flip &card 5 "
        Me.btnflip5.UseVisualStyleBackColor = True
        Me.btnflip5.Visible = False
        '
        'btnflip4
        '
        Me.btnflip4.Location = New System.Drawing.Point(542, 344)
        Me.btnflip4.Name = "btnflip4"
        Me.btnflip4.Size = New System.Drawing.Size(75, 23)
        Me.btnflip4.TabIndex = 49
        Me.btnflip4.Text = "Fli&p card 4"
        Me.btnflip4.UseVisualStyleBackColor = True
        Me.btnflip4.Visible = False
        '
        'btnflip3
        '
        Me.btnflip3.Location = New System.Drawing.Point(371, 344)
        Me.btnflip3.Name = "btnflip3"
        Me.btnflip3.Size = New System.Drawing.Size(75, 23)
        Me.btnflip3.TabIndex = 50
        Me.btnflip3.Text = "Flip car&d 3"
        Me.btnflip3.UseVisualStyleBackColor = True
        Me.btnflip3.Visible = False
        '
        'btncardflip2
        '
        Me.btncardflip2.Location = New System.Drawing.Point(200, 344)
        Me.btncardflip2.Name = "btncardflip2"
        Me.btncardflip2.Size = New System.Drawing.Size(75, 23)
        Me.btncardflip2.TabIndex = 51
        Me.btncardflip2.Text = "F&lip card 2"
        Me.btncardflip2.UseVisualStyleBackColor = True
        Me.btncardflip2.Visible = False
        '
        'frmquizlet
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(839, 532)
        Me.Controls.Add(Me.btncardflip2)
        Me.Controls.Add(Me.btnflip3)
        Me.Controls.Add(Me.btnflip4)
        Me.Controls.Add(Me.btnflip5)
        Me.Controls.Add(Me.btnflip1)
        Me.Controls.Add(Me.lblstudyanswer5)
        Me.Controls.Add(Me.lblstudyanswer4)
        Me.Controls.Add(Me.lblstudyanswer2)
        Me.Controls.Add(Me.lblstudyanswer3)
        Me.Controls.Add(Me.lblstudyanswer1)
        Me.Controls.Add(Me.lblstudyquestion5)
        Me.Controls.Add(Me.lblstudyquestion4)
        Me.Controls.Add(Me.lblstudyquestion3)
        Me.Controls.Add(Me.lblstudyquestion2)
        Me.Controls.Add(Me.lblstudyquestion1)
        Me.Controls.Add(Me.btncreate)
        Me.Controls.Add(Me.btnstudy)
        Me.Controls.Add(Me.btnclear5)
        Me.Controls.Add(Me.btnclear4)
        Me.Controls.Add(Me.btnclear3)
        Me.Controls.Add(Me.btnclear2)
        Me.Controls.Add(Me.btncard1)
        Me.Controls.Add(Me.brncard2)
        Me.Controls.Add(Me.btncard3)
        Me.Controls.Add(Me.btncard4)
        Me.Controls.Add(Me.btncard5)
        Me.Controls.Add(Me.btnclear1)
        Me.Controls.Add(Me.btnclearanswer)
        Me.Controls.Add(Me.btnclearquestion)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtanswer)
        Me.Controls.Add(Me.lblquestion1)
        Me.Controls.Add(Me.lblanswer1)
        Me.Controls.Add(Me.lblquestion5)
        Me.Controls.Add(Me.lblanswer5)
        Me.Controls.Add(Me.lblanswer4)
        Me.Controls.Add(Me.lblanswer2)
        Me.Controls.Add(Me.lblquestion4)
        Me.Controls.Add(Me.lblquestion2)
        Me.Controls.Add(Me.lblquestion3)
        Me.Controls.Add(Me.btneraseallcards)
        Me.Controls.Add(Me.txtquestion)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lblanswer3)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnintro)
        Me.Name = "frmquizlet"
        Me.Text = "Trash Quizlet by Nevin Ndonwi"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnintro As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents lblanswer3 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents txtquestion As TextBox
    Friend WithEvents btneraseallcards As Button
    Friend WithEvents lblquestion3 As Label
    Friend WithEvents lblquestion2 As Label
    Friend WithEvents lblquestion4 As Label
    Friend WithEvents lblanswer2 As Label
    Friend WithEvents lblanswer4 As Label
    Friend WithEvents lblanswer5 As Label
    Friend WithEvents lblquestion5 As Label
    Friend WithEvents lblanswer1 As Label
    Friend WithEvents lblquestion1 As Label
    Friend WithEvents txtanswer As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents btnclearquestion As Button
    Friend WithEvents btnclearanswer As Button
    Friend WithEvents btnclear1 As Button
    Friend WithEvents btncard5 As Button
    Friend WithEvents btncard4 As Button
    Friend WithEvents btncard3 As Button
    Friend WithEvents brncard2 As Button
    Friend WithEvents btncard1 As Button
    Friend WithEvents btnclear2 As Button
    Friend WithEvents btnclear3 As Button
    Friend WithEvents btnclear4 As Button
    Friend WithEvents btnclear5 As Button
    Friend WithEvents btnstudy As Button
    Friend WithEvents btncreate As Button
    Friend WithEvents lblstudyquestion1 As Label
    Friend WithEvents lblstudyquestion2 As Label
    Friend WithEvents lblstudyquestion3 As Label
    Friend WithEvents lblstudyquestion4 As Label
    Friend WithEvents lblstudyquestion5 As Label
    Friend WithEvents lblstudyanswer1 As Label
    Friend WithEvents lblstudyanswer3 As Label
    Friend WithEvents lblstudyanswer2 As Label
    Friend WithEvents lblstudyanswer4 As Label
    Friend WithEvents lblstudyanswer5 As Label
    Friend WithEvents btnflip1 As Button
    Friend WithEvents btnflip5 As Button
    Friend WithEvents btnflip4 As Button
    Friend WithEvents btnflip3 As Button
    Friend WithEvents btncardflip2 As Button
End Class
