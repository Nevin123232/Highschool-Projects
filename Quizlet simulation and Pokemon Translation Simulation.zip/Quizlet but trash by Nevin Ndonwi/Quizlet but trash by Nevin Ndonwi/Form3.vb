﻿Public Class frmquizlet


    Private Sub btnintro_Click(sender As Object, e As EventArgs) Handles btnintro.Click
        Me.Close()
    End Sub

    Private Sub btnclearquestion_Click(sender As Object, e As EventArgs) Handles btnclearquestion.Click
        txtquestion.Clear()
    End Sub

    Private Sub btnclearanswer_Click(sender As Object, e As EventArgs) Handles btnclearanswer.Click
        txtanswer.Clear()
    End Sub



    Private Sub btneraseallcards_Click(sender As Object, e As EventArgs) Handles btneraseallcards.Click
        lblquestion1.Text = String.Empty
        lblquestion2.Text = String.Empty
        lblquestion3.Text = String.Empty
        lblquestion4.Text = String.Empty
        lblquestion5.Text = String.Empty

        lblanswer1.Text = String.Empty
        lblanswer2.Text = String.Empty
        lblanswer3.Text = String.Empty
        lblanswer4.Text = String.Empty
        lblanswer5.Text = String.Empty

    End Sub

    Private Sub btncard1_Click(sender As Object, e As EventArgs) Handles btncard1.Click
        lblquestion1.Text = txtquestion.Text
        lblanswer1.Text = txtanswer.Text
    End Sub

    Private Sub brncard2_Click(sender As Object, e As EventArgs) Handles brncard2.Click
        lblquestion2.Text = txtquestion.Text
        lblanswer2.Text = txtanswer.Text
    End Sub

    Private Sub btncard3_Click(sender As Object, e As EventArgs) Handles btncard3.Click
        lblquestion3.Text = txtquestion.Text
        lblanswer3.Text = txtanswer.Text
    End Sub

    Private Sub btncard4_Click(sender As Object, e As EventArgs) Handles btncard4.Click
        lblquestion4.Text = txtquestion.Text
        lblanswer4.Text = txtanswer.Text
    End Sub

    Private Sub btncard5_Click(sender As Object, e As EventArgs) Handles btncard5.Click
        lblquestion5.Text = txtquestion.Text
        lblanswer5.Text = txtanswer.Text
    End Sub

    Private Sub btnclear1_Click(sender As Object, e As EventArgs) Handles btnclear1.Click
        lblquestion1.Text = String.Empty
        lblanswer1.Text = String.Empty
    End Sub

    Private Sub btnclear2_Click(sender As Object, e As EventArgs) Handles btnclear2.Click
        lblquestion2.Text = String.Empty
        lblanswer2.Text = String.Empty
    End Sub

    Private Sub btnclear3_Click(sender As Object, e As EventArgs) Handles btnclear3.Click
        lblquestion3.Text = String.Empty
        lblanswer3.Text = String.Empty
    End Sub

    Private Sub btnclear4_Click(sender As Object, e As EventArgs) Handles btnclear4.Click
        lblquestion4.Text = String.Empty
        lblanswer4.Text = String.Empty
    End Sub

    Private Sub btnclear5_Click(sender As Object, e As EventArgs) Handles btnclear5.Click
        lblquestion5.Text = String.Empty
        lblanswer5.Text = String.Empty
    End Sub

    Private Sub btnstudy_Click(sender As Object, e As EventArgs) Handles btnstudy.Click
        lblanswer1.Visible = False
        lblanswer2.Visible = False
        lblanswer3.Visible = False
        lblanswer4.Visible = False
        lblanswer5.Visible = False
        lblquestion1.Visible = False
        lblquestion2.Visible = False
        lblquestion3.Visible = False
        lblquestion4.Visible = False
        lblquestion5.Visible = False
        btncard1.Visible = False
        brncard2.Visible = False
        btncard3.Visible = False
        btncard4.Visible = False
        btncard5.Visible = False
        btnclear1.Visible = False
        btnclear2.Visible = False
        btnclear3.Visible = False
        btnclear4.Visible = False
        btnclear5.Visible = False

        btnclearanswer.Visible = False
        btnclearquestion.Visible = False
        btneraseallcards.Visible = False
        btnintro.Visible = False
        btnstudy.Visible = False
        PictureBox1.Visible = False
        Label1.Visible = False
        Label2.Visible = False
        Label3.Visible = False
        txtanswer.Visible = False
        txtquestion.Visible = False
        btncreate.Visible = True

        lblstudyquestion1.Visible = True
        lblstudyquestion2.Visible = True
        lblstudyquestion3.Visible = True
        lblstudyquestion4.Visible = True
        lblstudyquestion5.Visible = True

        lblstudyanswer1.Visible = False
        lblstudyanswer2.Visible = False
        lblstudyanswer3.Visible = False
        lblstudyanswer4.Visible = False
        lblstudyanswer5.Visible = False

        btnflip4.Visible = True
        btnflip5.Visible = True
        btncardflip2.Visible = True
        btnflip1.Visible = True
        btnflip3.Visible = True


        lblstudyquestion1.Text = lblquestion1.Text
        lblstudyquestion2.Text = lblquestion2.Text
        lblstudyquestion3.Text = lblquestion3.Text
        lblstudyquestion4.Text = lblquestion4.Text
        lblstudyquestion5.Text = lblquestion5.Text


        lblstudyanswer2.Text = lblanswer2.Text
        lblstudyanswer1.Text = lblanswer1.Text
        lblstudyanswer3.Text = lblanswer3.Text
        lblstudyanswer4.Text = lblanswer4.Text
        lblstudyanswer5.Text = lblanswer5.Text


    End Sub

    Private Sub btncreate_Click(sender As Object, e As EventArgs) Handles btncreate.Click



        lblanswer1.Visible = True
        lblanswer2.Visible = True
        lblanswer3.Visible = True
        lblanswer4.Visible = True
        lblanswer5.Visible = True
        lblquestion1.Visible = True
        lblquestion2.Visible = True
        lblquestion3.Visible = True
        lblquestion4.Visible = True
        lblquestion5.Visible = True
        btncard1.Visible = True
        brncard2.Visible = True
        btncard3.Visible = True
        btncard4.Visible = True
        btncard5.Visible = True
        btnclear1.Visible = True
        btnclear2.Visible = True
        btnclear3.Visible = True
        btnclear4.Visible = True
        btnclear5.Visible = True

        btnclearanswer.Visible = True
        btnclearquestion.Visible = True
        btneraseallcards.Visible = True
        btnintro.Visible = True
        btnstudy.Visible = True
        PictureBox1.Visible = True
        Label1.Visible = True
        Label2.Visible = True
        Label3.Visible = True
        txtanswer.Visible = True
        txtquestion.Visible = True
        btncreate.Visible = False

        lblstudyquestion1.Visible = False
        lblstudyquestion2.Visible = False
        lblstudyquestion3.Visible = False
        lblstudyquestion4.Visible = False
        lblstudyquestion5.Visible = False

        lblstudyanswer1.Visible = False
        lblstudyanswer2.Visible = False
        lblstudyanswer3.Visible = False
        lblstudyanswer4.Visible = False
        lblstudyanswer5.Visible = False

        btncard1.Visible = True
        btncard3.Visible = True
        btncard4.Visible = True
        btncard5.Visible = True
        btncardflip2.Visible = False

        btnflip1.Visible = False
        btnflip3.Visible = False
        btnflip4.Visible = False
        btnflip5.Visible = False




    End Sub

    Private Sub btnflip1_Click(sender As Object, e As EventArgs) Handles btnflip1.Click
        If lblstudyquestion1.Visible = True Then
            lblstudyquestion1.Visible = False
            lblstudyanswer1.Visible = True
        ElseIf lblstudyanswer1.Visible = True Then
            lblstudyquestion1.Visible = True
            lblstudyanswer1.Visible = False
        End If

    End Sub

    Private Sub btncardflip2_Click(sender As Object, e As EventArgs) Handles btncardflip2.Click
        If lblstudyquestion2.Visible = True Then
            lblstudyquestion2.Visible = False
            lblstudyanswer2.Visible = True
        ElseIf lblstudyanswer2.Visible = True Then
            lblstudyquestion2.Visible = True
            lblstudyanswer2.Visible = False
        End If
    End Sub

    Private Sub btnflip3_Click(sender As Object, e As EventArgs) Handles btnflip3.Click
        If lblstudyquestion3.Visible = True Then
            lblstudyquestion3.Visible = False
            lblstudyanswer3.Visible = True
        ElseIf lblstudyanswer3.Visible = True Then
            lblstudyquestion3.Visible = True
            lblstudyanswer3.Visible = False
        End If



    End Sub

    Private Sub btnflip4_Click(sender As Object, e As EventArgs) Handles btnflip4.Click
        If lblstudyquestion4.Visible = True Then
            lblstudyquestion4.Visible = False
            lblstudyanswer4.Visible = True
        ElseIf lblstudyanswer4.Visible = True Then
            lblstudyquestion4.Visible = True
            lblstudyanswer4.Visible = False
        End If
    End Sub

    Private Sub btnflip5_Click(sender As Object, e As EventArgs) Handles btnflip5.Click
        If lblstudyquestion5.Visible = True Then
            lblstudyquestion5.Visible = False
            lblstudyanswer5.Visible = True
        ElseIf lblstudyanswer5.Visible = True Then
            lblstudyquestion5.Visible = True
            lblstudyanswer5.Visible = False
        End If
    End Sub
End Class

