﻿Public Class frmintro
    Private Sub frmintro_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnexit_Click(sender As Object, e As EventArgs) Handles btnexit.Click
        Me.Close()

    End Sub

    Private Sub btnfrench_Click(sender As Object, e As EventArgs) Handles btnfrench.Click
        frmpoknames.ShowDialog()

    End Sub

    Private Sub btnquizlet_Click(sender As Object, e As EventArgs) Handles btnquizlet.Click
        frmquizlet.ShowDialog()
    End Sub
End Class
