#quiz object for TriviaQuiz


import os

class Quiz:
    def __init__(self,path):
        self.setFile(path)
        self._error =""

        #keep separate lists for questions/ answers

        self._q = []
        self._a = []
        self._qcount = 0
        self._qnumber = 0 #'next' question to be given
        self._over = False #variable storing if the quiz is complete?
       


        #read and open file represented by path


        try: 
            #opens file to read
            f = open(path,"r")
            eof = False 
            while eof == False:
                ques = f.readline() #reads line of file
                if ques != "":

                    #question read successfully/ assume an answer is present
                    self._q.append(ques)
                    self._a.append(f.readline())
                    self._qcount += 1
                else:
                    eof = True 


            f.close()

        except OSError as e:
            self._error = "Quiz file error: " + str(e)
        

        if self._error == "" and self._qcount >0:
            self._over = False
            self._qnumber = 1
        else:
            self._over = True
            self._qnumber = 0

            

    def setFile(self,path):
        self._path = path

    def getFile(self):
        return self._path

    def getErrorMsg(self):
        return self._error

    def getQCount(self):
        return self._qcount

    def getQNumber(self):
        return self._qnumber

    def getQuestion(self, ques = None):   #none is a keyword used in overloading in python(has a value if sent, or will be given the value 'none' of not sent
      
        if ques == None:

        #give them next question in line - if quiz is not over
            if self._over == True:
                response = "No more questions: # " + str(self._qcount) + " was the last one."


                #return is the response plus boolean 
                #that indicates whether or not an answer comes next
                return (response,False) #question doesn't exist, no more questions 

            else:
                response = self._q[self._qnumber - 1]
                return (response, True)
        else:
            #seem to be asking for specific question # (in ques variable) 
            try:
                qn = int(ques)#is requested value actually an integer?
            except ValueError:
                response = "Question requested was not an integer.\n"
                return (response,False)

            if qn < 1:
                return("Questions start at 1 please.\n", False)
            elif qn > self._qcount:
                response = "Requested question out of bounds: " + str(self._qcount) + " is max"
                return (response,False)
            else:
                response = self._q[qn - 1]
                self._qnumber = qn
                self._over = False 
                return(response,True)
                          


    def getAnswer(self):
        #end-of-quiz logic goes here 
        #answer method only returns string (not tuple)
        if self._over == True:
            return "Quiz already over: no answer to return."
        
        a = self._a[self._qnumber - 1] #answer to the current question
        if self._qnumber + 1 <= self._qcount:
            self._qnumber += 1
        else:
            self._over = True
        return a 


    def isOver(self):
        return self._over

