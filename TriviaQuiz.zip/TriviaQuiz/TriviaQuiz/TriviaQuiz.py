#Command Line Control File for TriviaQuiz by Nevin Ndonwi

import os #for file components 

from Quiz import Quiz

def doQuiz(q):
    print("Quiz opened: it has " + str(q.getQCount()) + " questions.")
    qinprogress = True 
    while qinprogress:
        qn = (str(input("Press <enter> for question " + str( q.getQNumber() ) 
                       + " or enter specific question #, or ('Q' for quit): ")  )).upper()

        if len(qn) > 0 and qn[0] == "Q":
            qinprogress = False
            needanswer = False
        elif qn == "":
            qtuple = q.getQuestion()
            print(qtuple[0])  #response from question (question or error)
            needanswer = qtuple[1] #boolean indicating answer needed Y/N
        else:
            #overloaded methods(python version) 
            qtuple= q.getQuestion(qn)
            print(qtuple[0])
            needanswer = qtuple[1]

        if qinprogress == True and needanswer == True:
            input("Press <enter> for the answer: ")
            print(q.getAnswer())
            if q.isOver() and qn == "":
                print("That was the last answer!")
                qinprogress = False







def getFile():
    choice = ""
    while choice.lower() != "q" and choice.lower() != "s":
        #loop runs until user says q or selects a file 
        cwd = os.getcwd() #get current working directory (as strings)
        print("Current Directory: " + cwd)
        
        choice = str(input("Action: show all <F>iles, <T>ext files,"+ 
        "<D>irectories, <C>hange directory, <S>elect file, or <Q>uit (F,T,D,C,S,Q): \n"))

        if choice.lower() == "c":
            #change directory
            dirnm = str(input("<..> for parent or new dirname: "))
            try:
                if dirnm != "":
                    os.chdir(dirnm) # does process  .. as 'move up one level'
                    print("Success")
                else:
                    print("No directory entered.")

            except Exception as e:
                print("CD error: " + str(e))

        elif choice.lower() == "f" or choice.lower() == "t" or choice.lower() == "d":
            #show files 
            for entry in os.listdir(cwd):
                #entry does not have full path info..
                
                fullpath = os.path.join(cwd,entry) #recreates full path fro directory entry
                if choice.lower() == "d" and os.path.isdir(fullpath):
                    print("D: " + entry)
                elif choice.lower() == "f" and os.path.isfile(fullpath):
                    print("F: " + entry)
                elif choice.lower() == "t" and os.path.isfile(fullpath) and entry.endswith(".txt"):
                    print("T: " + entry)


        elif choice.lower() == "q":
        #quit
            print("Thank you for utilizing this application, Have a nice day!")

        elif choice.lower() == "s":
         #select file
            filenm = str(input("Enter file name (with extension): "))
         #verify that input is a file....
            fullpath = os.path.join(cwd,filenm)

            if not os.path.isfile(fullpath):
                    print("Entered name is not a file.")
                    choice = ""
        else:
            print("I do not understand the choice.")



    if choice.lower() == "q":
        return "" #if no file is obtained
    else:
        return fullpath #if a file is obtained



def main():
    print("Main\n")


    #getfile method

    filenm = getFile() #method to navigate and select file from file system

    while filenm != "":
        q = Quiz(filenm)
        if q.getErrorMsg() != "":
            print("Quiz file error: " + q.getErrorMsg())

        else:
            doQuiz(q)
        filenm = getFile()




if __name__ == "__main__":
    main()