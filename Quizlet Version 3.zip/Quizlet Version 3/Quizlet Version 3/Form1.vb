﻿Imports System.IO
Imports System.Text


Public Class frmmain
    'Quizlet version 3  


    'Program Information

    'I am not trying to sell a quizlet idea, I do not own quizlet, I am just trying to improve my programming abilities through attempting to replicate various applications


    'due to a limit of time (With school starting soon), this is a rough schematic of the functionalities of this quizlet simulation idea
    'Quizlet version 3 is supposed to emulate the qualities of my Quizlet siumilation version 2 

    'Quizlet 3 will contain a graphical user interface unlike my quizlet version 2.


    'Quizlet version 2 will have the most features but quizlet version 3 will contain a UI


    'You will still be able to save questions and answers like in the other application

    'VbCrLf -- Visual Basic Newline character

    '<> The 'doesn't equals' sign

    'forecolor changes text color, backcolor changes the color of the label



    'Questions and answers stored in arraylist. This is useful for filing storing questions and answers and filing them
    Dim questions As ArrayList = New ArrayList()
    Dim answers As ArrayList = New ArrayList()
    Dim qafilename As String
    'Amount of cards created by the user
    Dim amountCard As Integer = 0

    'position of the current card during study mode 
    Dim cardpos As Integer = 0


    'checks if the card is flipped to the answer
    Dim flipped As Boolean = False

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub txtshown_TextChanged(sender As Object, e As EventArgs) Handles txtshown.TextChanged
        'making Confirmation label invisiible
        lblcreated.Visible = False



        'Makes the displayed text above the text input field  of shown card the same as what is inputted
        lblshown.Text = txtshown.Text
    End Sub


    Private Sub txthidden_TextChanged(sender As Object, e As EventArgs) Handles txthidden.TextChanged
        'Makes the displayed text above the text input field  of hidden card the same as what is inputted
        lblhidden.Text = txthidden.Text

        'making Confirmation label invisiible
        lblcreated.Visible = False

    End Sub




    Private Sub btnCreate_Click(sender As Object, e As EventArgs) Handles btnCreate.Click
        If txtshown.Text <> "" And txthidden.Text <> "" Then


            'add the text to an array list for flash cards
            questions.Add(txtshown.Text)
            answers.Add(txthidden.Text)


            'Increases the amount of cards created by 1
            amountCard += 1
            MsgBox("You have created a flashcard!!" + vbCrLf + "- " + amountCard.ToString + " " + "card(s) have been created so far")

            'allows the user to file questions and answers once 3 cards have been created
            If amountCard > 2 Then
                btnFile.Visible = True
                lbllimit.Visible = False
            End If

            'Confirmation label
            lblcreated.Visible = True
            lblcreated.ForeColor = Color.Green



        Else
            MsgBox("Make sure to fill out both input fields before creating a flash card!!")

        End If
    End Sub





    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Erases text in the input fields
        txtshown.Text = ""
        txthidden.Text = ""

        'making Confirmation label invisiible
        lblcreated.Visible = False

    End Sub






    Private Sub frmmain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'makes elements of study mode and card creation mode invisible 
        lblshown.Visible = False
        lblhidden.Visible = False
        lblcreated.Visible = False


        Label1.Visible = False
        Label2.Visible = False
        txtshown.Visible = False
        txthidden.Visible = False
        Label3.Visible = True
        Label4.Visible = False
        Label5.Visible = False
        btnClear.Visible = False
        btnCreate.Visible = False
        lbllimit.Visible = False
        btnFile.Visible = False

    End Sub





    Private Sub btnnotrecup_Click(sender As Object, e As EventArgs) Handles btnnotrecup.Click

        MsgBox("Time to create questions and answers to be filed" + " " + "and used for studying")


        'if the user does not have data to recuparate
        btnnotrecup.Visible = False
        lblrecup.Visible = False
        btnFiled.Visible = False



        lblshown.Visible = True
        lblhidden.Visible = True

        Label1.Visible = True
        Label2.Visible = True
        txtshown.Visible = True
        txthidden.Visible = True
        Label3.Visible = True
        Label4.Visible = True
        Label5.Visible = True
        btnExit.Visible = True
        btnClear.Visible = True
        btnCreate.Visible = True
        lbllimit.Visible = True
        lbllimit.ForeColor = Color.Red

    End Sub





    Private Sub btnFiled_Click(sender As Object, e As EventArgs) Handles btnFiled.Click

        MsgBox("Obtaining your previously filed questions and answers")



        'if the user has previous data (filed questions and answers)
        btnnotrecup.Visible = False
        btnFiled.Visible = False
        lblrecup.Visible = False


        btnback.Visible = True
        lblddd.Visible = True
        txtprevfile.Visible = True
        btnreget.Visible = True

    End Sub

    Private Sub btnFile_Click(sender As Object, e As EventArgs) Handles btnFile.Click
        'Filing questions and answers

        MsgBox("Filing Questions and answers")

        'Makes everything else on the form invisible so that the flash cards can be filed
        lblshown.Visible = False
        lblhidden.Visible = False
        lblcreated.Visible = False


        Label1.Visible = False
        Label2.Visible = False
        txtshown.Visible = False
        txthidden.Visible = False
        Label3.Visible = True

        Label4.Visible = False
        Label5.Visible = False
        btnClear.Visible = False
        btnCreate.Visible = False
        lbllimit.Visible = False
        btnFile.Visible = False


        'Filing flashcards 
        txtfilename.Visible = True
        lblfilee.Visible = True
        btnSubmit.Visible = True















        'The user needs at least 3 cards in order to go into study mode or test mode 
        btnFile.Visible = False







    End Sub

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        If txtfilename.Text = "" Then
            MsgBox("Please input a file name to save your flashcards!!")

        Else
            qafilename = txtfilename.Text + ".txt"


            'file questions and answers 
            'If the file exists then ask the user if they wish to overwrite or append the file
            'file info

            'Checks if a file exists

            If My.Computer.FileSystem.FileExists(qafilename) Then

                'Alerts user that this file contains information 
                MsgBox("This File is already storing information.")


                ' end Filing flashcards 
                txtfilename.Visible = False
                lblfilee.Visible = False
                btnSubmit.Visible = False

                'If it exists then the user can overwrite the file with new information or append it (add the new information to the file)


                radoverwrite.Visible = True
                lblask.Visible = True
                btnfilechoice.Visible = True
                radappend.Visible = True










            Else


                ' end Filing flashcards 
                txtfilename.Visible = False
                lblfilee.Visible = False
                btnSubmit.Visible = False


                'This will just create a new file with questions and answers
                MsgBox("This File does not exist, Creating a new File")

                'The storage of questions and answers is in the qastorage file, the name of the file is in the qafilename variable 
                Dim qastorage As System.IO.StreamWriter = My.Computer.FileSystem.OpenTextFileWriter(qafilename, False)


                'Writes information into file

                'position of the current answer card
                Dim ans As Integer = 0

                For Each x In questions
                    'Writes a question into a file
                    qastorage.WriteLine(x)
                    'writes an answer on the nextline (the position is maintained by ans variable)
                    qastorage.WriteLine(answers.Item(ans))
                    ans += 1
                Next



                'Closes file 
                qastorage.Close()




                'Confirmation that the questions and answers have been filed 
                MsgBox("The Flashcard information has been saved in a text file called " + qafilename)






                btnStudy.Visible = True
            End If
            'Questions will be stored on odd number lines, answers will be stored on even number lines 








        End If






    End Sub


    Private Sub btnStudy_Click(sender As Object, e As EventArgs) Handles btnStudy.Click
        btnStudy.Visible = False
        MsgBox("Entering study mode")

        ' Flashcard study mode


        lblstudycard.Visible = True
        btnNextcard.Visible = True
        btnprevcard.Visible = True
        btnFlipcard.Visible = True

        lblstudycard.Text = "Shown Side:" + vbCrLf + vbCrLf + vbCrLf + questions.Item(cardpos)








    End Sub


    Private Sub btnfilechoice_Click(sender As Object, e As EventArgs) Handles btnfilechoice.Click

        ''appends the information to the file
        If radappend.Checked Then
            MsgBox("Your flashcards will be added to the file inputted")







            'The storage of questions and answers is in the qastorage file, the name of the file is in the qafilename variable 
            Dim qastorage As System.IO.StreamWriter = My.Computer.FileSystem.OpenTextFileWriter(qafilename, True)


            'Writes information into file

            'position of the current answer card
            Dim ans As Integer = 0

            For Each x In questions
                'Writes a question into a file
                qastorage.WriteLine(x)
                'writes an answer on the nextline (the position is maintained by ans variable)
                qastorage.WriteLine(answers.Item(ans))
                ans += 1
            Next

            'Closes file 
            qastorage.Close()





            radoverwrite.Visible = False
            lblask.Visible = False
            btnfilechoice.Visible = False
            radappend.Visible = False

            'Confirmation that the questions and answers have been filed 
            MsgBox("The Flashcard information has been saved in a text file called " + qafilename + vbCrLf + "It has been added to  the previous contents")









            btnStudy.Visible = True


            'overwrites the information to the file the user inputted
        ElseIf radoverwrite.Checked Then
            MsgBox("Your flashcards will be overwritten into the file inputted")



            'The storage of questions and answers is in the qastorage file, the name of the file is in the qafilename variable 
            Dim qastorage As System.IO.StreamWriter = My.Computer.FileSystem.OpenTextFileWriter(qafilename, False)


            'Writes information into file

            'position of the current answer card
            Dim ans As Integer = 0

            For Each x In questions
                'Writes a question into a file
                qastorage.WriteLine(x)
                'writes an answer on the nextline (the position is maintained by ans variable)
                qastorage.WriteLine(answers.Item(ans))
                ans += 1
            Next


            'Closes file 
            qastorage.Close()




            'Confirmation that the questions and answers have been filed 
            MsgBox("The Flashcard information has been saved in a text file called " + qafilename + vbCrLf + "It has overwritten the previous contents")



            radoverwrite.Visible = False
            lblask.Visible = False
            btnfilechoice.Visible = False
            radappend.Visible = False





            btnStudy.Visible = True
            'If no option is inputted by the user
        ElseIf radappend.Checked <> True And radoverwrite.Checked <> True Then
            MsgBox("Only One option muct be checked in order to continue ")


            'If both radio buttons are checked 
        ElseIf radappend.Checked = True And radoverwrite.Checked = True Then
            MsgBox("Only One option muct be checked in order to continue ")
            radappend.Checked = False
            radoverwrite.Checked = False


        End If
    End Sub

    Private Sub radappend_CheckedChanged(sender As Object, e As EventArgs) Handles radappend.CheckedChanged


        If radappend.Checked Then
            radoverwrite.Checked = False
        End If
    End Sub

    Private Sub radoverwrite_CheckedChanged(sender As Object, e As EventArgs) Handles radoverwrite.CheckedChanged


        If radoverwrite.Checked Then
            radappend.Checked = False

        End If

    End Sub

    Private Sub btnreget_Click(sender As Object, e As EventArgs) Handles btnreget.Click

        Dim prevfile As String = txtprevfile.Text + ".txt"
        If txtprevfile.Text = "" Then
            MsgBox("Input the name of the previous file")
        Else
            If My.Computer.FileSystem.FileExists(prevfile) Then
                Dim fileReader As System.IO.StreamReader
                fileReader = My.Computer.FileSystem.OpenTextFileReader(prevfile)

                Dim counter As Integer = 1

                Dim v As Integer

                Do While fileReader.Peek() <> -1 'Reads all the lines of a file in visual basic (like the .hasnext in java)

                    v = counter Mod 2

                    'counter checks if the number is even. If it is then the questions is added to the questions arraylist
                    If v = 0 Then

                        answers.Add(fileReader.ReadLine())

                        'counter is odd when the line is at an answer, it will be added to the answers arraylist
                    Else

                        questions.Add(fileReader.ReadLine())
                    End If

                    counter += 1

                Loop

                MsgBox("Your previous flashcard data has been obtained")

                btnreget.Visible = False
                txtprevfile.Visible = False
                lblddd.Visible = False
                btnback.Visible = False

                btnStudy.Visible = True
            Else
                MsgBox("The inputted file does not exist")
            End If
        End If



    End Sub

    Private Sub btnNextcard_Click(sender As Object, e As EventArgs) Handles btnNextcard.Click
        If (cardpos + 1) < questions.Count Then
            ' adds 1 to cardpos to access the information in a future card
            cardpos += 1
            lblstudycard.Text = "Shown Side:" + vbCrLf + vbCrLf + vbCrLf + questions.Item(cardpos)
            flipped = False
        Else
            MsgBox("This is the last card created" + vbCrLf + "You created " + questions.Count.ToString() + " cards")
        End If
    End Sub

    Private Sub btnprevcard_Click(sender As Object, e As EventArgs) Handles btnprevcard.Click
        If (cardpos - 1) >= 0 Then

            ' subtracts 1 from cardpos to access the information in the previous card
            cardpos -= 1
            lblstudycard.Text = "Shown Side:" + vbCrLf + vbCrLf + vbCrLf + questions.Item(cardpos)
            flipped = False
        Else
            MsgBox("This is the last card created" + vbCrLf + "You created " + questions.Count.ToString() + " cards")
        End If
    End Sub

    Private Sub btnFlipcard_Click(sender As Object, e As EventArgs) Handles btnFlipcard.Click

        If flipped = False Then

            'makes the text of the label the answer instead of the question
            lblstudycard.Text = "Hidden Side:" + vbCrLf + vbCrLf + vbCrLf + answers.Item(cardpos)

            flipped = True
        Else
            'makes the text of the label the question instead of the answer
            lblstudycard.Text = "Shown Side:" + vbCrLf + vbCrLf + vbCrLf + questions.Item(cardpos)
            flipped = False
        End If

    End Sub

    Private Sub btnback_Click(sender As Object, e As EventArgs) Handles btnback.Click
        'if the user has previous data (filed questions and answers)
        btnnotrecup.Visible = True
        btnFiled.Visible = True
        lblrecup.Visible = True


        lblddd.Visible = False
        txtprevfile.Visible = False
        btnreget.Visible = False
        btnback.Visible = False
    End Sub
End Class



'VbCrLf -- Visual Basic Newline character

'<> The 'doesn't equals' sign

'forecolor changes text color, backcolor changes the color of the label