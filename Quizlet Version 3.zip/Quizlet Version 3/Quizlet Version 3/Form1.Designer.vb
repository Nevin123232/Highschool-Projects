﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmmain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblshown = New System.Windows.Forms.Label()
        Me.lblhidden = New System.Windows.Forms.Label()
        Me.txtshown = New System.Windows.Forms.TextBox()
        Me.txthidden = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnCreate = New System.Windows.Forms.Button()
        Me.btnFiled = New System.Windows.Forms.Button()
        Me.lblrecup = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblcreated = New System.Windows.Forms.Label()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnnotrecup = New System.Windows.Forms.Button()
        Me.btnStudy = New System.Windows.Forms.Button()
        Me.lbllimit = New System.Windows.Forms.Label()
        Me.btnFile = New System.Windows.Forms.Button()
        Me.lblfilee = New System.Windows.Forms.Label()
        Me.txtfilename = New System.Windows.Forms.TextBox()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.lblask = New System.Windows.Forms.Label()
        Me.radappend = New System.Windows.Forms.RadioButton()
        Me.radoverwrite = New System.Windows.Forms.RadioButton()
        Me.btnfilechoice = New System.Windows.Forms.Button()
        Me.txtprevfile = New System.Windows.Forms.TextBox()
        Me.lblddd = New System.Windows.Forms.Label()
        Me.btnreget = New System.Windows.Forms.Button()
        Me.lblstudycard = New System.Windows.Forms.Label()
        Me.btnNextcard = New System.Windows.Forms.Button()
        Me.btnprevcard = New System.Windows.Forms.Button()
        Me.btnFlipcard = New System.Windows.Forms.Button()
        Me.btnback = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(797, 485)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(96, 43)
        Me.btnExit.TabIndex = 0
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblshown
        '
        Me.lblshown.AutoSize = True
        Me.lblshown.Location = New System.Drawing.Point(105, 67)
        Me.lblshown.Name = "lblshown"
        Me.lblshown.Size = New System.Drawing.Size(122, 13)
        Me.lblshown.TabIndex = 1
        Me.lblshown.Text = "Shown Side of flashcard"
        '
        'lblhidden
        '
        Me.lblhidden.AutoSize = True
        Me.lblhidden.Location = New System.Drawing.Point(625, 67)
        Me.lblhidden.Name = "lblhidden"
        Me.lblhidden.Size = New System.Drawing.Size(123, 13)
        Me.lblhidden.TabIndex = 2
        Me.lblhidden.Text = "Hidden Side of flashcard"
        '
        'txtshown
        '
        Me.txtshown.Location = New System.Drawing.Point(108, 258)
        Me.txtshown.Name = "txtshown"
        Me.txtshown.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtshown.Size = New System.Drawing.Size(100, 20)
        Me.txtshown.TabIndex = 3
        '
        'txthidden
        '
        Me.txthidden.Location = New System.Drawing.Point(648, 258)
        Me.txthidden.Name = "txthidden"
        Me.txthidden.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txthidden.Size = New System.Drawing.Size(100, 20)
        Me.txthidden.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(613, 197)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(170, 58)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Input what should be on the hidden side of the flashcard"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(82, 197)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(167, 58)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Input what should be on the shown side of the card"
        '
        'btnCreate
        '
        Me.btnCreate.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCreate.Location = New System.Drawing.Point(233, 413)
        Me.btnCreate.Name = "btnCreate"
        Me.btnCreate.Size = New System.Drawing.Size(110, 56)
        Me.btnCreate.TabIndex = 7
        Me.btnCreate.Text = "&Create Card"
        Me.btnCreate.UseVisualStyleBackColor = True
        '
        'btnFiled
        '
        Me.btnFiled.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFiled.Location = New System.Drawing.Point(261, 285)
        Me.btnFiled.Name = "btnFiled"
        Me.btnFiled.Size = New System.Drawing.Size(169, 122)
        Me.btnFiled.TabIndex = 8
        Me.btnFiled.Text = "I &have previous saved questions and answers"
        Me.btnFiled.UseVisualStyleBackColor = True
        '
        'lblrecup
        '
        Me.lblrecup.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblrecup.Location = New System.Drawing.Point(322, 149)
        Me.lblrecup.Name = "lblrecup"
        Me.lblrecup.Size = New System.Drawing.Size(335, 73)
        Me.lblrecup.TabIndex = 9
        Me.lblrecup.Text = "If you have previous flashcards filed then press this button to recuperate that d" &
    "ata"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(778, 446)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(133, 36)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "Press this button to exit the application" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(230, 341)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(130, 73)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Once you have filled out the text input fields above press this button to create " &
    "a flashcard" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'lblcreated
        '
        Me.lblcreated.AutoSize = True
        Me.lblcreated.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcreated.Location = New System.Drawing.Point(311, 125)
        Me.lblcreated.Name = "lblcreated"
        Me.lblcreated.Size = New System.Drawing.Size(267, 24)
        Me.lblcreated.TabIndex = 12
        Me.lblcreated.Text = "You have Created a FlashCard"
        Me.lblcreated.Visible = False
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(547, 413)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(110, 56)
        Me.btnClear.TabIndex = 13
        Me.btnClear.Text = "C&lear Text Input Fields"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(537, 361)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(130, 49)
        Me.Label5.TabIndex = 14
        Me.Label5.Text = "Press this button to clear the text in the input fields" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'btnnotrecup
        '
        Me.btnnotrecup.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnnotrecup.Location = New System.Drawing.Point(503, 285)
        Me.btnnotrecup.Name = "btnnotrecup"
        Me.btnnotrecup.Size = New System.Drawing.Size(185, 122)
        Me.btnnotrecup.TabIndex = 15
        Me.btnnotrecup.Text = "I don't ha&ve previous questions and answers saved/ I would like to add more flas" &
    "hcards in a previous file" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.btnnotrecup.UseVisualStyleBackColor = True
        '
        'btnStudy
        '
        Me.btnStudy.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStudy.Location = New System.Drawing.Point(308, 126)
        Me.btnStudy.Name = "btnStudy"
        Me.btnStudy.Size = New System.Drawing.Size(299, 185)
        Me.btnStudy.TabIndex = 16
        Me.btnStudy.Text = "Activate Study &Mode" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "(You will be presented with the questions and answers in a " &
    "flashcard simulation so you can study with them )"
        Me.btnStudy.UseVisualStyleBackColor = True
        Me.btnStudy.Visible = False
        '
        'lbllimit
        '
        Me.lbllimit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbllimit.Location = New System.Drawing.Point(44, 341)
        Me.lbllimit.Name = "lbllimit"
        Me.lbllimit.Size = New System.Drawing.Size(142, 158)
        Me.lbllimit.TabIndex = 18
        Me.lbllimit.Text = "You need to have created and saved at least 3 flashcards before studying"
        '
        'btnFile
        '
        Me.btnFile.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFile.Location = New System.Drawing.Point(46, 377)
        Me.btnFile.Name = "btnFile"
        Me.btnFile.Size = New System.Drawing.Size(140, 73)
        Me.btnFile.TabIndex = 19
        Me.btnFile.Text = "File Flashcards"
        Me.btnFile.UseVisualStyleBackColor = True
        Me.btnFile.Visible = False
        '
        'lblfilee
        '
        Me.lblfilee.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfilee.Location = New System.Drawing.Point(326, 149)
        Me.lblfilee.Name = "lblfilee"
        Me.lblfilee.Size = New System.Drawing.Size(331, 106)
        Me.lblfilee.TabIndex = 20
        Me.lblfilee.Text = "Please input the name of the file where you would like to save your questions and" &
    " answers (The .txt extension will be added automatically)"
        Me.lblfilee.Visible = False
        '
        'txtfilename
        '
        Me.txtfilename.Location = New System.Drawing.Point(423, 285)
        Me.txtfilename.Name = "txtfilename"
        Me.txtfilename.Size = New System.Drawing.Size(100, 20)
        Me.txtfilename.TabIndex = 21
        Me.txtfilename.Visible = False
        '
        'btnSubmit
        '
        Me.btnSubmit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubmit.Location = New System.Drawing.Point(390, 341)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(163, 73)
        Me.btnSubmit.TabIndex = 22
        Me.btnSubmit.Text = "Submit file&name"
        Me.btnSubmit.UseVisualStyleBackColor = True
        Me.btnSubmit.Visible = False
        '
        'lblask
        '
        Me.lblask.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblask.Location = New System.Drawing.Point(362, 36)
        Me.lblask.Name = "lblask"
        Me.lblask.Size = New System.Drawing.Size(158, 35)
        Me.lblask.TabIndex = 23
        Me.lblask.Text = "Would you like to:"
        Me.lblask.Visible = False
        '
        'radappend
        '
        Me.radappend.AutoSize = True
        Me.radappend.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radappend.Location = New System.Drawing.Point(125, 126)
        Me.radappend.Name = "radappend"
        Me.radappend.Size = New System.Drawing.Size(412, 24)
        Me.radappend.TabIndex = 24
        Me.radappend.TabStop = True
        Me.radappend.Text = "Append the file(Add these flashcards to the file)"
        Me.radappend.UseVisualStyleBackColor = True
        Me.radappend.Visible = False
        '
        'radoverwrite
        '
        Me.radoverwrite.AutoSize = True
        Me.radoverwrite.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radoverwrite.Location = New System.Drawing.Point(125, 188)
        Me.radoverwrite.Name = "radoverwrite"
        Me.radoverwrite.Size = New System.Drawing.Size(755, 28)
        Me.radoverwrite.TabIndex = 25
        Me.radoverwrite.TabStop = True
        Me.radoverwrite.Text = "Overwrite the file(Replace the contents of the file with my flashcard information" &
    ""
        Me.radoverwrite.UseVisualStyleBackColor = True
        Me.radoverwrite.Visible = False
        '
        'btnfilechoice
        '
        Me.btnfilechoice.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnfilechoice.Location = New System.Drawing.Point(393, 314)
        Me.btnfilechoice.Name = "btnfilechoice"
        Me.btnfilechoice.Size = New System.Drawing.Size(130, 65)
        Me.btnfilechoice.TabIndex = 26
        Me.btnfilechoice.Text = "&Submit decision"
        Me.btnfilechoice.UseVisualStyleBackColor = True
        Me.btnfilechoice.Visible = False
        '
        'txtprevfile
        '
        Me.txtprevfile.Location = New System.Drawing.Point(390, 269)
        Me.txtprevfile.Name = "txtprevfile"
        Me.txtprevfile.Size = New System.Drawing.Size(100, 20)
        Me.txtprevfile.TabIndex = 27
        Me.txtprevfile.Visible = False
        '
        'lblddd
        '
        Me.lblddd.AutoSize = True
        Me.lblddd.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblddd.Location = New System.Drawing.Point(173, 99)
        Me.lblddd.Name = "lblddd"
        Me.lblddd.Size = New System.Drawing.Size(673, 24)
        Me.lblddd.TabIndex = 28
        Me.lblddd.Text = "Input the file name (without the .txt) the .txt extension will be added automatic" &
    "ally"
        Me.lblddd.Visible = False
        '
        'btnreget
        '
        Me.btnreget.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.btnreget.Location = New System.Drawing.Point(390, 327)
        Me.btnreget.Name = "btnreget"
        Me.btnreget.Size = New System.Drawing.Size(130, 62)
        Me.btnreget.TabIndex = 29
        Me.btnreget.Text = "submit the filename"
        Me.btnreget.UseVisualStyleBackColor = True
        Me.btnreget.Visible = False
        '
        'lblstudycard
        '
        Me.lblstudycard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblstudycard.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblstudycard.Location = New System.Drawing.Point(296, 35)
        Me.lblstudycard.Name = "lblstudycard"
        Me.lblstudycard.Size = New System.Drawing.Size(311, 379)
        Me.lblstudycard.TabIndex = 30
        Me.lblstudycard.Text = "Label6"
        Me.lblstudycard.Visible = False
        '
        'btnNextcard
        '
        Me.btnNextcard.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNextcard.Location = New System.Drawing.Point(663, 222)
        Me.btnNextcard.Name = "btnNextcard"
        Me.btnNextcard.Size = New System.Drawing.Size(142, 81)
        Me.btnNextcard.TabIndex = 31
        Me.btnNextcard.Text = "Next ca&rd"
        Me.btnNextcard.UseVisualStyleBackColor = True
        Me.btnNextcard.Visible = False
        '
        'btnprevcard
        '
        Me.btnprevcard.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnprevcard.Location = New System.Drawing.Point(84, 229)
        Me.btnprevcard.Name = "btnprevcard"
        Me.btnprevcard.Size = New System.Drawing.Size(143, 80)
        Me.btnprevcard.TabIndex = 32
        Me.btnprevcard.Text = "Previous &card"
        Me.btnprevcard.UseVisualStyleBackColor = True
        Me.btnprevcard.Visible = False
        '
        'btnFlipcard
        '
        Me.btnFlipcard.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFlipcard.Location = New System.Drawing.Point(390, 435)
        Me.btnFlipcard.Name = "btnFlipcard"
        Me.btnFlipcard.Size = New System.Drawing.Size(130, 75)
        Me.btnFlipcard.TabIndex = 33
        Me.btnFlipcard.Text = "&Flip Card"
        Me.btnFlipcard.UseVisualStyleBackColor = True
        Me.btnFlipcard.Visible = False
        '
        'btnback
        '
        Me.btnback.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnback.Location = New System.Drawing.Point(590, 485)
        Me.btnback.Name = "btnback"
        Me.btnback.Size = New System.Drawing.Size(179, 43)
        Me.btnback.TabIndex = 34
        Me.btnback.Text = "Back to &Previous page"
        Me.btnback.UseVisualStyleBackColor = True
        Me.btnback.Visible = False
        '
        'frmmain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(923, 540)
        Me.Controls.Add(Me.btnback)
        Me.Controls.Add(Me.btnFlipcard)
        Me.Controls.Add(Me.btnprevcard)
        Me.Controls.Add(Me.btnNextcard)
        Me.Controls.Add(Me.lblstudycard)
        Me.Controls.Add(Me.btnreget)
        Me.Controls.Add(Me.lblddd)
        Me.Controls.Add(Me.txtprevfile)
        Me.Controls.Add(Me.btnfilechoice)
        Me.Controls.Add(Me.radoverwrite)
        Me.Controls.Add(Me.radappend)
        Me.Controls.Add(Me.lblask)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.txtfilename)
        Me.Controls.Add(Me.lblfilee)
        Me.Controls.Add(Me.btnFile)
        Me.Controls.Add(Me.lbllimit)
        Me.Controls.Add(Me.btnStudy)
        Me.Controls.Add(Me.btnnotrecup)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.lblcreated)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lblrecup)
        Me.Controls.Add(Me.btnFiled)
        Me.Controls.Add(Me.btnCreate)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txthidden)
        Me.Controls.Add(Me.txtshown)
        Me.Controls.Add(Me.lblhidden)
        Me.Controls.Add(Me.lblshown)
        Me.Controls.Add(Me.btnExit)
        Me.Name = "frmmain"
        Me.Text = "Welcome to Quizlet simulation version 3"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents lblshown As Label
    Friend WithEvents lblhidden As Label
    Friend WithEvents txtshown As TextBox
    Friend WithEvents txthidden As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnCreate As Button
    Friend WithEvents btnFiled As Button
    Friend WithEvents lblrecup As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblcreated As Label
    Friend WithEvents btnClear As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents btnnotrecup As Button
    Friend WithEvents btnStudy As Button
    Friend WithEvents lbllimit As Label
    Friend WithEvents btnFile As Button
    Friend WithEvents lblfilee As Label
    Friend WithEvents txtfilename As TextBox
    Friend WithEvents btnSubmit As Button
    Friend WithEvents lblask As Label
    Friend WithEvents radappend As RadioButton
    Friend WithEvents radoverwrite As RadioButton
    Friend WithEvents btnfilechoice As Button
    Friend WithEvents txtprevfile As TextBox
    Friend WithEvents lblddd As Label
    Friend WithEvents btnreget As Button
    Friend WithEvents lblstudycard As Label
    Friend WithEvents btnNextcard As Button
    Friend WithEvents btnprevcard As Button
    Friend WithEvents btnFlipcard As Button
    Friend WithEvents btnback As Button
End Class
