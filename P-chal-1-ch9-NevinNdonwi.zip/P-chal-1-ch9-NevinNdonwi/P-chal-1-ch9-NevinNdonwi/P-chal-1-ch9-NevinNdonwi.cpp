// P-chal-1-ch9-NevinNdonwi.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>


//Programming Challenge 3 on page 655
using namespace std;

int main()


{

	
		int arr[] = { 13579, 26791, 26792, 33445, 55555, 62483, 77777, 79422,85647, 93121 }; //Ticket Numbers, Ticket Number = position + 1 

		cout << "Input the winning lottery ticket number for this week!\n";
		int num = 0;
		cin >> num;

		int size = sizeof(arr) / sizeof(arr[0]);


		int first = 0, // first element
			last = size - 1, //last element
			middle, position = -1;  // middle, current position

		bool found = false; // found value or not 


		while (!found && first <= last) {

			middle = (first + last) / 2;
			if (arr[middle] == num) {

				found = true;
				position = middle;
			}
			else if (arr[middle] > num) {

				last = middle - 1;
			}
			else {
				first = middle + 1;
			}


		}


		if (position == -1) {

			cout << "\nNone of the tickets won this week\n";
		}
		else {
			cout << "\nTicket #" << position + 1 << " contains the winning number!\n";
		}
		


		system("pause");
	return 0;
}


// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
