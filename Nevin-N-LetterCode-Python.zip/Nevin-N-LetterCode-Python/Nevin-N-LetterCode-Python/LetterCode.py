#LetterCode project by Nevin Ndonwi 

from LetterCodeLogic import LetterCodeLogic #Imports everything in the LetterCodeLogic class from the LetterCodeLogic File 


def getChoice():
    #use boolean variable for loop control..
    val = False
    while not val:
        try:
             c = int(input("Choice? Input: (1 = Encode), (2 = Decode), (0 = quit)\n"))
             if (c < 0 or c > 2):
                 #illegitimate input
                 print("Illegal input, (only 0,1,2 are valid inputs) Please try again\n")
                 
                 val = False
             else:
                 #legal input
                 val = True 

           

        except ValueError:
            print("Illegal input, (only 0,1,2 are valid inputs) Please try again\n")
           
            val = False

    #returns user input to the main function
    return c
    




def main():
    print("Welcome to the Letter Code program.")

    choice = getChoice()
    while choice != 0:
        if choice == 1:
            
            msg = input("\nEnter your letters to encode (capitalized): \n")
            #call encode method of LetterCodeLogic class
            result = LetterCodeLogic.Encode(msg)
            print("Your encoded message is:\n"+ result)

        elif choice == 2:
          
            msg = input("\nEnter your numbers to decode (separated by commas): \n")
            #call decode method of LetterCodeLogic class
            result = LetterCodeLogic.Decode(msg)
            print("Your decoded message is:\n"+ result)

        else:
            print("I do not understand your request")


        print()
        choice = getChoice()
    print ("Thank you for utilising the Letter Code program")








if __name__ == "__main__":
    main()
