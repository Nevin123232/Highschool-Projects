#LetterCodeLogic by Nevin Ndonwi

class LetterCodeLogic:
    """Encode/ Decode Methods"""


    @staticmethod #static method(able to be used by other program files)
    def Encode(msg):
        result = ""

        #separate string into individual values
        nums = msg

        c = ""
        #process each element of the list(the numbers) 
        for i in nums:

            
            try:
                n = i.upper() #makes sure there are no spaces

               
                if n == " ":
                    c = "0"


                

                else: #translation time  (based on ASCII chart values)
                    c = ord(n)  - 64


                    # how to match the output on the assignment example, if it is outside the range of 1-26 (A-Z)
                    if c < 1 or c > 26:
                        c = 99
            

               
            except:
                c = "?" #any character that is invalid in the input the user sends 



         
            result = result + str(c) + " " #last step inside the for loop

        return result
    

    @staticmethod
    def Decode(msg):
        #Method to split message string and decode the numbers inside
      
        result = ""

        #separate string into individual values
        nums = msg.split(",")

        #process each element of the list(the numbers) 
        for i in nums:
            #translate the string x into a letter

            try:
                n = int(i.strip()) #makes sure there are no spaces
                if n == 0:
                    c = " "
                elif n < 1 or n > 26: # if the number is outside the range
                    c = "?"
                else: #translation time  (based on ASCII chart values)
                    c = chr(n+64)
            

               
            except ValueError:
                c = "?" #any character that is invalid in the input the user sends 



            result = result + c #last step inside the for loop

        return result


