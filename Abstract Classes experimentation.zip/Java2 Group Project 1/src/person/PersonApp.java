//Java programming 2 Group Project 1 by Nevin Ndonwi and William Molloy
//Outputs information to console (Console Application verson) 
  
package person;

 
import java.util.*;
//validates email
import java.util.regex.Pattern;
 

//abstract person class 
abstract class Person{
	
	
	private String firstName = "";
	private String lastName = "";
	private String email = "";
	
	//Person constructor without parameters
	public Person() {
		
		
	}
	
	//Person constructor with parameters
	public Person(String name1, String name2, String mail) {
		
		setfirstName(name1);
		setlastName(name2);
		setemail(mail);
	}
	
	
	//sets person's subfields
	public void setfirstName(String name1) {
	
		firstName = name1;
	}
	
	public void setlastName(String name2) {
		
		lastName = name2;
	}

	public void setemail(String mail) {
		email = mail;
		
	}

	
	//returns elements of a person
	public String getfirstName() {
		
    return firstName;
		
	}
	
	public String getlastName() {
		
		return lastName;
	}

	public String getemail() {
		
		return email;
	}
	
	
	//override toString method
	public String toString() {
		String output = "";
		
		output = "Name: " + firstName + " " + lastName + "\n" + "Email: " + email;
		
		return output;
	}

	
	//getDisplayText abstract method 
	public abstract String getDisplayText();
}



//customer class that inherits from abstract person class

class Customer extends Person{

	private String customerNumber = "";
	
	//no parameter 
	public Customer() {
		
		
	}
	
	////constructor with parameters 
	public Customer(String name1, String name2, String email, String customerNum) {
		//evokes superclass constructor
		super(name1,name2,email);
		
		
		setCustomernumber(customerNum);
	}
	
	
	
//sets customer number
	
	public void setCustomernumber(String num) {
		this.customerNumber = num;
		
	}
	
	
//	gets customer number
	public String getCustomernumber() {
    return this.customerNumber;
		
	}
	
	
	// getDisplay text abstract method
	
	public String getDisplayText() {
	
		
		return super.toString() + "\n" + "Customer Number: " + this.customerNumber;
	}
	
	
}



//Employee class
class Employee extends Person {

	
//social security variable 
	private String social = "";
	
	
	//no parameter constructor
	public Employee() {
		
		
	}
	
	
	//parameter constructor
	public Employee(String name1, String name2, String email, String socialsec) {
		//evokes superclass constructor
		super(name1,name2,email);
		
		
		setsocial(socialsec);
	}
	
	
	//sets social security 
	public void setsocial(String num) {
		this.social = num;
		
	}
	
	
	// gets social security 
	public String getsocialSec() {
    return this.social;
		
	}
	
	
	// getDisplay text abstract method
	
	public String getDisplayText() {
	
		
		return super.toString() + "\n" + "Social Security Number: " + this.social;
	}
	
	
	
}

public class PersonApp {

static Scanner scan = new Scanner(System.in);

	 public static void main(String[] args) {
		 
		 
		 while(true) {
			 
			 
			 
		 System.out.println("Welcome to the Person Application\n");
		 
		 System.out.println("Would you like to create a Customer (input c) or Employee (input e)?\n");
		 //gets user's input
		 String object = scan.nextLine();
		 
		 //checks if the user inputs c or e
		while(true) {
			
			//loop breaks if a legitimate option is inputted
			 if(object.equals("c")) {
					 break;
			 }
			 else if(object.equals("e")) {
				 
				 break;
			 } 
			 else {
				 
				 //loop continues if the user does not input a valid option (customer or employee)
				 System.out.println("\nYour previous input was invalid, please input c or e. ");
				  object = scan.nextLine();
			 }
			
		}
	

		String middle = ""; // based on whether employee or customer is chosen (displays one or the other)
		
		
		if(object.equals("c")) {
			 System.out.println("\nGreat! Time to register a new Customer! ");
			 
			
			 middle = "customer";
			 
		 }
		 else if(object.equals("e")) {
			 
			 System.out.println("\nGreat! Time to register a new Employee! ");
			 
			 
			middle = "employee";
			 
		 }
		 
		System.out.println("\nPlease enter the " + middle +  "'s First Name: ");
		 
		String name1 = scan.nextLine();
		
		while(nameLegitimizer(name1) != true) {
			
			System.out.println("\nPlease input a name that only contains letters\n");
			 name1 = scan.nextLine();
			nameLegitimizer(name1);
			
		}
		
		System.out.println("\nPlease enter the " + middle +  "'s Last Name: ");
		
		String name2 = scan.nextLine();
		
		
		while(nameLegitimizer(name2) != true) {
			
			System.out.println("\nPlease input a name that only contains letters\n");
			 name2 = scan.nextLine();
			nameLegitimizer(name2);
			
		}
		
		
		System.out.println("\nPlease enter the " + middle +  "'s Email: ");
		
		//gets email with appropriate validation
		String email = getEmail();
		
		
		if(object.equals("c")) {
		
			System.out.println("\nPlease enter the " + middle +  "'s Customer Number: ");
			
			String num = scan.nextLine();
			
			
			
			//validate customer number 
			
			 while(true) {
			if(cnum(num) == true) {
				break;
				
			}
			else {
				
				System.out.println("\nYour previous input was invalid, please try again(input a letter then numbers, example: R56789)\n Your input must be at least 4 characters \n");
				num = scan.nextLine();
			}
			
			
		  }
			 
			
	
			
			Customer x = new Customer(name1, name2,email,num);
			
			System.out.println("\n\n\n\n**********A New " + middle + " object has been created**********\n\n\n\n");
			
			
			System.out.println("Here is the information: \n");
			
			print(x);
		 }
		 else if(object.equals("e")) {
			 
				System.out.println("\nPlease enter the " + middle +  "'s Social Security Number: ");
				
				String num = scan.nextLine();
				

				while(true) {
					if(numberLegitimizer(num) == true) {
						break;
						
					}
					else {
						
						System.out.println("\nYour previous input was invalid, please try again (Only input numbers 1,2,3,4,5,6,7,8,9,0),\\n Your input must be at least 4 characters\n");
						num = scan.nextLine();
					}
					
					
				}
				
			
				Employee x = new Employee(name1, name2,email,num);
				
				System.out.println("\n\n\n\n**********A New " + middle + " object has been created**********\n\n\n\n");
				
				
				System.out.println("Here is the information: \n");
				
				print(x);
				
				
		 }
		
		System.out.println("Would you like to continue using this application?(Input n for no)");
		
		
	String c = scan.nextLine();
	
	if(c.equals("n")) {
		
		break;
	}
	else {
		
		System.out.println("\n\n");
	}
		
		
		 }
		   
		 
		 System.out.println("\n\nHave a nice Day!\n\n");
	 }
	 
	 
	 //outputs information
	
	 public static void print(Person x) {
		 
		 System.out.println(x.getDisplayText());
	 }
	
	 
	 
	 
	 //validates names

	 public static boolean nameLegitimizer(String test) { // This makes sure that the Employee's name has only letters and no extraneous characters
			
			boolean legit = false;
			String alphabet = "abcdefghijklmnopqrstuvwxyz";
			String capital = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
			int counter = 0;  
			
			for (int i = 1; i <= test.length(); i++) { // Checks if any of the name characters doesn't equal the alphabet character
				
				
				for (int o = 1; o <= alphabet.length(); o++) {
				
				  if(test.substring(i - 1,i).equals(alphabet.substring(o - 1, o)) ) {
					
					counter += 1; // checks the amount of characters that equal the alphabet characters
					break;
				   }
				  
				  if(test.substring(i - 1,i).equals(capital.substring(o - 1, o)) ) {
						
					counter += 1;  // checks the amount of characters that equal the alphabet characters
					break;
					
				   }
				  
				  
					
				}
				
			}
			
			
			if (counter >= test.length() ) { // checks if the amount of legitimate characters is greater than or equal to the length of the string

				return !legit; // returns true if there are only letters in the string 
				
				
	// returns true if the amount of legit characters is greater than or equal the length of the string
				
			}
			else { 
				
			return legit; // returns false if there are characters other then letters in the string
			
			
			
	//returns false if the amount of legit characters is less than the length of the string
			
			
			}
		}
		
	 
	 
	 
	 // validates email address
	
	 public static String getEmail()
	 
	    {  
		 
		
		 
	        String eMail = "";
	        eMail = scan.nextLine();
	        Scanner sc = new Scanner(eMail);
	        while (true)
	        {
	         
	            if (sc.hasNextLine())
	            {
	                
	                if (!Pattern.matches("^[a-zA-Z][\\w\\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\\w\\.-]*[a-zA-Z0-9]\\.[a-zA-Z][a-zA-Z\\.]*[a-zA-Z]$", eMail))
	                {
	                    System.out.println("This is not a valid email address! Try again.\n");
	                    eMail = scan.nextLine();
	                }
	                else {
	                	System.out.println("\nA legitimate email has been entered\n");
	                	break;
	                }
	               
	                //sc.nextLine();
	            }
	        }
	        return eMail;
	    }
	    
	 
	 
	 

	 
	 //validates customer number?
	 public static boolean cnum(String test) {
		 
		 //customer number must be at least 4 characters long
		 if(test.length() < 4) {
			 return false; 
			 
		 }
		 
		 char[] alph = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
		 
		 
		 //checks if a letter is the first character of the customer id
		 for(int x = 0; x < alph.length;  x++) {
			 if(test.charAt(0) == alph[x]) {
				 break;
				 
			 }
			 else if(test.charAt(0) == Character.toUpperCase(alph[x])) {
				 break;
				 
			 }
			 
			 if(x == alph.length - 1) {
				 return false;
			 }
			 
		 }
		 
		 
		 //checks if the customer id only contains numbers 
		 String test2 = test.substring(1,test.length());
		 
		 return numberLegitimizer(test2);
		 
	 }
	 
	 
	 
	 
	 
	 //validates employee social security number
	 
	 public static boolean numberLegitimizer(String test) {
			
		 //customer number must be at least 4 characters long
		 if(test.length() < 3) {
			 return false; 
			 
		 }
		 
			boolean legit = false;
			String numbers = "1234567890";
		
			int counter = 0;  
			
			for (int i = 1; i <= test.length(); i++) { // Checks if any of the number characters does not equal a number character
				
				
				for (int o = 1; o <= numbers.length(); o++) {
				
				  if(test.substring(i - 1,i).equals(numbers.substring(o - 1, o)) ) {
					
					counter += 1; 
					break;
				   }
				  
				 
				  
				   
					
				}
				
			}
			
			
			if (counter >= test.length() ) {   // checks if the amount of legitimate number characters is greater than or equal to the length of the string

				

				return !legit; // Returns true if it doesn't contain a non-number character
				
				// returns true if the amount of legitimate number characters is greater than or equal to the length of the string 
			}
			else {
				
			return legit; // Returns false if it does contain a non-number character
			
			// returns false if the amount of legitimate number characters is less than or equal to the length of the string 
			}
			
			
			
		}
	 
	 
} 
 














