// Ch10-P-chal-1-Nevin-Ndonwi.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

using namespace std;

// Programming Challenge 2 page 715

struct student {

    string name;
    double score;
};

void sort(student* arr, int size)
{
    for (int y = 0; y < size; y++) {

        for (int z = y + 1; z < size; z++) {

            if (   ((arr + z)->score) <    ((arr + y)->score)    ) {

                student temp = *(arr + y);
                *(arr + y) = *(arr + z);
                *(arr + z) = temp;


            }
        }

    }


    for (int x = 0; x < size; x++) {

        cout << arr[x].name<< ": " << arr[x].score << "\n";
    }

}

void average(student* arr, int size)
{
    int total = 0;

    for (int a = 0; a < size; a++) {

        total += (arr+ a)->score;
    }


    double average = (double)total / (double)size;

    cout << average << "\n";
}
int main()
{
    cout << "Input how many (students and test score pairs) do you have:\n";
    int amount;
    cin >> amount;
    cout << "\nYou are going to input " << amount << " students and test score(s):\n";

    student* group = new student[amount];

    int x = 0;
    double r = 0;
    string s = "";

    while (x < amount) {

        cout << "Input a student name:\n";
        cin >> s;

        bool val = false;

        while (!val) {
            cout << "Input a test score(no negative numbers):\n";
            cin >> r;
            if (r >= 0) {
                val = true;
            }
            else {
                cout << "Negative numbers are not allowed.\n";
            }

        }


        group[x].score = r;
        group[x].name = s;
        
        x++;
    }


    cout << "\nAll scores and student names have been inputted.\n";

    cout << "\n\nHere is the list of names and scores(unsorted) :\n\n";

    for (int x = 0; x < amount; x++) {

        cout << group[x].name << ": " << group[x].score << "\n";
    }



    cout << "\n\nHere is the list of names and scores(sorted) :\n\n";

    sort(group, amount);


    cout << "\n\nHere is the average score:\n\n";
    average(group, amount);



    delete[] group;

    system("pause");

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
