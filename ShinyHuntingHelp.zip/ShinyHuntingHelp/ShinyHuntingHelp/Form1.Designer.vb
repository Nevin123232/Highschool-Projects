﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmmain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbluseless = New System.Windows.Forms.Label()
        Me.btnsubsoft = New System.Windows.Forms.Button()
        Me.btnaddsoft = New System.Windows.Forms.Button()
        Me.lbldisresets = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblodds = New System.Windows.Forms.Label()
        Me.lblodds1 = New System.Windows.Forms.Label()
        Me.btnfile = New System.Windows.Forms.Button()
        Me.btnsave = New System.Windows.Forms.Button()
        Me.txtsave = New System.Windows.Forms.TextBox()
        Me.lblsave = New System.Windows.Forms.Label()
        Me.btnload = New System.Windows.Forms.Button()
        Me.txtreget = New System.Windows.Forms.TextBox()
        Me.btnreget = New System.Windows.Forms.Button()
        Me.lblload = New System.Windows.Forms.Label()
        Me.lblodds2 = New System.Windows.Forms.Label()
        Me.btnmanual = New System.Windows.Forms.Button()
        Me.txtinput = New System.Windows.Forms.TextBox()
        Me.btninput = New System.Windows.Forms.Button()
        Me.lblinput = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lbluseless
        '
        Me.lbluseless.AutoSize = True
        Me.lbluseless.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbluseless.Location = New System.Drawing.Point(3, 184)
        Me.lbluseless.Name = "lbluseless"
        Me.lbluseless.Size = New System.Drawing.Size(293, 20)
        Me.lbluseless.TabIndex = 0
        Me.lbluseless.Text = "SoftResets / Amount of encounters"
        '
        'btnsubsoft
        '
        Me.btnsubsoft.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsubsoft.Location = New System.Drawing.Point(201, 291)
        Me.btnsubsoft.Name = "btnsubsoft"
        Me.btnsubsoft.Size = New System.Drawing.Size(95, 44)
        Me.btnsubsoft.TabIndex = 1
        Me.btnsubsoft.Text = "&-"
        Me.btnsubsoft.UseVisualStyleBackColor = True
        '
        'btnaddsoft
        '
        Me.btnaddsoft.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnaddsoft.Location = New System.Drawing.Point(7, 291)
        Me.btnaddsoft.Name = "btnaddsoft"
        Me.btnaddsoft.Size = New System.Drawing.Size(88, 44)
        Me.btnaddsoft.TabIndex = 2
        Me.btnaddsoft.Text = "&+"
        Me.btnaddsoft.UseVisualStyleBackColor = True
        '
        'lbldisresets
        '
        Me.lbldisresets.AutoSize = True
        Me.lbldisresets.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldisresets.Location = New System.Drawing.Point(93, 228)
        Me.lbldisresets.Name = "lbldisresets"
        Me.lbldisresets.Size = New System.Drawing.Size(120, 39)
        Me.lbldisresets.TabIndex = 3
        Me.lbldisresets.Text = "Label1"
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(545, 464)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(57, 47)
        Me.btnExit.TabIndex = 4
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblodds
        '
        Me.lblodds.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblodds.Location = New System.Drawing.Point(43, 1)
        Me.lblodds.Name = "lblodds"
        Me.lblodds.Size = New System.Drawing.Size(205, 51)
        Me.lblodds.TabIndex = 5
        Me.lblodds.Text = "You have hit odds!!!! (pre gen 6: 1/8192)"
        Me.lblodds.Visible = False
        '
        'lblodds1
        '
        Me.lblodds1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblodds1.Location = New System.Drawing.Point(47, 61)
        Me.lblodds1.Name = "lblodds1"
        Me.lblodds1.Size = New System.Drawing.Size(206, 51)
        Me.lblodds1.TabIndex = 6
        Me.lblodds1.Text = "You have hit odds!!!! (post gen 6: 1/4096)"
        Me.lblodds1.Visible = False
        '
        'btnfile
        '
        Me.btnfile.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnfile.Location = New System.Drawing.Point(334, 2)
        Me.btnfile.Name = "btnfile"
        Me.btnfile.Size = New System.Drawing.Size(170, 77)
        Me.btnfile.TabIndex = 7
        Me.btnfile.Text = "Save the &amount of encounters / softresets"
        Me.btnfile.UseVisualStyleBackColor = True
        '
        'btnsave
        '
        Me.btnsave.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsave.Location = New System.Drawing.Point(387, 217)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(87, 50)
        Me.btnsave.TabIndex = 8
        Me.btnsave.Text = "Su&bmit filename"
        Me.btnsave.UseVisualStyleBackColor = True
        Me.btnsave.Visible = False
        '
        'txtsave
        '
        Me.txtsave.Location = New System.Drawing.Point(364, 186)
        Me.txtsave.Name = "txtsave"
        Me.txtsave.Size = New System.Drawing.Size(125, 20)
        Me.txtsave.TabIndex = 9
        Me.txtsave.Visible = False
        '
        'lblsave
        '
        Me.lblsave.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblsave.Location = New System.Drawing.Point(290, 82)
        Me.lblsave.Name = "lblsave"
        Me.lblsave.Size = New System.Drawing.Size(269, 102)
        Me.lblsave.TabIndex = 10
        Me.lblsave.Text = "Input the name of the file where you want to save your data (the .txt extension w" &
    "ill be added automatically)" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.lblsave.Visible = False
        '
        'btnload
        '
        Me.btnload.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnload.Location = New System.Drawing.Point(311, 292)
        Me.btnload.Name = "btnload"
        Me.btnload.Size = New System.Drawing.Size(235, 59)
        Me.btnload.TabIndex = 11
        Me.btnload.Text = "Load &Previous Data"
        Me.btnload.UseVisualStyleBackColor = True
        '
        'txtreget
        '
        Me.txtreget.Location = New System.Drawing.Point(364, 435)
        Me.txtreget.Name = "txtreget"
        Me.txtreget.Size = New System.Drawing.Size(125, 20)
        Me.txtreget.TabIndex = 13
        Me.txtreget.Visible = False
        '
        'btnreget
        '
        Me.btnreget.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnreget.Location = New System.Drawing.Point(387, 464)
        Me.btnreget.Name = "btnreget"
        Me.btnreget.Size = New System.Drawing.Size(87, 50)
        Me.btnreget.TabIndex = 12
        Me.btnreget.Text = "Submit f&ilename"
        Me.btnreget.UseVisualStyleBackColor = True
        Me.btnreget.Visible = False
        '
        'lblload
        '
        Me.lblload.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblload.Location = New System.Drawing.Point(238, 354)
        Me.lblload.Name = "lblload"
        Me.lblload.Size = New System.Drawing.Size(377, 75)
        Me.lblload.TabIndex = 14
        Me.lblload.Text = "Input the name of the file where you want to save your data (the .txt extension w" &
    "ill be added automatically)" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.lblload.Visible = False
        '
        'lblodds2
        '
        Me.lblodds2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblodds2.Location = New System.Drawing.Point(43, 116)
        Me.lblodds2.Name = "lblodds2"
        Me.lblodds2.Size = New System.Drawing.Size(213, 48)
        Me.lblodds2.TabIndex = 15
        Me.lblodds2.Text = "You have hit odds!!!! (Pokemon Go: 1/450)"
        Me.lblodds2.Visible = False
        '
        'btnmanual
        '
        Me.btnmanual.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnmanual.Location = New System.Drawing.Point(70, 400)
        Me.btnmanual.Name = "btnmanual"
        Me.btnmanual.Size = New System.Drawing.Size(129, 77)
        Me.btnmanual.TabIndex = 16
        Me.btnmanual.Text = "Input so&ftresets"
        Me.btnmanual.UseVisualStyleBackColor = True
        '
        'txtinput
        '
        Me.txtinput.Location = New System.Drawing.Point(86, 430)
        Me.txtinput.Name = "txtinput"
        Me.txtinput.Size = New System.Drawing.Size(100, 20)
        Me.txtinput.TabIndex = 17
        Me.txtinput.Visible = False
        '
        'btninput
        '
        Me.btninput.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btninput.Location = New System.Drawing.Point(70, 459)
        Me.btninput.Name = "btninput"
        Me.btninput.Size = New System.Drawing.Size(129, 52)
        Me.btninput.TabIndex = 18
        Me.btninput.Text = "Re&set"
        Me.btninput.UseVisualStyleBackColor = True
        Me.btninput.Visible = False
        '
        'lblinput
        '
        Me.lblinput.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblinput.Location = New System.Drawing.Point(42, 349)
        Me.lblinput.Name = "lblinput"
        Me.lblinput.Size = New System.Drawing.Size(190, 45)
        Me.lblinput.TabIndex = 19
        Me.lblinput.Text = "Input the amount of encounters/softresets"
        Me.lblinput.Visible = False
        '
        'frmmain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(614, 516)
        Me.Controls.Add(Me.lblinput)
        Me.Controls.Add(Me.btninput)
        Me.Controls.Add(Me.txtinput)
        Me.Controls.Add(Me.btnmanual)
        Me.Controls.Add(Me.lblodds2)
        Me.Controls.Add(Me.lblload)
        Me.Controls.Add(Me.txtreget)
        Me.Controls.Add(Me.btnreget)
        Me.Controls.Add(Me.btnload)
        Me.Controls.Add(Me.lblsave)
        Me.Controls.Add(Me.txtsave)
        Me.Controls.Add(Me.btnsave)
        Me.Controls.Add(Me.btnfile)
        Me.Controls.Add(Me.lblodds1)
        Me.Controls.Add(Me.lblodds)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lbldisresets)
        Me.Controls.Add(Me.btnaddsoft)
        Me.Controls.Add(Me.btnsubsoft)
        Me.Controls.Add(Me.lbluseless)
        Me.Name = "frmmain"
        Me.Text = "Shiny Hunter Helper"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbluseless As Label
    Friend WithEvents btnsubsoft As Button
    Friend WithEvents btnaddsoft As Button
    Friend WithEvents lbldisresets As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents lblodds As Label
    Friend WithEvents lblodds1 As Label
    Friend WithEvents btnfile As Button
    Friend WithEvents btnsave As Button
    Friend WithEvents txtsave As TextBox
    Friend WithEvents lblsave As Label
    Friend WithEvents btnload As Button
    Friend WithEvents txtreget As TextBox
    Friend WithEvents btnreget As Button
    Friend WithEvents lblload As Label
    Friend WithEvents lblodds2 As Label
    Friend WithEvents btnmanual As Button
    Friend WithEvents txtinput As TextBox
    Friend WithEvents btninput As Button
    Friend WithEvents lblinput As Label
End Class
