// P-chal-1-chapter-9.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>


using namespace std;

//Programming challenge 1 page 655

int main()
{
    cout << "Hello World!\n";

    //Array of valid integer IDs

    int valid[18] = {5658845,  8080152,  1005231,
                     4520125,  4562555,  6545231,
                     7895122,  5552012,  3852085,
                     8777541,  5050552,  7576651,
                     8451277,  7825877,  7881200,
                     1302850,  1250255,  4581002};




    cout << "Input an ID Number:\n";
    int num = 0;
    cin >> num;

    bool x = false;

    for (int y = 0; y < 18; y++) {

        if (num == valid[y]) {

            x = true;
        }

    }

    if (x == true) {

        cout << "The ID inputted is valid\n";
    }
    else {
        cout << "The ID inputted is invalid\n";

    }


    system("pause");
}


// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
