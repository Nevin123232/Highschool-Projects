﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmlevel3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmlevel3))
        Me.lblwrong2 = New System.Windows.Forms.Label()
        Me.lblwrong1 = New System.Windows.Forms.Label()
        Me.pbofakeditto = New System.Windows.Forms.PictureBox()
        Me.pbofakezoroa = New System.Windows.Forms.PictureBox()
        Me.pbozoroa = New System.Windows.Forms.PictureBox()
        Me.pborealpikachu = New System.Windows.Forms.PictureBox()
        Me.pboditto = New System.Windows.Forms.PictureBox()
        Me.lblwrong4 = New System.Windows.Forms.Label()
        Me.lblwrong3 = New System.Windows.Forms.Label()
        Me.lblwrong5 = New System.Windows.Forms.Label()
        Me.lblwrong10 = New System.Windows.Forms.Label()
        Me.lblwrong8 = New System.Windows.Forms.Label()
        Me.lblwrong7 = New System.Windows.Forms.Label()
        Me.lblwrong9 = New System.Windows.Forms.Label()
        Me.lblwrong12 = New System.Windows.Forms.Label()
        Me.lblwrong11 = New System.Windows.Forms.Label()
        Me.lblwrong13 = New System.Windows.Forms.Label()
        Me.lblwrong14 = New System.Windows.Forms.Label()
        Me.lblright1 = New System.Windows.Forms.Label()
        Me.lblright2 = New System.Windows.Forms.Label()
        Me.lblright4 = New System.Windows.Forms.Label()
        Me.lblright3 = New System.Windows.Forms.Label()
        Me.lblright5 = New System.Windows.Forms.Label()
        Me.lblright6 = New System.Windows.Forms.Label()
        Me.lblright7 = New System.Windows.Forms.Label()
        Me.lblright8 = New System.Windows.Forms.Label()
        Me.lblright10 = New System.Windows.Forms.Label()
        Me.lblright9 = New System.Windows.Forms.Label()
        Me.lblright11 = New System.Windows.Forms.Label()
        Me.lblright12 = New System.Windows.Forms.Label()
        Me.lblright13 = New System.Windows.Forms.Label()
        Me.lblright14 = New System.Windows.Forms.Label()
        Me.lblright15 = New System.Windows.Forms.Label()
        Me.lblright16 = New System.Windows.Forms.Label()
        Me.lblright17 = New System.Windows.Forms.Label()
        Me.lblright18 = New System.Windows.Forms.Label()
        Me.lblright19 = New System.Windows.Forms.Label()
        Me.lblwrong25 = New System.Windows.Forms.Label()
        Me.lblright20 = New System.Windows.Forms.Label()
        Me.lblright21 = New System.Windows.Forms.Label()
        Me.lblwrong20 = New System.Windows.Forms.Label()
        Me.lblwrong21 = New System.Windows.Forms.Label()
        Me.lblwrong22 = New System.Windows.Forms.Label()
        Me.lblwrong24 = New System.Windows.Forms.Label()
        Me.lblwrong26 = New System.Windows.Forms.Label()
        Me.lblwrong27 = New System.Windows.Forms.Label()
        Me.lblwrong28 = New System.Windows.Forms.Label()
        Me.lblwrong29 = New System.Windows.Forms.Label()
        Me.lblwrong30 = New System.Windows.Forms.Label()
        Me.lblwrong34 = New System.Windows.Forms.Label()
        Me.lblwrong33 = New System.Windows.Forms.Label()
        Me.lblwrong31 = New System.Windows.Forms.Label()
        Me.lblwrong35 = New System.Windows.Forms.Label()
        Me.lblwrong36 = New System.Windows.Forms.Label()
        Me.lblwrong38 = New System.Windows.Forms.Label()
        Me.lblwrong39 = New System.Windows.Forms.Label()
        Me.lblwrong40 = New System.Windows.Forms.Label()
        Me.lblwrong41 = New System.Windows.Forms.Label()
        CType(Me.pbofakeditto, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbofakezoroa, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbozoroa, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pborealpikachu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pboditto, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblwrong2
        '
        Me.lblwrong2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong2.Location = New System.Drawing.Point(943, 453)
        Me.lblwrong2.Name = "lblwrong2"
        Me.lblwrong2.Size = New System.Drawing.Size(122, 41)
        Me.lblwrong2.TabIndex = 0
        '
        'lblwrong1
        '
        Me.lblwrong1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong1.Location = New System.Drawing.Point(791, 484)
        Me.lblwrong1.Name = "lblwrong1"
        Me.lblwrong1.Size = New System.Drawing.Size(59, 250)
        Me.lblwrong1.TabIndex = 1
        '
        'pbofakeditto
        '
        Me.pbofakeditto.Image = CType(resources.GetObject("pbofakeditto.Image"), System.Drawing.Image)
        Me.pbofakeditto.Location = New System.Drawing.Point(424, 33)
        Me.pbofakeditto.Name = "pbofakeditto"
        Me.pbofakeditto.Size = New System.Drawing.Size(187, 176)
        Me.pbofakeditto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbofakeditto.TabIndex = 2
        Me.pbofakeditto.TabStop = False
        '
        'pbofakezoroa
        '
        Me.pbofakezoroa.Image = CType(resources.GetObject("pbofakezoroa.Image"), System.Drawing.Image)
        Me.pbofakezoroa.Location = New System.Drawing.Point(827, 485)
        Me.pbofakezoroa.Name = "pbofakezoroa"
        Me.pbofakezoroa.Size = New System.Drawing.Size(207, 222)
        Me.pbofakezoroa.TabIndex = 3
        Me.pbofakezoroa.TabStop = False
        '
        'pbozoroa
        '
        Me.pbozoroa.Image = CType(resources.GetObject("pbozoroa.Image"), System.Drawing.Image)
        Me.pbozoroa.Location = New System.Drawing.Point(833, 484)
        Me.pbozoroa.Name = "pbozoroa"
        Me.pbozoroa.Size = New System.Drawing.Size(201, 251)
        Me.pbozoroa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbozoroa.TabIndex = 4
        Me.pbozoroa.TabStop = False
        '
        'pborealpikachu
        '
        Me.pborealpikachu.Image = CType(resources.GetObject("pborealpikachu.Image"), System.Drawing.Image)
        Me.pborealpikachu.Location = New System.Drawing.Point(50, 477)
        Me.pborealpikachu.Name = "pborealpikachu"
        Me.pborealpikachu.Size = New System.Drawing.Size(205, 225)
        Me.pborealpikachu.TabIndex = 5
        Me.pborealpikachu.TabStop = False
        '
        'pboditto
        '
        Me.pboditto.Image = CType(resources.GetObject("pboditto.Image"), System.Drawing.Image)
        Me.pboditto.Location = New System.Drawing.Point(405, 14)
        Me.pboditto.Name = "pboditto"
        Me.pboditto.Size = New System.Drawing.Size(201, 199)
        Me.pboditto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pboditto.TabIndex = 6
        Me.pboditto.TabStop = False
        '
        'lblwrong4
        '
        Me.lblwrong4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong4.Location = New System.Drawing.Point(791, 703)
        Me.lblwrong4.Name = "lblwrong4"
        Me.lblwrong4.Size = New System.Drawing.Size(274, 52)
        Me.lblwrong4.TabIndex = 7
        '
        'lblwrong3
        '
        Me.lblwrong3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong3.Location = New System.Drawing.Point(1032, 469)
        Me.lblwrong3.Name = "lblwrong3"
        Me.lblwrong3.Size = New System.Drawing.Size(33, 286)
        Me.lblwrong3.TabIndex = 8
        '
        'lblwrong5
        '
        Me.lblwrong5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong5.Location = New System.Drawing.Point(791, 447)
        Me.lblwrong5.Name = "lblwrong5"
        Me.lblwrong5.Size = New System.Drawing.Size(98, 41)
        Me.lblwrong5.TabIndex = 9
        '
        'lblwrong10
        '
        Me.lblwrong10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong10.Location = New System.Drawing.Point(250, 521)
        Me.lblwrong10.Name = "lblwrong10"
        Me.lblwrong10.Size = New System.Drawing.Size(29, 228)
        Me.lblwrong10.TabIndex = 10
        '
        'lblwrong8
        '
        Me.lblwrong8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong8.Location = New System.Drawing.Point(7, 475)
        Me.lblwrong8.Name = "lblwrong8"
        Me.lblwrong8.Size = New System.Drawing.Size(53, 254)
        Me.lblwrong8.TabIndex = 11
        '
        'lblwrong7
        '
        Me.lblwrong7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong7.Location = New System.Drawing.Point(7, 447)
        Me.lblwrong7.Name = "lblwrong7"
        Me.lblwrong7.Size = New System.Drawing.Size(248, 31)
        Me.lblwrong7.TabIndex = 12
        '
        'lblwrong9
        '
        Me.lblwrong9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong9.Location = New System.Drawing.Point(7, 697)
        Me.lblwrong9.Name = "lblwrong9"
        Me.lblwrong9.Size = New System.Drawing.Size(248, 52)
        Me.lblwrong9.TabIndex = 13
        '
        'lblwrong12
        '
        Me.lblwrong12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong12.Location = New System.Drawing.Point(593, 14)
        Me.lblwrong12.Name = "lblwrong12"
        Me.lblwrong12.Size = New System.Drawing.Size(34, 208)
        Me.lblwrong12.TabIndex = 14
        '
        'lblwrong11
        '
        Me.lblwrong11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong11.Location = New System.Drawing.Point(480, 198)
        Me.lblwrong11.Name = "lblwrong11"
        Me.lblwrong11.Size = New System.Drawing.Size(131, 24)
        Me.lblwrong11.TabIndex = 15
        '
        'lblwrong13
        '
        Me.lblwrong13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong13.Location = New System.Drawing.Point(405, 2)
        Me.lblwrong13.Name = "lblwrong13"
        Me.lblwrong13.Size = New System.Drawing.Size(222, 31)
        Me.lblwrong13.TabIndex = 16
        '
        'lblwrong14
        '
        Me.lblwrong14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong14.Location = New System.Drawing.Point(405, 33)
        Me.lblwrong14.Name = "lblwrong14"
        Me.lblwrong14.Size = New System.Drawing.Size(26, 189)
        Me.lblwrong14.TabIndex = 17
        '
        'lblright1
        '
        Me.lblright1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright1.Location = New System.Drawing.Point(433, 310)
        Me.lblright1.Name = "lblright1"
        Me.lblright1.Size = New System.Drawing.Size(305, 232)
        Me.lblright1.TabIndex = 18
        '
        'lblright2
        '
        Me.lblright2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright2.Location = New System.Drawing.Point(653, 116)
        Me.lblright2.Name = "lblright2"
        Me.lblright2.Size = New System.Drawing.Size(30, 201)
        Me.lblright2.TabIndex = 19
        '
        'lblright4
        '
        Me.lblright4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright4.Location = New System.Drawing.Point(653, 78)
        Me.lblright4.Name = "lblright4"
        Me.lblright4.Size = New System.Drawing.Size(397, 38)
        Me.lblright4.TabIndex = 20
        '
        'lblright3
        '
        Me.lblright3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright3.Location = New System.Drawing.Point(1018, 78)
        Me.lblright3.Name = "lblright3"
        Me.lblright3.Size = New System.Drawing.Size(32, 201)
        Me.lblright3.TabIndex = 21
        '
        'lblright5
        '
        Me.lblright5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright5.Location = New System.Drawing.Point(791, 258)
        Me.lblright5.Name = "lblright5"
        Me.lblright5.Size = New System.Drawing.Size(259, 21)
        Me.lblright5.TabIndex = 22
        '
        'lblright6
        '
        Me.lblright6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright6.Location = New System.Drawing.Point(791, 258)
        Me.lblright6.Name = "lblright6"
        Me.lblright6.Size = New System.Drawing.Size(27, 179)
        Me.lblright6.TabIndex = 23
        '
        'lblright7
        '
        Me.lblright7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright7.Location = New System.Drawing.Point(791, 416)
        Me.lblright7.Name = "lblright7"
        Me.lblright7.Size = New System.Drawing.Size(156, 31)
        Me.lblright7.TabIndex = 24
        '
        'lblright8
        '
        Me.lblright8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright8.Location = New System.Drawing.Point(885, 416)
        Me.lblright8.Name = "lblright8"
        Me.lblright8.Size = New System.Drawing.Size(62, 78)
        Me.lblright8.TabIndex = 25
        '
        'lblright10
        '
        Me.lblright10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright10.Location = New System.Drawing.Point(87, 131)
        Me.lblright10.Name = "lblright10"
        Me.lblright10.Size = New System.Drawing.Size(39, 201)
        Me.lblright10.TabIndex = 26
        '
        'lblright9
        '
        Me.lblright9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright9.Location = New System.Drawing.Point(87, 310)
        Me.lblright9.Name = "lblright9"
        Me.lblright9.Size = New System.Drawing.Size(360, 22)
        Me.lblright9.TabIndex = 27
        '
        'lblright11
        '
        Me.lblright11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright11.Location = New System.Drawing.Point(87, 131)
        Me.lblright11.Name = "lblright11"
        Me.lblright11.Size = New System.Drawing.Size(290, 22)
        Me.lblright11.TabIndex = 28
        '
        'lblright12
        '
        Me.lblright12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright12.Location = New System.Drawing.Point(354, 131)
        Me.lblright12.Name = "lblright12"
        Me.lblright12.Size = New System.Drawing.Size(56, 148)
        Me.lblright12.TabIndex = 29
        '
        'lblright13
        '
        Me.lblright13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright13.Location = New System.Drawing.Point(354, 222)
        Me.lblright13.Name = "lblright13"
        Me.lblright13.Size = New System.Drawing.Size(132, 72)
        Me.lblright13.TabIndex = 30
        '
        'lblright14
        '
        Me.lblright14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright14.Location = New System.Drawing.Point(424, 198)
        Me.lblright14.Name = "lblright14"
        Me.lblright14.Size = New System.Drawing.Size(62, 81)
        Me.lblright14.TabIndex = 31
        '
        'lblright15
        '
        Me.lblright15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright15.Location = New System.Drawing.Point(534, 521)
        Me.lblright15.Name = "lblright15"
        Me.lblright15.Size = New System.Drawing.Size(21, 64)
        Me.lblright15.TabIndex = 32
        '
        'lblright16
        '
        Me.lblright16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright16.Location = New System.Drawing.Point(534, 562)
        Me.lblright16.Name = "lblright16"
        Me.lblright16.Size = New System.Drawing.Size(241, 23)
        Me.lblright16.TabIndex = 33
        '
        'lblright17
        '
        Me.lblright17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright17.Location = New System.Drawing.Point(761, 562)
        Me.lblright17.Name = "lblright17"
        Me.lblright17.Size = New System.Drawing.Size(33, 145)
        Me.lblright17.TabIndex = 34
        '
        'lblright18
        '
        Me.lblright18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright18.Location = New System.Drawing.Point(535, 679)
        Me.lblright18.Name = "lblright18"
        Me.lblright18.Size = New System.Drawing.Size(259, 30)
        Me.lblright18.TabIndex = 35
        '
        'lblright19
        '
        Me.lblright19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright19.Location = New System.Drawing.Point(278, 679)
        Me.lblright19.Name = "lblright19"
        Me.lblright19.Size = New System.Drawing.Size(277, 30)
        Me.lblright19.TabIndex = 36
        '
        'lblwrong25
        '
        Me.lblwrong25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong25.Location = New System.Drawing.Point(480, 222)
        Me.lblwrong25.Name = "lblwrong25"
        Me.lblwrong25.Size = New System.Drawing.Size(176, 94)
        Me.lblwrong25.TabIndex = 37
        '
        'lblright20
        '
        Me.lblright20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright20.Location = New System.Drawing.Point(278, 521)
        Me.lblright20.Name = "lblright20"
        Me.lblright20.Size = New System.Drawing.Size(29, 186)
        Me.lblright20.TabIndex = 38
        '
        'lblright21
        '
        Me.lblright21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright21.Location = New System.Drawing.Point(224, 475)
        Me.lblright21.Name = "lblright21"
        Me.lblright21.Size = New System.Drawing.Size(83, 46)
        Me.lblright21.TabIndex = 39
        '
        'lblwrong20
        '
        Me.lblwrong20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong20.Location = New System.Drawing.Point(7, 2)
        Me.lblwrong20.Name = "lblwrong20"
        Me.lblwrong20.Size = New System.Drawing.Size(83, 445)
        Me.lblwrong20.TabIndex = 40
        '
        'lblwrong21
        '
        Me.lblwrong21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong21.Location = New System.Drawing.Point(87, 2)
        Me.lblwrong21.Name = "lblwrong21"
        Me.lblwrong21.Size = New System.Drawing.Size(323, 129)
        Me.lblwrong21.TabIndex = 41
        '
        'lblwrong22
        '
        Me.lblwrong22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong22.Location = New System.Drawing.Point(122, 153)
        Me.lblwrong22.Name = "lblwrong22"
        Me.lblwrong22.Size = New System.Drawing.Size(237, 157)
        Me.lblwrong22.TabIndex = 42
        '
        'lblwrong24
        '
        Me.lblwrong24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong24.Location = New System.Drawing.Point(358, 294)
        Me.lblwrong24.Name = "lblwrong24"
        Me.lblwrong24.Size = New System.Drawing.Size(128, 22)
        Me.lblwrong24.TabIndex = 43
        '
        'lblwrong26
        '
        Me.lblwrong26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong26.Location = New System.Drawing.Point(626, 2)
        Me.lblwrong26.Name = "lblwrong26"
        Me.lblwrong26.Size = New System.Drawing.Size(30, 220)
        Me.lblwrong26.TabIndex = 44
        '
        'lblwrong27
        '
        Me.lblwrong27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong27.Location = New System.Drawing.Point(653, 2)
        Me.lblwrong27.Name = "lblwrong27"
        Me.lblwrong27.Size = New System.Drawing.Size(412, 76)
        Me.lblwrong27.TabIndex = 45
        '
        'lblwrong28
        '
        Me.lblwrong28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong28.Location = New System.Drawing.Point(1046, -8)
        Me.lblwrong28.Name = "lblwrong28"
        Me.lblwrong28.Size = New System.Drawing.Size(62, 461)
        Me.lblwrong28.TabIndex = 46
        '
        'lblwrong29
        '
        Me.lblwrong29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong29.Location = New System.Drawing.Point(943, 400)
        Me.lblwrong29.Name = "lblwrong29"
        Me.lblwrong29.Size = New System.Drawing.Size(107, 53)
        Me.lblwrong29.TabIndex = 47
        '
        'lblwrong30
        '
        Me.lblwrong30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong30.Location = New System.Drawing.Point(817, 277)
        Me.lblwrong30.Name = "lblwrong30"
        Me.lblwrong30.Size = New System.Drawing.Size(233, 139)
        Me.lblwrong30.TabIndex = 48
        '
        'lblwrong34
        '
        Me.lblwrong34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong34.Location = New System.Drawing.Point(553, 542)
        Me.lblwrong34.Name = "lblwrong34"
        Me.lblwrong34.Size = New System.Drawing.Size(130, 25)
        Me.lblwrong34.TabIndex = 50
        '
        'lblwrong33
        '
        Me.lblwrong33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong33.Location = New System.Drawing.Point(680, 258)
        Me.lblwrong33.Name = "lblwrong33"
        Me.lblwrong33.Size = New System.Drawing.Size(114, 304)
        Me.lblwrong33.TabIndex = 51
        '
        'lblwrong31
        '
        Me.lblwrong31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong31.Location = New System.Drawing.Point(680, 116)
        Me.lblwrong31.Name = "lblwrong31"
        Me.lblwrong31.Size = New System.Drawing.Size(340, 144)
        Me.lblwrong31.TabIndex = 52
        '
        'lblwrong35
        '
        Me.lblwrong35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong35.Location = New System.Drawing.Point(307, 585)
        Me.lblwrong35.Name = "lblwrong35"
        Me.lblwrong35.Size = New System.Drawing.Size(458, 94)
        Me.lblwrong35.TabIndex = 55
        '
        'lblwrong36
        '
        Me.lblwrong36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong36.Location = New System.Drawing.Point(278, 707)
        Me.lblwrong36.Name = "lblwrong36"
        Me.lblwrong36.Size = New System.Drawing.Size(516, 42)
        Me.lblwrong36.TabIndex = 56
        '
        'lblwrong38
        '
        Me.lblwrong38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong38.Location = New System.Drawing.Point(87, 332)
        Me.lblwrong38.Name = "lblwrong38"
        Me.lblwrong38.Size = New System.Drawing.Size(360, 115)
        Me.lblwrong38.TabIndex = 57
        '
        'lblwrong39
        '
        Me.lblwrong39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong39.Location = New System.Drawing.Point(250, 447)
        Me.lblwrong39.Name = "lblwrong39"
        Me.lblwrong39.Size = New System.Drawing.Size(197, 30)
        Me.lblwrong39.TabIndex = 58
        '
        'lblwrong40
        '
        Me.lblwrong40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong40.Location = New System.Drawing.Point(307, 477)
        Me.lblwrong40.Name = "lblwrong40"
        Me.lblwrong40.Size = New System.Drawing.Size(140, 108)
        Me.lblwrong40.TabIndex = 59
        '
        'lblwrong41
        '
        Me.lblwrong41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong41.Location = New System.Drawing.Point(424, 542)
        Me.lblwrong41.Name = "lblwrong41"
        Me.lblwrong41.Size = New System.Drawing.Size(114, 43)
        Me.lblwrong41.TabIndex = 60
        '
        'frmlevel3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1145, 749)
        Me.Controls.Add(Me.lblright1)
        Me.Controls.Add(Me.lblright21)
        Me.Controls.Add(Me.lblwrong41)
        Me.Controls.Add(Me.lblwrong40)
        Me.Controls.Add(Me.lblwrong39)
        Me.Controls.Add(Me.lblwrong38)
        Me.Controls.Add(Me.lblwrong36)
        Me.Controls.Add(Me.lblwrong35)
        Me.Controls.Add(Me.lblwrong31)
        Me.Controls.Add(Me.lblwrong33)
        Me.Controls.Add(Me.lblwrong34)
        Me.Controls.Add(Me.lblwrong30)
        Me.Controls.Add(Me.lblwrong29)
        Me.Controls.Add(Me.lblwrong28)
        Me.Controls.Add(Me.lblwrong27)
        Me.Controls.Add(Me.lblwrong26)
        Me.Controls.Add(Me.lblwrong24)
        Me.Controls.Add(Me.lblwrong22)
        Me.Controls.Add(Me.lblwrong21)
        Me.Controls.Add(Me.lblwrong20)
        Me.Controls.Add(Me.lblright20)
        Me.Controls.Add(Me.lblwrong25)
        Me.Controls.Add(Me.lblright19)
        Me.Controls.Add(Me.lblright18)
        Me.Controls.Add(Me.lblright17)
        Me.Controls.Add(Me.lblright16)
        Me.Controls.Add(Me.lblright15)
        Me.Controls.Add(Me.lblright14)
        Me.Controls.Add(Me.lblright13)
        Me.Controls.Add(Me.lblright12)
        Me.Controls.Add(Me.lblright11)
        Me.Controls.Add(Me.lblright9)
        Me.Controls.Add(Me.lblright10)
        Me.Controls.Add(Me.lblright8)
        Me.Controls.Add(Me.lblright7)
        Me.Controls.Add(Me.lblright6)
        Me.Controls.Add(Me.lblright5)
        Me.Controls.Add(Me.lblright3)
        Me.Controls.Add(Me.lblright4)
        Me.Controls.Add(Me.lblright2)
        Me.Controls.Add(Me.lblwrong14)
        Me.Controls.Add(Me.lblwrong13)
        Me.Controls.Add(Me.lblwrong11)
        Me.Controls.Add(Me.lblwrong12)
        Me.Controls.Add(Me.lblwrong9)
        Me.Controls.Add(Me.lblwrong7)
        Me.Controls.Add(Me.lblwrong8)
        Me.Controls.Add(Me.lblwrong10)
        Me.Controls.Add(Me.lblwrong5)
        Me.Controls.Add(Me.lblwrong3)
        Me.Controls.Add(Me.lblwrong4)
        Me.Controls.Add(Me.pborealpikachu)
        Me.Controls.Add(Me.pbofakezoroa)
        Me.Controls.Add(Me.pbofakeditto)
        Me.Controls.Add(Me.lblwrong1)
        Me.Controls.Add(Me.lblwrong2)
        Me.Controls.Add(Me.pbozoroa)
        Me.Controls.Add(Me.pboditto)
        Me.Name = "frmlevel3"
        Me.Text = "Welcome to level 3"
        CType(Me.pbofakeditto, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbofakezoroa, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbozoroa, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pborealpikachu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pboditto, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblwrong2 As Label
    Friend WithEvents lblwrong1 As Label
    Friend WithEvents pbofakeditto As PictureBox
    Friend WithEvents pbofakezoroa As PictureBox
    Friend WithEvents pbozoroa As PictureBox
    Friend WithEvents pborealpikachu As PictureBox
    Friend WithEvents pboditto As PictureBox
    Friend WithEvents lblwrong4 As Label
    Friend WithEvents lblwrong3 As Label
    Friend WithEvents lblwrong5 As Label
    Friend WithEvents lblwrong10 As Label
    Friend WithEvents lblwrong8 As Label
    Friend WithEvents lblwrong7 As Label
    Friend WithEvents lblwrong9 As Label
    Friend WithEvents lblwrong12 As Label
    Friend WithEvents lblwrong11 As Label
    Friend WithEvents lblwrong13 As Label
    Friend WithEvents lblwrong14 As Label
    Friend WithEvents lblright1 As Label
    Friend WithEvents lblright2 As Label
    Friend WithEvents lblright4 As Label
    Friend WithEvents lblright3 As Label
    Friend WithEvents lblright5 As Label
    Friend WithEvents lblright6 As Label
    Friend WithEvents lblright7 As Label
    Friend WithEvents lblright8 As Label
    Friend WithEvents lblright10 As Label
    Friend WithEvents lblright9 As Label
    Friend WithEvents lblright11 As Label
    Friend WithEvents lblright12 As Label
    Friend WithEvents lblright13 As Label
    Friend WithEvents lblright14 As Label
    Friend WithEvents lblright15 As Label
    Friend WithEvents lblright16 As Label
    Friend WithEvents lblright17 As Label
    Friend WithEvents lblright18 As Label
    Friend WithEvents lblright19 As Label
    Friend WithEvents lblwrong25 As Label
    Friend WithEvents lblright20 As Label
    Friend WithEvents lblright21 As Label
    Friend WithEvents lblwrong20 As Label
    Friend WithEvents lblwrong21 As Label
    Friend WithEvents lblwrong22 As Label
    Friend WithEvents lblwrong24 As Label
    Friend WithEvents lblwrong26 As Label
    Friend WithEvents lblwrong27 As Label
    Friend WithEvents lblwrong28 As Label
    Friend WithEvents lblwrong29 As Label
    Friend WithEvents lblwrong30 As Label
    Friend WithEvents lblwrong34 As Label
    Friend WithEvents lblwrong33 As Label
    Friend WithEvents lblwrong31 As Label
    Friend WithEvents lblwrong35 As Label
    Friend WithEvents lblwrong36 As Label
    Friend WithEvents lblwrong38 As Label
    Friend WithEvents lblwrong39 As Label
    Friend WithEvents lblwrong40 As Label
    Friend WithEvents lblwrong41 As Label
End Class
