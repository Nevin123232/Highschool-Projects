﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmlevel1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmlevel1))
        Me.pbolevel1win = New System.Windows.Forms.PictureBox()
        Me.lblright1 = New System.Windows.Forms.Label()
        Me.lblright6 = New System.Windows.Forms.Label()
        Me.lblright4 = New System.Windows.Forms.Label()
        Me.lblright7 = New System.Windows.Forms.Label()
        Me.lblright8 = New System.Windows.Forms.Label()
        Me.lblright9 = New System.Windows.Forms.Label()
        Me.lblright5 = New System.Windows.Forms.Label()
        Me.lblright3 = New System.Windows.Forms.Label()
        Me.lblright2 = New System.Windows.Forms.Label()
        Me.lblright10 = New System.Windows.Forms.Label()
        Me.lblwrong2 = New System.Windows.Forms.Label()
        Me.lblwrong1 = New System.Windows.Forms.Label()
        Me.lblwrong3 = New System.Windows.Forms.Label()
        Me.lblwrong4 = New System.Windows.Forms.Label()
        Me.lblwrong6 = New System.Windows.Forms.Label()
        Me.lblwrong5 = New System.Windows.Forms.Label()
        Me.lblwrong7 = New System.Windows.Forms.Label()
        Me.lblwrong8 = New System.Windows.Forms.Label()
        Me.lblwrong9 = New System.Windows.Forms.Label()
        Me.lblwrong10 = New System.Windows.Forms.Label()
        Me.lblwrong11 = New System.Windows.Forms.Label()
        CType(Me.pbolevel1win, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pbolevel1win
        '
        Me.pbolevel1win.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbolevel1win.Image = CType(resources.GetObject("pbolevel1win.Image"), System.Drawing.Image)
        Me.pbolevel1win.Location = New System.Drawing.Point(767, 206)
        Me.pbolevel1win.Name = "pbolevel1win"
        Me.pbolevel1win.Size = New System.Drawing.Size(248, 224)
        Me.pbolevel1win.TabIndex = 4
        Me.pbolevel1win.TabStop = False
        '
        'lblright1
        '
        Me.lblright1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright1.Location = New System.Drawing.Point(388, 346)
        Me.lblright1.Name = "lblright1"
        Me.lblright1.Size = New System.Drawing.Size(171, 44)
        Me.lblright1.TabIndex = 5
        '
        'lblright6
        '
        Me.lblright6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright6.Location = New System.Drawing.Point(707, 438)
        Me.lblright6.Name = "lblright6"
        Me.lblright6.Size = New System.Drawing.Size(28, 138)
        Me.lblright6.TabIndex = 6
        '
        'lblright4
        '
        Me.lblright4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright4.Location = New System.Drawing.Point(527, 96)
        Me.lblright4.Name = "lblright4"
        Me.lblright4.Size = New System.Drawing.Size(32, 260)
        Me.lblright4.TabIndex = 7
        '
        'lblright7
        '
        Me.lblright7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright7.Location = New System.Drawing.Point(577, 236)
        Me.lblright7.Name = "lblright7"
        Me.lblright7.Size = New System.Drawing.Size(98, 15)
        Me.lblright7.TabIndex = 8
        '
        'lblright8
        '
        Me.lblright8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright8.Location = New System.Drawing.Point(527, 96)
        Me.lblright8.Name = "lblright8"
        Me.lblright8.Size = New System.Drawing.Size(159, 21)
        Me.lblright8.TabIndex = 9
        '
        'lblright9
        '
        Me.lblright9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright9.Location = New System.Drawing.Point(577, 438)
        Me.lblright9.Name = "lblright9"
        Me.lblright9.Size = New System.Drawing.Size(158, 19)
        Me.lblright9.TabIndex = 10
        '
        'lblright5
        '
        Me.lblright5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright5.Location = New System.Drawing.Point(577, 236)
        Me.lblright5.Name = "lblright5"
        Me.lblright5.Size = New System.Drawing.Size(19, 213)
        Me.lblright5.TabIndex = 11
        '
        'lblright3
        '
        Me.lblright3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright3.Location = New System.Drawing.Point(660, 96)
        Me.lblright3.Name = "lblright3"
        Me.lblright3.Size = New System.Drawing.Size(26, 155)
        Me.lblright3.TabIndex = 12
        '
        'lblright2
        '
        Me.lblright2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright2.Location = New System.Drawing.Point(969, 415)
        Me.lblright2.Name = "lblright2"
        Me.lblright2.Size = New System.Drawing.Size(34, 161)
        Me.lblright2.TabIndex = 13
        '
        'lblright10
        '
        Me.lblright10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright10.Location = New System.Drawing.Point(717, 555)
        Me.lblright10.Name = "lblright10"
        Me.lblright10.Size = New System.Drawing.Size(279, 21)
        Me.lblright10.TabIndex = 14
        '
        'lblwrong2
        '
        Me.lblwrong2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong2.Location = New System.Drawing.Point(388, 29)
        Me.lblwrong2.Name = "lblwrong2"
        Me.lblwrong2.Size = New System.Drawing.Size(142, 317)
        Me.lblwrong2.TabIndex = 15
        '
        'lblwrong1
        '
        Me.lblwrong1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong1.Location = New System.Drawing.Point(388, 390)
        Me.lblwrong1.Name = "lblwrong1"
        Me.lblwrong1.Size = New System.Drawing.Size(171, 224)
        Me.lblwrong1.TabIndex = 16
        '
        'lblwrong3
        '
        Me.lblwrong3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong3.Location = New System.Drawing.Point(527, 29)
        Me.lblwrong3.Name = "lblwrong3"
        Me.lblwrong3.Size = New System.Drawing.Size(498, 67)
        Me.lblwrong3.TabIndex = 17
        '
        'lblwrong4
        '
        Me.lblwrong4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong4.Location = New System.Drawing.Point(558, 78)
        Me.lblwrong4.Name = "lblwrong4"
        Me.lblwrong4.Size = New System.Drawing.Size(105, 379)
        Me.lblwrong4.TabIndex = 18
        '
        'lblwrong6
        '
        Me.lblwrong6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong6.Location = New System.Drawing.Point(679, 55)
        Me.lblwrong6.Name = "lblwrong6"
        Me.lblwrong6.Size = New System.Drawing.Size(346, 156)
        Me.lblwrong6.TabIndex = 19
        '
        'lblwrong5
        '
        Me.lblwrong5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong5.Location = New System.Drawing.Point(577, 251)
        Me.lblwrong5.Name = "lblwrong5"
        Me.lblwrong5.Size = New System.Drawing.Size(210, 187)
        Me.lblwrong5.TabIndex = 20
        '
        'lblwrong7
        '
        Me.lblwrong7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong7.Location = New System.Drawing.Point(679, 198)
        Me.lblwrong7.Name = "lblwrong7"
        Me.lblwrong7.Size = New System.Drawing.Size(108, 53)
        Me.lblwrong7.TabIndex = 21
        '
        'lblwrong8
        '
        Me.lblwrong8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong8.Location = New System.Drawing.Point(732, 433)
        Me.lblwrong8.Name = "lblwrong8"
        Me.lblwrong8.Size = New System.Drawing.Size(241, 122)
        Me.lblwrong8.TabIndex = 22
        '
        'lblwrong9
        '
        Me.lblwrong9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong9.Location = New System.Drawing.Point(558, 576)
        Me.lblwrong9.Name = "lblwrong9"
        Me.lblwrong9.Size = New System.Drawing.Size(476, 38)
        Me.lblwrong9.TabIndex = 23
        '
        'lblwrong10
        '
        Me.lblwrong10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong10.Location = New System.Drawing.Point(547, 453)
        Me.lblwrong10.Name = "lblwrong10"
        Me.lblwrong10.Size = New System.Drawing.Size(164, 123)
        Me.lblwrong10.TabIndex = 24
        '
        'lblwrong11
        '
        Me.lblwrong11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong11.Location = New System.Drawing.Point(1002, 198)
        Me.lblwrong11.Name = "lblwrong11"
        Me.lblwrong11.Size = New System.Drawing.Size(23, 378)
        Me.lblwrong11.TabIndex = 25
        '
        'frmlevel1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1130, 617)
        Me.Controls.Add(Me.lblright9)
        Me.Controls.Add(Me.lblright7)
        Me.Controls.Add(Me.lblright5)
        Me.Controls.Add(Me.lblright8)
        Me.Controls.Add(Me.lblwrong11)
        Me.Controls.Add(Me.lblwrong10)
        Me.Controls.Add(Me.lblwrong9)
        Me.Controls.Add(Me.lblwrong8)
        Me.Controls.Add(Me.lblwrong7)
        Me.Controls.Add(Me.lblwrong5)
        Me.Controls.Add(Me.lblwrong6)
        Me.Controls.Add(Me.lblwrong4)
        Me.Controls.Add(Me.lblwrong3)
        Me.Controls.Add(Me.lblwrong1)
        Me.Controls.Add(Me.lblwrong2)
        Me.Controls.Add(Me.lblright10)
        Me.Controls.Add(Me.lblright2)
        Me.Controls.Add(Me.lblright3)
        Me.Controls.Add(Me.lblright4)
        Me.Controls.Add(Me.lblright6)
        Me.Controls.Add(Me.lblright1)
        Me.Controls.Add(Me.pbolevel1win)
        Me.Name = "frmlevel1"
        Me.Text = "Level1"
        CType(Me.pbolevel1win, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents pbolevel1win As PictureBox
    Friend WithEvents lblright1 As Label
    Friend WithEvents lblright6 As Label
    Friend WithEvents lblright4 As Label
    Friend WithEvents lblright7 As Label
    Friend WithEvents lblright8 As Label
    Friend WithEvents lblright9 As Label
    Friend WithEvents lblright5 As Label
    Friend WithEvents lblright3 As Label
    Friend WithEvents lblright2 As Label
    Friend WithEvents lblright10 As Label
    Friend WithEvents lblwrong2 As Label
    Friend WithEvents lblwrong1 As Label
    Friend WithEvents lblwrong3 As Label
    Friend WithEvents lblwrong4 As Label
    Friend WithEvents lblwrong6 As Label
    Friend WithEvents lblwrong5 As Label
    Friend WithEvents lblwrong7 As Label
    Friend WithEvents lblwrong8 As Label
    Friend WithEvents lblwrong9 As Label
    Friend WithEvents lblwrong10 As Label
    Friend WithEvents lblwrong11 As Label
End Class
