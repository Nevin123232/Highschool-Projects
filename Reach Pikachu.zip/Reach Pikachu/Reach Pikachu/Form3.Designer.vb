﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmlevel2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmlevel2))
        Me.lblwrong2 = New System.Windows.Forms.Label()
        Me.lblright1 = New System.Windows.Forms.Label()
        Me.pboright = New System.Windows.Forms.PictureBox()
        Me.pbowrong1 = New System.Windows.Forms.PictureBox()
        Me.pboditto = New System.Windows.Forms.PictureBox()
        Me.lblwrong1 = New System.Windows.Forms.Label()
        Me.lblwrong3 = New System.Windows.Forms.Label()
        Me.lblright2 = New System.Windows.Forms.Label()
        Me.lblright4 = New System.Windows.Forms.Label()
        Me.lblright5 = New System.Windows.Forms.Label()
        Me.lblright6 = New System.Windows.Forms.Label()
        Me.lblright7 = New System.Windows.Forms.Label()
        Me.lblright8 = New System.Windows.Forms.Label()
        Me.lblright9 = New System.Windows.Forms.Label()
        Me.lblwrong4 = New System.Windows.Forms.Label()
        Me.lblwrong5 = New System.Windows.Forms.Label()
        Me.lblwrong6 = New System.Windows.Forms.Label()
        Me.lblwrong7 = New System.Windows.Forms.Label()
        Me.lblwrong8 = New System.Windows.Forms.Label()
        Me.lblwrong9 = New System.Windows.Forms.Label()
        Me.lblwrong10 = New System.Windows.Forms.Label()
        Me.lblwrong11 = New System.Windows.Forms.Label()
        Me.lblwrong12 = New System.Windows.Forms.Label()
        Me.lblrip1 = New System.Windows.Forms.Label()
        Me.lblrip2 = New System.Windows.Forms.Label()
        CType(Me.pboright, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbowrong1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pboditto, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblwrong2
        '
        Me.lblwrong2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong2.Location = New System.Drawing.Point(486, 35)
        Me.lblwrong2.Name = "lblwrong2"
        Me.lblwrong2.Size = New System.Drawing.Size(540, 264)
        Me.lblwrong2.TabIndex = 0
        '
        'lblright1
        '
        Me.lblright1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright1.Location = New System.Drawing.Point(462, 202)
        Me.lblright1.Name = "lblright1"
        Me.lblright1.Size = New System.Drawing.Size(589, 189)
        Me.lblright1.TabIndex = 1
        '
        'pboright
        '
        Me.pboright.Image = CType(resources.GetObject("pboright.Image"), System.Drawing.Image)
        Me.pboright.Location = New System.Drawing.Point(190, 89)
        Me.pboright.Name = "pboright"
        Me.pboright.Size = New System.Drawing.Size(223, 194)
        Me.pboright.TabIndex = 2
        Me.pboright.TabStop = False
        '
        'pbowrong1
        '
        Me.pbowrong1.Image = CType(resources.GetObject("pbowrong1.Image"), System.Drawing.Image)
        Me.pbowrong1.Location = New System.Drawing.Point(190, 331)
        Me.pbowrong1.Name = "pbowrong1"
        Me.pbowrong1.Size = New System.Drawing.Size(223, 211)
        Me.pbowrong1.TabIndex = 3
        Me.pbowrong1.TabStop = False
        '
        'pboditto
        '
        Me.pboditto.Image = CType(resources.GetObject("pboditto.Image"), System.Drawing.Image)
        Me.pboditto.Location = New System.Drawing.Point(190, 339)
        Me.pboditto.Name = "pboditto"
        Me.pboditto.Size = New System.Drawing.Size(226, 211)
        Me.pboditto.TabIndex = 4
        Me.pboditto.TabStop = False
        Me.pboditto.Visible = False
        '
        'lblwrong1
        '
        Me.lblwrong1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong1.Location = New System.Drawing.Point(1022, 35)
        Me.lblwrong1.Name = "lblwrong1"
        Me.lblwrong1.Size = New System.Drawing.Size(29, 556)
        Me.lblwrong1.TabIndex = 5
        '
        'lblwrong3
        '
        Me.lblwrong3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong3.Location = New System.Drawing.Point(486, 327)
        Me.lblwrong3.Name = "lblwrong3"
        Me.lblwrong3.Size = New System.Drawing.Size(540, 264)
        Me.lblwrong3.TabIndex = 6
        '
        'lblright2
        '
        Me.lblright2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright2.Location = New System.Drawing.Point(462, 57)
        Me.lblright2.Name = "lblright2"
        Me.lblright2.Size = New System.Drawing.Size(26, 510)
        Me.lblright2.TabIndex = 7
        '
        'lblright4
        '
        Me.lblright4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright4.Location = New System.Drawing.Point(114, 35)
        Me.lblright4.Name = "lblright4"
        Me.lblright4.Size = New System.Drawing.Size(374, 37)
        Me.lblright4.TabIndex = 8
        '
        'lblright5
        '
        Me.lblright5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright5.Location = New System.Drawing.Point(114, 32)
        Me.lblright5.Name = "lblright5"
        Me.lblright5.Size = New System.Drawing.Size(31, 241)
        Me.lblright5.TabIndex = 9
        '
        'lblright6
        '
        Me.lblright6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright6.Location = New System.Drawing.Point(132, 241)
        Me.lblright6.Name = "lblright6"
        Me.lblright6.Size = New System.Drawing.Size(62, 32)
        Me.lblright6.TabIndex = 10
        '
        'lblright7
        '
        Me.lblright7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright7.Location = New System.Drawing.Point(114, 545)
        Me.lblright7.Name = "lblright7"
        Me.lblright7.Size = New System.Drawing.Size(374, 46)
        Me.lblright7.TabIndex = 11
        '
        'lblright8
        '
        Me.lblright8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright8.Location = New System.Drawing.Point(114, 331)
        Me.lblright8.Name = "lblright8"
        Me.lblright8.Size = New System.Drawing.Size(31, 236)
        Me.lblright8.TabIndex = 12
        '
        'lblright9
        '
        Me.lblright9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright9.Location = New System.Drawing.Point(114, 331)
        Me.lblright9.Name = "lblright9"
        Me.lblright9.Size = New System.Drawing.Size(87, 32)
        Me.lblright9.TabIndex = 13
        '
        'lblwrong4
        '
        Me.lblwrong4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong4.Location = New System.Drawing.Point(114, 273)
        Me.lblwrong4.Name = "lblwrong4"
        Me.lblwrong4.Size = New System.Drawing.Size(353, 66)
        Me.lblwrong4.TabIndex = 14
        '
        'lblwrong5
        '
        Me.lblwrong5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong5.Location = New System.Drawing.Point(405, 72)
        Me.lblwrong5.Name = "lblwrong5"
        Me.lblwrong5.Size = New System.Drawing.Size(62, 201)
        Me.lblwrong5.TabIndex = 15
        '
        'lblwrong6
        '
        Me.lblwrong6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong6.Location = New System.Drawing.Point(405, 339)
        Me.lblwrong6.Name = "lblwrong6"
        Me.lblwrong6.Size = New System.Drawing.Size(62, 197)
        Me.lblwrong6.TabIndex = 16
        '
        'lblwrong7
        '
        Me.lblwrong7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong7.Location = New System.Drawing.Point(139, 363)
        Me.lblwrong7.Name = "lblwrong7"
        Me.lblwrong7.Size = New System.Drawing.Size(62, 173)
        Me.lblwrong7.TabIndex = 17
        '
        'lblwrong8
        '
        Me.lblwrong8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong8.Location = New System.Drawing.Point(139, 72)
        Me.lblwrong8.Name = "lblwrong8"
        Me.lblwrong8.Size = New System.Drawing.Size(55, 175)
        Me.lblwrong8.TabIndex = 18
        '
        'lblwrong9
        '
        Me.lblwrong9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong9.Location = New System.Drawing.Point(31, -1)
        Me.lblwrong9.Name = "lblwrong9"
        Me.lblwrong9.Size = New System.Drawing.Size(86, 629)
        Me.lblwrong9.TabIndex = 19
        '
        'lblwrong10
        '
        Me.lblwrong10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong10.Location = New System.Drawing.Point(114, 591)
        Me.lblwrong10.Name = "lblwrong10"
        Me.lblwrong10.Size = New System.Drawing.Size(985, 42)
        Me.lblwrong10.TabIndex = 20
        '
        'lblwrong11
        '
        Me.lblwrong11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong11.Location = New System.Drawing.Point(1050, -1)
        Me.lblwrong11.Name = "lblwrong11"
        Me.lblwrong11.Size = New System.Drawing.Size(49, 592)
        Me.lblwrong11.TabIndex = 21
        '
        'lblwrong12
        '
        Me.lblwrong12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong12.Location = New System.Drawing.Point(114, -1)
        Me.lblwrong12.Name = "lblwrong12"
        Me.lblwrong12.Size = New System.Drawing.Size(937, 36)
        Me.lblwrong12.TabIndex = 22
        '
        'lblrip1
        '
        Me.lblrip1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblrip1.Location = New System.Drawing.Point(190, 72)
        Me.lblrip1.Name = "lblrip1"
        Me.lblrip1.Size = New System.Drawing.Size(223, 18)
        Me.lblrip1.TabIndex = 23
        '
        'lblrip2
        '
        Me.lblrip2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblrip2.Location = New System.Drawing.Point(139, 536)
        Me.lblrip2.Name = "lblrip2"
        Me.lblrip2.Size = New System.Drawing.Size(328, 22)
        Me.lblrip2.TabIndex = 24
        '
        'frmlevel2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1097, 630)
        Me.Controls.Add(Me.lblrip2)
        Me.Controls.Add(Me.lblrip1)
        Me.Controls.Add(Me.lblwrong12)
        Me.Controls.Add(Me.lblwrong11)
        Me.Controls.Add(Me.lblwrong10)
        Me.Controls.Add(Me.lblwrong9)
        Me.Controls.Add(Me.lblright1)
        Me.Controls.Add(Me.lblwrong8)
        Me.Controls.Add(Me.lblwrong7)
        Me.Controls.Add(Me.lblwrong6)
        Me.Controls.Add(Me.lblwrong5)
        Me.Controls.Add(Me.lblwrong4)
        Me.Controls.Add(Me.lblright9)
        Me.Controls.Add(Me.lblright8)
        Me.Controls.Add(Me.lblright7)
        Me.Controls.Add(Me.lblright6)
        Me.Controls.Add(Me.lblright5)
        Me.Controls.Add(Me.lblright4)
        Me.Controls.Add(Me.lblright2)
        Me.Controls.Add(Me.lblwrong3)
        Me.Controls.Add(Me.pboditto)
        Me.Controls.Add(Me.pbowrong1)
        Me.Controls.Add(Me.pboright)
        Me.Controls.Add(Me.lblwrong2)
        Me.Controls.Add(Me.lblwrong1)
        Me.Name = "frmlevel2"
        Me.Text = "Welcome to level 2 "
        CType(Me.pboright, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbowrong1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pboditto, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lblwrong2 As Label
    Friend WithEvents lblright1 As Label
    Friend WithEvents pboright As PictureBox
    Friend WithEvents pbowrong1 As PictureBox
    Friend WithEvents pboditto As PictureBox
    Friend WithEvents lblwrong1 As Label
    Friend WithEvents lblwrong3 As Label
    Friend WithEvents lblright2 As Label
    Friend WithEvents lblright4 As Label
    Friend WithEvents lblright5 As Label
    Friend WithEvents lblright6 As Label
    Friend WithEvents lblright7 As Label
    Friend WithEvents lblright8 As Label
    Friend WithEvents lblright9 As Label
    Friend WithEvents lblwrong4 As Label
    Friend WithEvents lblwrong5 As Label
    Friend WithEvents lblwrong6 As Label
    Friend WithEvents lblwrong7 As Label
    Friend WithEvents lblwrong8 As Label
    Friend WithEvents lblwrong9 As Label
    Friend WithEvents lblwrong10 As Label
    Friend WithEvents lblwrong11 As Label
    Friend WithEvents lblwrong12 As Label
    Friend WithEvents lblrip1 As Label
    Friend WithEvents lblrip2 As Label
End Class
