﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Frmintro
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Frmintro))
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblexample = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.btnstart = New System.Windows.Forms.Button()
        Me.pbozoroark = New System.Windows.Forms.PictureBox()
        Me.pboditto = New System.Windows.Forms.PictureBox()
        Me.pbozoroa = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label4 = New System.Windows.Forms.Label()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbozoroark, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pboditto, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbozoroa, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), System.Drawing.Image)
        Me.PictureBox4.Location = New System.Drawing.Point(478, 238)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(248, 224)
        Me.PictureBox4.TabIndex = 3
        Me.PictureBox4.TabStop = False
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(233, 55)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(584, 130)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "The job of the player is to control the mouse cursor and traverse through the maz" &
    "e provided. you may only touch the blue labels in order to reach the picture of " &
    "Pikachu. "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(-1, 195)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(463, 25)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "The labels that you're allowed to touch --->"
        '
        'lblexample
        '
        Me.lblexample.Location = New System.Drawing.Point(468, 185)
        Me.lblexample.Name = "lblexample"
        Me.lblexample.Size = New System.Drawing.Size(90, 40)
        Me.lblexample.TabIndex = 6
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(7, 257)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(465, 25)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "The picture of Pikachu that you must click----->"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!)
        Me.Label3.Location = New System.Drawing.Point(84, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(733, 39)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Welcome to the Reach Pikachu maze game!! :) "
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Button1.Location = New System.Drawing.Point(27, 414)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(128, 66)
        Me.Button1.TabIndex = 10
        Me.Button1.Text = "E&xit this game  "
        Me.Button1.UseVisualStyleBackColor = True
        '
        'btnstart
        '
        Me.btnstart.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.btnstart.Location = New System.Drawing.Point(12, 319)
        Me.btnstart.Name = "btnstart"
        Me.btnstart.Size = New System.Drawing.Size(128, 69)
        Me.btnstart.TabIndex = 11
        Me.btnstart.Text = "&Start Playing "
        Me.btnstart.UseVisualStyleBackColor = True
        '
        'pbozoroark
        '
        Me.pbozoroark.Image = CType(resources.GetObject("pbozoroark.Image"), System.Drawing.Image)
        Me.pbozoroark.Location = New System.Drawing.Point(810, 13)
        Me.pbozoroark.Name = "pbozoroark"
        Me.pbozoroark.Size = New System.Drawing.Size(236, 212)
        Me.pbozoroark.TabIndex = 12
        Me.pbozoroark.TabStop = False
        Me.pbozoroark.Visible = False
        '
        'pboditto
        '
        Me.pboditto.Image = CType(resources.GetObject("pboditto.Image"), System.Drawing.Image)
        Me.pboditto.Location = New System.Drawing.Point(27, -4)
        Me.pboditto.Name = "pboditto"
        Me.pboditto.Size = New System.Drawing.Size(200, 196)
        Me.pboditto.TabIndex = 13
        Me.pboditto.TabStop = False
        Me.pboditto.Visible = False
        '
        'pbozoroa
        '
        Me.pbozoroa.Image = CType(resources.GetObject("pbozoroa.Image"), System.Drawing.Image)
        Me.pbozoroa.Location = New System.Drawing.Point(216, 309)
        Me.pbozoroa.Name = "pbozoroa"
        Me.pbozoroa.Size = New System.Drawing.Size(199, 190)
        Me.pbozoroa.TabIndex = 14
        Me.pbozoroa.TabStop = False
        Me.pbozoroa.Visible = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(774, 291)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(250, 208)
        Me.PictureBox1.TabIndex = 15
        Me.PictureBox1.TabStop = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(509, 489)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(217, 13)
        Me.Label4.TabIndex = 16
        Me.Label4.Text = "Try interacting with pictures on this form..... ;)"
        '
        'Frmintro
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1058, 511)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.pboditto)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.pbozoroa)
        Me.Controls.Add(Me.pbozoroark)
        Me.Controls.Add(Me.btnstart)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.lblexample)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox4)
        Me.Name = "Frmintro"
        Me.Text = "Welcome to the Reach Pikachu maze game."
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbozoroark, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pboditto, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbozoroa, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblexample As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents btnstart As Button
    Friend WithEvents pbozoroark As PictureBox
    Friend WithEvents pboditto As PictureBox
    Friend WithEvents pbozoroa As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label4 As Label
End Class
