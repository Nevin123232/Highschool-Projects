﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmlevel4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmlevel4))
        Me.lblright1 = New System.Windows.Forms.Label()
        Me.lblwrong1 = New System.Windows.Forms.Label()
        Me.pbozoroa = New System.Windows.Forms.PictureBox()
        Me.pborightpikachu = New System.Windows.Forms.PictureBox()
        Me.pbozoroark = New System.Windows.Forms.PictureBox()
        Me.pboditto = New System.Windows.Forms.PictureBox()
        Me.lblwrong4 = New System.Windows.Forms.Label()
        Me.lblwrong3 = New System.Windows.Forms.Label()
        Me.lblwrong2 = New System.Windows.Forms.Label()
        Me.lblwrong6 = New System.Windows.Forms.Label()
        Me.lblwrong7 = New System.Windows.Forms.Label()
        Me.lblwrong5 = New System.Windows.Forms.Label()
        Me.lblwrong8 = New System.Windows.Forms.Label()
        Me.lblwrong10 = New System.Windows.Forms.Label()
        Me.lblwrong12 = New System.Windows.Forms.Label()
        Me.lblwrong15 = New System.Windows.Forms.Label()
        Me.lblwrong14 = New System.Windows.Forms.Label()
        Me.lblwrong16 = New System.Windows.Forms.Label()
        Me.lblwrong13 = New System.Windows.Forms.Label()
        Me.lblwrong9 = New System.Windows.Forms.Label()
        Me.lblwrong11 = New System.Windows.Forms.Label()
        Me.lblright2 = New System.Windows.Forms.Label()
        Me.lblright3 = New System.Windows.Forms.Label()
        Me.lblright4 = New System.Windows.Forms.Label()
        Me.lblright5 = New System.Windows.Forms.Label()
        Me.lblright6 = New System.Windows.Forms.Label()
        Me.lblright11 = New System.Windows.Forms.Label()
        Me.lblright10 = New System.Windows.Forms.Label()
        Me.lblright9 = New System.Windows.Forms.Label()
        Me.lblright8 = New System.Windows.Forms.Label()
        Me.lblright7 = New System.Windows.Forms.Label()
        Me.lblright14 = New System.Windows.Forms.Label()
        Me.lblright12 = New System.Windows.Forms.Label()
        Me.lblright13 = New System.Windows.Forms.Label()
        Me.lblright15 = New System.Windows.Forms.Label()
        Me.lblright17 = New System.Windows.Forms.Label()
        Me.lblright16 = New System.Windows.Forms.Label()
        Me.lblright18 = New System.Windows.Forms.Label()
        Me.lblright19 = New System.Windows.Forms.Label()
        Me.lblright20 = New System.Windows.Forms.Label()
        Me.lblright22 = New System.Windows.Forms.Label()
        Me.lblright23 = New System.Windows.Forms.Label()
        Me.lblright24 = New System.Windows.Forms.Label()
        Me.lblright25 = New System.Windows.Forms.Label()
        Me.lblright21 = New System.Windows.Forms.Label()
        Me.lblright29 = New System.Windows.Forms.Label()
        Me.lblright30 = New System.Windows.Forms.Label()
        Me.lblright27 = New System.Windows.Forms.Label()
        Me.lblright28 = New System.Windows.Forms.Label()
        Me.lblright26 = New System.Windows.Forms.Label()
        Me.pbofakepikazoroark = New System.Windows.Forms.PictureBox()
        Me.pbofakepikaditto = New System.Windows.Forms.PictureBox()
        Me.pbofakepikazoroa = New System.Windows.Forms.PictureBox()
        Me.lblwrong17 = New System.Windows.Forms.Label()
        CType(Me.pbozoroa, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pborightpikachu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbozoroark, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pboditto, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbofakepikazoroark, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbofakepikaditto, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbofakepikazoroa, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblright1
        '
        Me.lblright1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright1.Location = New System.Drawing.Point(568, 329)
        Me.lblright1.Name = "lblright1"
        Me.lblright1.Size = New System.Drawing.Size(258, 142)
        Me.lblright1.TabIndex = 0
        '
        'lblwrong1
        '
        Me.lblwrong1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong1.Location = New System.Drawing.Point(22, 539)
        Me.lblwrong1.Name = "lblwrong1"
        Me.lblwrong1.Size = New System.Drawing.Size(225, 31)
        Me.lblwrong1.TabIndex = 1
        '
        'pbozoroa
        '
        Me.pbozoroa.Image = CType(resources.GetObject("pbozoroa.Image"), System.Drawing.Image)
        Me.pbozoroa.Location = New System.Drawing.Point(30, 558)
        Me.pbozoroa.Name = "pbozoroa"
        Me.pbozoroa.Size = New System.Drawing.Size(206, 179)
        Me.pbozoroa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbozoroa.TabIndex = 2
        Me.pbozoroa.TabStop = False
        '
        'pborightpikachu
        '
        Me.pborightpikachu.Image = CType(resources.GetObject("pborightpikachu.Image"), System.Drawing.Image)
        Me.pborightpikachu.Location = New System.Drawing.Point(1108, 558)
        Me.pborightpikachu.Name = "pborightpikachu"
        Me.pborightpikachu.Size = New System.Drawing.Size(206, 179)
        Me.pborightpikachu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pborightpikachu.TabIndex = 3
        Me.pborightpikachu.TabStop = False
        '
        'pbozoroark
        '
        Me.pbozoroark.Image = CType(resources.GetObject("pbozoroark.Image"), System.Drawing.Image)
        Me.pbozoroark.Location = New System.Drawing.Point(30, 12)
        Me.pbozoroark.Name = "pbozoroark"
        Me.pbozoroark.Size = New System.Drawing.Size(206, 170)
        Me.pbozoroark.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbozoroark.TabIndex = 4
        Me.pbozoroark.TabStop = False
        '
        'pboditto
        '
        Me.pboditto.Image = CType(resources.GetObject("pboditto.Image"), System.Drawing.Image)
        Me.pboditto.Location = New System.Drawing.Point(1108, 21)
        Me.pboditto.Name = "pboditto"
        Me.pboditto.Size = New System.Drawing.Size(206, 170)
        Me.pboditto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pboditto.TabIndex = 5
        Me.pboditto.TabStop = False
        '
        'lblwrong4
        '
        Me.lblwrong4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong4.Location = New System.Drawing.Point(3, 539)
        Me.lblwrong4.Name = "lblwrong4"
        Me.lblwrong4.Size = New System.Drawing.Size(31, 212)
        Me.lblwrong4.TabIndex = 6
        '
        'lblwrong3
        '
        Me.lblwrong3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong3.Location = New System.Drawing.Point(22, 727)
        Me.lblwrong3.Name = "lblwrong3"
        Me.lblwrong3.Size = New System.Drawing.Size(214, 24)
        Me.lblwrong3.TabIndex = 7
        '
        'lblwrong2
        '
        Me.lblwrong2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong2.Location = New System.Drawing.Point(230, 619)
        Me.lblwrong2.Name = "lblwrong2"
        Me.lblwrong2.Size = New System.Drawing.Size(26, 132)
        Me.lblwrong2.TabIndex = 8
        '
        'lblwrong6
        '
        Me.lblwrong6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong6.Location = New System.Drawing.Point(1300, 539)
        Me.lblwrong6.Name = "lblwrong6"
        Me.lblwrong6.Size = New System.Drawing.Size(24, 212)
        Me.lblwrong6.TabIndex = 9
        '
        'lblwrong7
        '
        Me.lblwrong7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong7.Location = New System.Drawing.Point(1095, 601)
        Me.lblwrong7.Name = "lblwrong7"
        Me.lblwrong7.Size = New System.Drawing.Size(18, 144)
        Me.lblwrong7.TabIndex = 10
        '
        'lblwrong5
        '
        Me.lblwrong5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong5.Location = New System.Drawing.Point(1095, 539)
        Me.lblwrong5.Name = "lblwrong5"
        Me.lblwrong5.Size = New System.Drawing.Size(224, 21)
        Me.lblwrong5.TabIndex = 11
        '
        'lblwrong8
        '
        Me.lblwrong8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong8.Location = New System.Drawing.Point(1095, 727)
        Me.lblwrong8.Name = "lblwrong8"
        Me.lblwrong8.Size = New System.Drawing.Size(229, 24)
        Me.lblwrong8.TabIndex = 12
        '
        'lblwrong10
        '
        Me.lblwrong10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong10.Location = New System.Drawing.Point(1089, 185)
        Me.lblwrong10.Name = "lblwrong10"
        Me.lblwrong10.Size = New System.Drawing.Size(235, 21)
        Me.lblwrong10.TabIndex = 13
        '
        'lblwrong12
        '
        Me.lblwrong12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong12.Location = New System.Drawing.Point(1089, 9)
        Me.lblwrong12.Name = "lblwrong12"
        Me.lblwrong12.Size = New System.Drawing.Size(235, 21)
        Me.lblwrong12.TabIndex = 14
        '
        'lblwrong15
        '
        Me.lblwrong15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong15.Location = New System.Drawing.Point(12, 9)
        Me.lblwrong15.Name = "lblwrong15"
        Me.lblwrong15.Size = New System.Drawing.Size(244, 21)
        Me.lblwrong15.TabIndex = 15
        '
        'lblwrong14
        '
        Me.lblwrong14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong14.Location = New System.Drawing.Point(12, 181)
        Me.lblwrong14.Name = "lblwrong14"
        Me.lblwrong14.Size = New System.Drawing.Size(244, 25)
        Me.lblwrong14.TabIndex = 16
        '
        'lblwrong16
        '
        Me.lblwrong16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong16.Location = New System.Drawing.Point(12, 9)
        Me.lblwrong16.Name = "lblwrong16"
        Me.lblwrong16.Size = New System.Drawing.Size(22, 182)
        Me.lblwrong16.TabIndex = 17
        '
        'lblwrong13
        '
        Me.lblwrong13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong13.Location = New System.Drawing.Point(234, 77)
        Me.lblwrong13.Name = "lblwrong13"
        Me.lblwrong13.Size = New System.Drawing.Size(22, 129)
        Me.lblwrong13.TabIndex = 18
        '
        'lblwrong9
        '
        Me.lblwrong9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong9.Location = New System.Drawing.Point(1091, 77)
        Me.lblwrong9.Name = "lblwrong9"
        Me.lblwrong9.Size = New System.Drawing.Size(22, 129)
        Me.lblwrong9.TabIndex = 19
        '
        'lblwrong11
        '
        Me.lblwrong11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong11.Location = New System.Drawing.Point(1302, 12)
        Me.lblwrong11.Name = "lblwrong11"
        Me.lblwrong11.Size = New System.Drawing.Size(22, 194)
        Me.lblwrong11.TabIndex = 20
        '
        'lblright2
        '
        Me.lblright2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright2.Location = New System.Drawing.Point(814, 360)
        Me.lblright2.Name = "lblright2"
        Me.lblright2.Size = New System.Drawing.Size(258, 33)
        Me.lblright2.TabIndex = 21
        '
        'lblright3
        '
        Me.lblright3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright3.Location = New System.Drawing.Point(592, 181)
        Me.lblright3.Name = "lblright3"
        Me.lblright3.Size = New System.Drawing.Size(234, 32)
        Me.lblright3.TabIndex = 22
        '
        'lblright4
        '
        Me.lblright4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright4.Location = New System.Drawing.Point(814, 181)
        Me.lblright4.Name = "lblright4"
        Me.lblright4.Size = New System.Drawing.Size(258, 24)
        Me.lblright4.TabIndex = 23
        '
        'lblright5
        '
        Me.lblright5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright5.Location = New System.Drawing.Point(1041, 185)
        Me.lblright5.Name = "lblright5"
        Me.lblright5.Size = New System.Drawing.Size(31, 209)
        Me.lblright5.TabIndex = 24
        '
        'lblright6
        '
        Me.lblright6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright6.Location = New System.Drawing.Point(1065, 30)
        Me.lblright6.Name = "lblright6"
        Me.lblright6.Size = New System.Drawing.Size(48, 64)
        Me.lblright6.TabIndex = 25
        '
        'lblright11
        '
        Me.lblright11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright11.Location = New System.Drawing.Point(592, 117)
        Me.lblright11.Name = "lblright11"
        Me.lblright11.Size = New System.Drawing.Size(27, 96)
        Me.lblright11.TabIndex = 26
        '
        'lblright10
        '
        Me.lblright10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright10.Location = New System.Drawing.Point(45, 382)
        Me.lblright10.Name = "lblright10"
        Me.lblright10.Size = New System.Drawing.Size(544, 30)
        Me.lblright10.TabIndex = 27
        '
        'lblright9
        '
        Me.lblright9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright9.Location = New System.Drawing.Point(827, 68)
        Me.lblright9.Name = "lblright9"
        Me.lblright9.Size = New System.Drawing.Size(258, 26)
        Me.lblright9.TabIndex = 28
        '
        'lblright8
        '
        Me.lblright8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright8.Location = New System.Drawing.Point(824, 77)
        Me.lblright8.Name = "lblright8"
        Me.lblright8.Size = New System.Drawing.Size(26, 46)
        Me.lblright8.TabIndex = 29
        '
        'lblright7
        '
        Me.lblright7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright7.Location = New System.Drawing.Point(592, 117)
        Me.lblright7.Name = "lblright7"
        Me.lblright7.Size = New System.Drawing.Size(258, 28)
        Me.lblright7.TabIndex = 30
        '
        'lblright14
        '
        Me.lblright14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright14.Location = New System.Drawing.Point(30, 485)
        Me.lblright14.Name = "lblright14"
        Me.lblright14.Size = New System.Drawing.Size(382, 30)
        Me.lblright14.TabIndex = 31
        '
        'lblright12
        '
        Me.lblright12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright12.Location = New System.Drawing.Point(30, 229)
        Me.lblright12.Name = "lblright12"
        Me.lblright12.Size = New System.Drawing.Size(382, 30)
        Me.lblright12.TabIndex = 32
        '
        'lblright13
        '
        Me.lblright13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright13.Location = New System.Drawing.Point(30, 239)
        Me.lblright13.Name = "lblright13"
        Me.lblright13.Size = New System.Drawing.Size(27, 276)
        Me.lblright13.TabIndex = 33
        '
        'lblright15
        '
        Me.lblright15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright15.Location = New System.Drawing.Point(399, 154)
        Me.lblright15.Name = "lblright15"
        Me.lblright15.Size = New System.Drawing.Size(24, 106)
        Me.lblright15.TabIndex = 34
        '
        'lblright17
        '
        Me.lblright17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright17.Location = New System.Drawing.Point(406, 485)
        Me.lblright17.Name = "lblright17"
        Me.lblright17.Size = New System.Drawing.Size(32, 230)
        Me.lblright17.TabIndex = 35
        '
        'lblright16
        '
        Me.lblright16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright16.Location = New System.Drawing.Point(267, 689)
        Me.lblright16.Name = "lblright16"
        Me.lblright16.Size = New System.Drawing.Size(145, 26)
        Me.lblright16.TabIndex = 36
        '
        'lblright18
        '
        Me.lblright18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright18.Location = New System.Drawing.Point(234, 30)
        Me.lblright18.Name = "lblright18"
        Me.lblright18.Size = New System.Drawing.Size(75, 50)
        Me.lblright18.TabIndex = 37
        '
        'lblright19
        '
        Me.lblright19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright19.Location = New System.Drawing.Point(299, 46)
        Me.lblright19.Name = "lblright19"
        Me.lblright19.Size = New System.Drawing.Size(30, 136)
        Me.lblright19.TabIndex = 38
        '
        'lblright20
        '
        Me.lblright20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright20.Location = New System.Drawing.Point(299, 154)
        Me.lblright20.Name = "lblright20"
        Me.lblright20.Size = New System.Drawing.Size(113, 28)
        Me.lblright20.TabIndex = 39
        '
        'lblright22
        '
        Me.lblright22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright22.Location = New System.Drawing.Point(499, 606)
        Me.lblright22.Name = "lblright22"
        Me.lblright22.Size = New System.Drawing.Size(448, 26)
        Me.lblright22.TabIndex = 40
        '
        'lblright23
        '
        Me.lblright23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright23.Location = New System.Drawing.Point(230, 570)
        Me.lblright23.Name = "lblright23"
        Me.lblright23.Size = New System.Drawing.Size(64, 49)
        Me.lblright23.TabIndex = 41
        '
        'lblright24
        '
        Me.lblright24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright24.Location = New System.Drawing.Point(499, 534)
        Me.lblright24.Name = "lblright24"
        Me.lblright24.Size = New System.Drawing.Size(21, 96)
        Me.lblright24.TabIndex = 42
        '
        'lblright25
        '
        Me.lblright25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright25.Location = New System.Drawing.Point(927, 676)
        Me.lblright25.Name = "lblright25"
        Me.lblright25.Size = New System.Drawing.Size(145, 26)
        Me.lblright25.TabIndex = 43
        '
        'lblright21
        '
        Me.lblright21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright21.Location = New System.Drawing.Point(253, 606)
        Me.lblright21.Name = "lblright21"
        Me.lblright21.Size = New System.Drawing.Size(38, 109)
        Me.lblright21.TabIndex = 44
        '
        'lblright29
        '
        Me.lblright29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright29.Location = New System.Drawing.Point(929, 435)
        Me.lblright29.Name = "lblright29"
        Me.lblright29.Size = New System.Drawing.Size(30, 125)
        Me.lblright29.TabIndex = 45
        '
        'lblright30
        '
        Me.lblright30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright30.Location = New System.Drawing.Point(814, 435)
        Me.lblright30.Name = "lblright30"
        Me.lblright30.Size = New System.Drawing.Size(145, 26)
        Me.lblright30.TabIndex = 46
        '
        'lblright27
        '
        Me.lblright27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright27.Location = New System.Drawing.Point(929, 606)
        Me.lblright27.Name = "lblright27"
        Me.lblright27.Size = New System.Drawing.Size(37, 96)
        Me.lblright27.TabIndex = 47
        '
        'lblright28
        '
        Me.lblright28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright28.Location = New System.Drawing.Point(499, 534)
        Me.lblright28.Name = "lblright28"
        Me.lblright28.Size = New System.Drawing.Size(460, 26)
        Me.lblright28.TabIndex = 48
        '
        'lblright26
        '
        Me.lblright26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright26.Location = New System.Drawing.Point(1065, 539)
        Me.lblright26.Name = "lblright26"
        Me.lblright26.Size = New System.Drawing.Size(48, 163)
        Me.lblright26.TabIndex = 49
        '
        'pbofakepikazoroark
        '
        Me.pbofakepikazoroark.Image = CType(resources.GetObject("pbofakepikazoroark.Image"), System.Drawing.Image)
        Me.pbofakepikazoroark.Location = New System.Drawing.Point(30, 30)
        Me.pbofakepikazoroark.Name = "pbofakepikazoroark"
        Me.pbofakepikazoroark.Size = New System.Drawing.Size(206, 152)
        Me.pbofakepikazoroark.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbofakepikazoroark.TabIndex = 50
        Me.pbofakepikazoroark.TabStop = False
        '
        'pbofakepikaditto
        '
        Me.pbofakepikaditto.Image = CType(resources.GetObject("pbofakepikaditto.Image"), System.Drawing.Image)
        Me.pbofakepikaditto.Location = New System.Drawing.Point(1108, 30)
        Me.pbofakepikaditto.Name = "pbofakepikaditto"
        Me.pbofakepikaditto.Size = New System.Drawing.Size(206, 161)
        Me.pbofakepikaditto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbofakepikaditto.TabIndex = 51
        Me.pbofakepikaditto.TabStop = False
        '
        'pbofakepikazoroa
        '
        Me.pbofakepikazoroa.Image = CType(resources.GetObject("pbofakepikazoroa.Image"), System.Drawing.Image)
        Me.pbofakepikazoroa.Location = New System.Drawing.Point(22, 558)
        Me.pbofakepikazoroa.Name = "pbofakepikazoroa"
        Me.pbofakepikazoroa.Size = New System.Drawing.Size(214, 179)
        Me.pbofakepikazoroa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbofakepikazoroa.TabIndex = 52
        Me.pbofakepikazoroa.TabStop = False
        '
        'lblwrong17
        '
        Me.lblwrong17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrong17.Location = New System.Drawing.Point(3, -3)
        Me.lblwrong17.Name = "lblwrong17"
        Me.lblwrong17.Size = New System.Drawing.Size(1321, 754)
        Me.lblwrong17.TabIndex = 53
        '
        'frmlevel4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1326, 749)
        Me.Controls.Add(Me.pbofakepikazoroa)
        Me.Controls.Add(Me.pbofakepikaditto)
        Me.Controls.Add(Me.pbofakepikazoroark)
        Me.Controls.Add(Me.lblright28)
        Me.Controls.Add(Me.lblright27)
        Me.Controls.Add(Me.lblright30)
        Me.Controls.Add(Me.lblright29)
        Me.Controls.Add(Me.lblright21)
        Me.Controls.Add(Me.lblright25)
        Me.Controls.Add(Me.lblright24)
        Me.Controls.Add(Me.lblright23)
        Me.Controls.Add(Me.lblright22)
        Me.Controls.Add(Me.lblright20)
        Me.Controls.Add(Me.lblright19)
        Me.Controls.Add(Me.lblright18)
        Me.Controls.Add(Me.lblright16)
        Me.Controls.Add(Me.lblright17)
        Me.Controls.Add(Me.lblright15)
        Me.Controls.Add(Me.lblright13)
        Me.Controls.Add(Me.lblright12)
        Me.Controls.Add(Me.lblright14)
        Me.Controls.Add(Me.lblright7)
        Me.Controls.Add(Me.lblright8)
        Me.Controls.Add(Me.lblright9)
        Me.Controls.Add(Me.lblright10)
        Me.Controls.Add(Me.lblright11)
        Me.Controls.Add(Me.lblright6)
        Me.Controls.Add(Me.lblright5)
        Me.Controls.Add(Me.lblright4)
        Me.Controls.Add(Me.lblright3)
        Me.Controls.Add(Me.lblright2)
        Me.Controls.Add(Me.lblwrong11)
        Me.Controls.Add(Me.lblwrong9)
        Me.Controls.Add(Me.lblwrong13)
        Me.Controls.Add(Me.lblwrong16)
        Me.Controls.Add(Me.lblwrong14)
        Me.Controls.Add(Me.lblwrong15)
        Me.Controls.Add(Me.lblwrong12)
        Me.Controls.Add(Me.lblwrong10)
        Me.Controls.Add(Me.lblwrong8)
        Me.Controls.Add(Me.lblwrong5)
        Me.Controls.Add(Me.lblwrong7)
        Me.Controls.Add(Me.lblwrong6)
        Me.Controls.Add(Me.lblwrong2)
        Me.Controls.Add(Me.lblwrong3)
        Me.Controls.Add(Me.lblwrong4)
        Me.Controls.Add(Me.pboditto)
        Me.Controls.Add(Me.pbozoroark)
        Me.Controls.Add(Me.pborightpikachu)
        Me.Controls.Add(Me.pbozoroa)
        Me.Controls.Add(Me.lblwrong1)
        Me.Controls.Add(Me.lblright1)
        Me.Controls.Add(Me.lblright26)
        Me.Controls.Add(Me.lblwrong17)
        Me.Name = "frmlevel4"
        Me.Text = "Welcome to level 4 "
        CType(Me.pbozoroa, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pborightpikachu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbozoroark, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pboditto, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbofakepikazoroark, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbofakepikaditto, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbofakepikazoroa, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lblright1 As Label
    Friend WithEvents lblwrong1 As Label
    Friend WithEvents pbozoroa As PictureBox
    Friend WithEvents pborightpikachu As PictureBox
    Friend WithEvents pbozoroark As PictureBox
    Friend WithEvents pboditto As PictureBox
    Friend WithEvents lblwrong4 As Label
    Friend WithEvents lblwrong3 As Label
    Friend WithEvents lblwrong2 As Label
    Friend WithEvents lblwrong6 As Label
    Friend WithEvents lblwrong7 As Label
    Friend WithEvents lblwrong5 As Label
    Friend WithEvents lblwrong8 As Label
    Friend WithEvents lblwrong10 As Label
    Friend WithEvents lblwrong12 As Label
    Friend WithEvents lblwrong15 As Label
    Friend WithEvents lblwrong14 As Label
    Friend WithEvents lblwrong16 As Label
    Friend WithEvents lblwrong13 As Label
    Friend WithEvents lblwrong9 As Label
    Friend WithEvents lblwrong11 As Label
    Friend WithEvents lblright2 As Label
    Friend WithEvents lblright3 As Label
    Friend WithEvents lblright4 As Label
    Friend WithEvents lblright5 As Label
    Friend WithEvents lblright6 As Label
    Friend WithEvents lblright11 As Label
    Friend WithEvents lblright10 As Label
    Friend WithEvents lblright9 As Label
    Friend WithEvents lblright8 As Label
    Friend WithEvents lblright7 As Label
    Friend WithEvents lblright14 As Label
    Friend WithEvents lblright12 As Label
    Friend WithEvents lblright13 As Label
    Friend WithEvents lblright15 As Label
    Friend WithEvents lblright17 As Label
    Friend WithEvents lblright16 As Label
    Friend WithEvents lblright18 As Label
    Friend WithEvents lblright19 As Label
    Friend WithEvents lblright20 As Label
    Friend WithEvents lblright22 As Label
    Friend WithEvents lblright23 As Label
    Friend WithEvents lblright24 As Label
    Friend WithEvents lblright25 As Label
    Friend WithEvents lblright21 As Label
    Friend WithEvents lblright29 As Label
    Friend WithEvents lblright30 As Label
    Friend WithEvents lblright27 As Label
    Friend WithEvents lblright28 As Label
    Friend WithEvents lblright26 As Label
    Friend WithEvents pbofakepikazoroark As PictureBox
    Friend WithEvents pbofakepikaditto As PictureBox
    Friend WithEvents pbofakepikazoroa As PictureBox
    Friend WithEvents lblwrong17 As Label
End Class
