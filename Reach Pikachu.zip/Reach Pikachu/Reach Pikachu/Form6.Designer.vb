﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmlevel5
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmlevel5))
        Me.lblwrongx = New System.Windows.Forms.Label()
        Me.lblrightx = New System.Windows.Forms.Label()
        Me.lblrighty = New System.Windows.Forms.Label()
        Me.lblright3 = New System.Windows.Forms.Label()
        Me.lblright1 = New System.Windows.Forms.Label()
        Me.lblright4 = New System.Windows.Forms.Label()
        Me.lblright2 = New System.Windows.Forms.Label()
        Me.lblright5 = New System.Windows.Forms.Label()
        Me.lblright6 = New System.Windows.Forms.Label()
        Me.lblright7 = New System.Windows.Forms.Label()
        Me.lblright8 = New System.Windows.Forms.Label()
        Me.lblright9 = New System.Windows.Forms.Label()
        Me.lblright10 = New System.Windows.Forms.Label()
        Me.pbofakepikachuditto = New System.Windows.Forms.PictureBox()
        Me.pbofakepikachuzoroa = New System.Windows.Forms.PictureBox()
        Me.pbofakepikachumimikyu = New System.Windows.Forms.PictureBox()
        Me.pbofakepikachuzoroark = New System.Windows.Forms.PictureBox()
        Me.pborealpikachu = New System.Windows.Forms.PictureBox()
        Me.pbozoroark = New System.Windows.Forms.PictureBox()
        Me.pbozoroa = New System.Windows.Forms.PictureBox()
        Me.pboditto = New System.Windows.Forms.PictureBox()
        Me.pbomimikyu = New System.Windows.Forms.PictureBox()
        CType(Me.pbofakepikachuditto, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbofakepikachuzoroa, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbofakepikachumimikyu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbofakepikachuzoroark, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pborealpikachu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbozoroark, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbozoroa, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pboditto, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbomimikyu, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblwrongx
        '
        Me.lblwrongx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwrongx.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblwrongx.Location = New System.Drawing.Point(-22, 9)
        Me.lblwrongx.Name = "lblwrongx"
        Me.lblwrongx.Size = New System.Drawing.Size(1155, 686)
        Me.lblwrongx.TabIndex = 0
        '
        'lblrightx
        '
        Me.lblrightx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblrightx.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblrightx.Location = New System.Drawing.Point(531, 190)
        Me.lblrightx.Name = "lblrightx"
        Me.lblrightx.Size = New System.Drawing.Size(359, 280)
        Me.lblrightx.TabIndex = 1
        '
        'lblrighty
        '
        Me.lblrighty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblrighty.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblrighty.Location = New System.Drawing.Point(191, 303)
        Me.lblrighty.Name = "lblrighty"
        Me.lblrighty.Size = New System.Drawing.Size(359, 16)
        Me.lblrighty.TabIndex = 2
        '
        'lblright3
        '
        Me.lblright3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblright3.Location = New System.Drawing.Point(42, 303)
        Me.lblright3.Name = "lblright3"
        Me.lblright3.Size = New System.Drawing.Size(359, 16)
        Me.lblright3.TabIndex = 3
        '
        'lblright1
        '
        Me.lblright1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblright1.Location = New System.Drawing.Point(42, 31)
        Me.lblright1.Name = "lblright1"
        Me.lblright1.Size = New System.Drawing.Size(17, 625)
        Me.lblright1.TabIndex = 4
        '
        'lblright4
        '
        Me.lblright4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblright4.Location = New System.Drawing.Point(42, 31)
        Me.lblright4.Name = "lblright4"
        Me.lblright4.Size = New System.Drawing.Size(1091, 21)
        Me.lblright4.TabIndex = 5
        '
        'lblright2
        '
        Me.lblright2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblright2.Location = New System.Drawing.Point(42, 638)
        Me.lblright2.Name = "lblright2"
        Me.lblright2.Size = New System.Drawing.Size(1091, 18)
        Me.lblright2.TabIndex = 6
        '
        'lblright5
        '
        Me.lblright5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblright5.Location = New System.Drawing.Point(341, 31)
        Me.lblright5.Name = "lblright5"
        Me.lblright5.Size = New System.Drawing.Size(34, 81)
        Me.lblright5.TabIndex = 7
        '
        'lblright6
        '
        Me.lblright6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblright6.Location = New System.Drawing.Point(261, 552)
        Me.lblright6.Name = "lblright6"
        Me.lblright6.Size = New System.Drawing.Size(28, 104)
        Me.lblright6.TabIndex = 8
        '
        'lblright7
        '
        Me.lblright7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblright7.Location = New System.Drawing.Point(993, 592)
        Me.lblright7.Name = "lblright7"
        Me.lblright7.Size = New System.Drawing.Size(33, 64)
        Me.lblright7.TabIndex = 9
        '
        'lblright8
        '
        Me.lblright8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblright8.Location = New System.Drawing.Point(1012, 31)
        Me.lblright8.Name = "lblright8"
        Me.lblright8.Size = New System.Drawing.Size(32, 89)
        Me.lblright8.TabIndex = 10
        '
        'lblright9
        '
        Me.lblright9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblright9.Location = New System.Drawing.Point(1117, 31)
        Me.lblright9.Name = "lblright9"
        Me.lblright9.Size = New System.Drawing.Size(16, 625)
        Me.lblright9.TabIndex = 11
        '
        'lblright10
        '
        Me.lblright10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblright10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblright10.Location = New System.Drawing.Point(1062, 345)
        Me.lblright10.Name = "lblright10"
        Me.lblright10.Size = New System.Drawing.Size(71, 25)
        Me.lblright10.TabIndex = 12
        '
        'pbofakepikachuditto
        '
        Me.pbofakepikachuditto.Image = CType(resources.GetObject("pbofakepikachuditto.Image"), System.Drawing.Image)
        Me.pbofakepikachuditto.Location = New System.Drawing.Point(896, 447)
        Me.pbofakepikachuditto.Name = "pbofakepikachuditto"
        Me.pbofakepikachuditto.Size = New System.Drawing.Size(201, 178)
        Me.pbofakepikachuditto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbofakepikachuditto.TabIndex = 13
        Me.pbofakepikachuditto.TabStop = False
        '
        'pbofakepikachuzoroa
        '
        Me.pbofakepikachuzoroa.Image = CType(resources.GetObject("pbofakepikachuzoroa.Image"), System.Drawing.Image)
        Me.pbofakepikachuzoroa.Location = New System.Drawing.Point(908, 246)
        Me.pbofakepikachuzoroa.Name = "pbofakepikachuzoroa"
        Me.pbofakepikachuzoroa.Size = New System.Drawing.Size(163, 181)
        Me.pbofakepikachuzoroa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbofakepikachuzoroa.TabIndex = 14
        Me.pbofakepikachuzoroa.TabStop = False
        '
        'pbofakepikachumimikyu
        '
        Me.pbofakepikachumimikyu.Image = CType(resources.GetObject("pbofakepikachumimikyu.Image"), System.Drawing.Image)
        Me.pbofakepikachumimikyu.Location = New System.Drawing.Point(191, 404)
        Me.pbofakepikachumimikyu.Name = "pbofakepikachumimikyu"
        Me.pbofakepikachumimikyu.Size = New System.Drawing.Size(210, 194)
        Me.pbofakepikachumimikyu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbofakepikachumimikyu.TabIndex = 15
        Me.pbofakepikachumimikyu.TabStop = False
        '
        'pbofakepikachuzoroark
        '
        Me.pbofakepikachuzoroark.Image = CType(resources.GetObject("pbofakepikachuzoroark.Image"), System.Drawing.Image)
        Me.pbofakepikachuzoroark.Location = New System.Drawing.Point(935, 62)
        Me.pbofakepikachuzoroark.Name = "pbofakepikachuzoroark"
        Me.pbofakepikachuzoroark.Size = New System.Drawing.Size(162, 172)
        Me.pbofakepikachuzoroark.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbofakepikachuzoroark.TabIndex = 16
        Me.pbofakepikachuzoroark.TabStop = False
        '
        'pborealpikachu
        '
        Me.pborealpikachu.Image = CType(resources.GetObject("pborealpikachu.Image"), System.Drawing.Image)
        Me.pborealpikachu.Location = New System.Drawing.Point(280, 78)
        Me.pborealpikachu.Name = "pborealpikachu"
        Me.pborealpikachu.Size = New System.Drawing.Size(171, 162)
        Me.pborealpikachu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pborealpikachu.TabIndex = 17
        Me.pborealpikachu.TabStop = False
        '
        'pbozoroark
        '
        Me.pbozoroark.Image = CType(resources.GetObject("pbozoroark.Image"), System.Drawing.Image)
        Me.pbozoroark.Location = New System.Drawing.Point(935, 62)
        Me.pbozoroark.Name = "pbozoroark"
        Me.pbozoroark.Size = New System.Drawing.Size(162, 172)
        Me.pbozoroark.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbozoroark.TabIndex = 19
        Me.pbozoroark.TabStop = False
        Me.pbozoroark.Visible = False
        '
        'pbozoroa
        '
        Me.pbozoroa.Image = CType(resources.GetObject("pbozoroa.Image"), System.Drawing.Image)
        Me.pbozoroa.Location = New System.Drawing.Point(908, 246)
        Me.pbozoroa.Name = "pbozoroa"
        Me.pbozoroa.Size = New System.Drawing.Size(163, 181)
        Me.pbozoroa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbozoroa.TabIndex = 20
        Me.pbozoroa.TabStop = False
        Me.pbozoroa.Visible = False
        '
        'pboditto
        '
        Me.pboditto.Image = CType(resources.GetObject("pboditto.Image"), System.Drawing.Image)
        Me.pboditto.Location = New System.Drawing.Point(896, 447)
        Me.pboditto.Name = "pboditto"
        Me.pboditto.Size = New System.Drawing.Size(201, 178)
        Me.pboditto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pboditto.TabIndex = 21
        Me.pboditto.TabStop = False
        Me.pboditto.Visible = False
        '
        'pbomimikyu
        '
        Me.pbomimikyu.Image = CType(resources.GetObject("pbomimikyu.Image"), System.Drawing.Image)
        Me.pbomimikyu.Location = New System.Drawing.Point(194, 404)
        Me.pbomimikyu.Name = "pbomimikyu"
        Me.pbomimikyu.Size = New System.Drawing.Size(210, 194)
        Me.pbomimikyu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbomimikyu.TabIndex = 22
        Me.pbomimikyu.TabStop = False
        Me.pbomimikyu.Visible = False
        '
        'frmlevel5
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1145, 681)
        Me.Controls.Add(Me.pbomimikyu)
        Me.Controls.Add(Me.pboditto)
        Me.Controls.Add(Me.pbozoroa)
        Me.Controls.Add(Me.pbozoroark)
        Me.Controls.Add(Me.pborealpikachu)
        Me.Controls.Add(Me.pbofakepikachuzoroark)
        Me.Controls.Add(Me.pbofakepikachumimikyu)
        Me.Controls.Add(Me.pbofakepikachuzoroa)
        Me.Controls.Add(Me.pbofakepikachuditto)
        Me.Controls.Add(Me.lblright10)
        Me.Controls.Add(Me.lblright9)
        Me.Controls.Add(Me.lblright8)
        Me.Controls.Add(Me.lblright7)
        Me.Controls.Add(Me.lblright6)
        Me.Controls.Add(Me.lblright5)
        Me.Controls.Add(Me.lblright2)
        Me.Controls.Add(Me.lblright4)
        Me.Controls.Add(Me.lblright1)
        Me.Controls.Add(Me.lblright3)
        Me.Controls.Add(Me.lblrighty)
        Me.Controls.Add(Me.lblrightx)
        Me.Controls.Add(Me.lblwrongx)
        Me.Name = "frmlevel5"
        Me.Text = "Welcome to Level 5"
        CType(Me.pbofakepikachuditto, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbofakepikachuzoroa, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbofakepikachumimikyu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbofakepikachuzoroark, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pborealpikachu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbozoroark, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbozoroa, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pboditto, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbomimikyu, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lblwrongx As Label
    Friend WithEvents lblrightx As Label
    Friend WithEvents lblrighty As Label
    Friend WithEvents lblright3 As Label
    Friend WithEvents lblright1 As Label
    Friend WithEvents lblright4 As Label
    Friend WithEvents lblright2 As Label
    Friend WithEvents lblright5 As Label
    Friend WithEvents lblright6 As Label
    Friend WithEvents lblright7 As Label
    Friend WithEvents lblright8 As Label
    Friend WithEvents lblright9 As Label
    Friend WithEvents lblright10 As Label
    Friend WithEvents pbofakepikachuditto As PictureBox
    Friend WithEvents pbofakepikachuzoroa As PictureBox
    Friend WithEvents pbofakepikachumimikyu As PictureBox
    Friend WithEvents pbofakepikachuzoroark As PictureBox
    Friend WithEvents pborealpikachu As PictureBox
    Friend WithEvents pbozoroark As PictureBox
    Friend WithEvents pbozoroa As PictureBox
    Friend WithEvents pboditto As PictureBox
    Friend WithEvents pbomimikyu As PictureBox
End Class
