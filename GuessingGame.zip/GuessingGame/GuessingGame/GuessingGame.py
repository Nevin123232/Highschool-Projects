#Guessing Game by Nevin Ndonwi

import random #imports required elements for random

#global variable declaration

prevcat = 0 #category value of previous guess
prevdiff = 0 # difference of previous guess from actual number 

def getGuess():
   
    #method to return user guess (1-100 or 0)'
    guess = -1

    while guess < 0 or guess > 100:
        try:
            guess = int(input("Guess? (1-100,0=quit): "))
            if guess < 0 or guess > 100:
                print("Guess must be 1-100 or 0 to quit.")
        except ValueError:
            print("Illegal input: only numbers from 1 to 100\n")

    return guess



def showHotCold(rnum,guess):
    #show response to user (hot,cold, warm)


    global prevcat, prevdiff


    print("Wrong\n")
    diff = abs(rnum - guess) #gets positive value of difference of rnum and guess
    category = 0 # categories will be 1 = cold, 2 = warm, 3 = very warm, 4 = hot
    if diff >= 60:
        category = 1
        msg = "cold"
    elif diff>= 30:
        category = 2
        msg = "warm"
    elif diff>= 16:
        category = 3
        msg = "very warm"
    else:
        category = 4
        msg = "HOT"
    

        


    if category == prevcat:
        if diff == prevdiff:
           msg += " (same degree)"
        elif diff > prevdiff:
            msg += " (getting colder)"
        else:
            if category == 4: #if the user is in the hot range then display getting hotter not getting warmer
               msg += " (getting HOTTER)"
            else:
               msg += " (getting warmer)"

           

    print("Your guess is " + msg)
    prevcat = category # previous category is now from latest guess (update it)
    prevdiff = diff




def playHotCold(rnum):
    print("Time to play Hot-Cold\n")
    gcount = 0 #amount of time the user guesses
    playing = True

    while playing: 
        guess = getGuess()
        gcount +=1 #increase guess by 1
        if guess == 0:
            print("Sorry, you did not guess my number which was: ", rnum, "in", gcount - 1, "tries.")
            playing = False
        elif guess == rnum:
            print("You guessed the number in", gcount , "tries!!!\n")
            playing = False
        else:
            showHotCold(rnum,guess)
            playing = True
       

#end playhotcold




def showhighlow(rnum,guess):
   
    #compares rnum to guess and outputs the result accordingly
    if(guess > rnum):
        print("Your guess is too high")
    elif(guess < rnum ):
        print("Your guess is too low")
   




def playHighLow(rnum):
    print("Time to play High-Low\n")
      
    gcount = 0 #amount of time the user guesses
    playing = True

    while playing: 
        guess = getGuess()
        gcount +=1 #increase guess by 1
        if guess == 0:
            print("Sorry, you did not guess my number which was: ", rnum, "in", gcount - 1, "tries.")
            playing = False
        elif guess == rnum:
            print("You guessed the number in", gcount , "tries!!!\n")
            playing = False
        else:
            showhighlow(rnum,guess)
            playing = True
       

#end playhighlow



def getChoice():
    goodVal = False
    #This function returns a good value of 0, 1 or 2
    while not goodVal:
        try:
            choice = int(input("Game type: 1=Hot/Cold, 2=High/Low, 0=Quit: \n"))
            if choice < 0 or choice > 2:
                print("Unknown selection: 0, 1, or 2 only.\n")
            else:
                goodVal = True
        except ValueError:
            print("Illegal input: integers from 0 to 2 only.")
            goodVal = False


    return choice

def main():
    print("Welcome to the guessing game\n")

    gametype = getChoice()

    while gametype != 0:
        rnum = random.randint(1,100) #random number

        print("I am thinking of a random number between 1 and 100....")

        if gametype == 1:
            playHotCold(rnum) #play hot cold version
        elif gametype == 2:
            playHighLow(rnum)
        else:
            print("Unknown Operation\n")


        gametype = getChoice()
     
    print("Thanks for playing!!!!!\n")



if __name__ == "__main__":
    main()
