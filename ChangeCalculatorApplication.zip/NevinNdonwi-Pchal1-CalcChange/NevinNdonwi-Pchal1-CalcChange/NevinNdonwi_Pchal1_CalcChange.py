

#change calculator program
 
#getCoin method

def getCoin(change): 
    
    
    coinListnum =  [50,25,10,5,1] # list of values of the coins based on the placement of the coin names 

    x = 0 
     
    coinList = ["Half-Dollars", "Quarters", "Dimes", "Nickels", "Pennies" ] #list of coins 

   

    while x < 5: 
        

        num = input("How many " + coinList[x] + " do you have? \n") 

        try: #try exception block to check illegal inputs 
            if num.isnumeric(): #checks if the number is a non negative integer/ if it is actually a number 
                change += int(num)* coinListnum[x]
                x +=1 
            else:
                 print("Input must be a non-negative integer. Please re-enter.\n")

        except ValueError:
            print("Illegal input: must be a non-negative integer")
            num = input("How many " + coinList[x] + " do you have? \n") 



    return change 


   
    


print("\nWelcome to the Change Calculator.\n")    #intro line

total = 0

choice = input("\nDo you have any change? (y/n)\n") #Asks if the user has any change (takes in string)



while choice[0].lower() == "y": #makes any phrase or input starting with an uppercase or lowercase y acceptable to the program (Choice[0] checks the first character)


    print("\nYour answer was: " + choice + ' (equilvilant to yes)\n') #outputs result to user

    change = 0 # initialize change variable 

    change = getCoin(change)

    print("You have " + str(change) + " cents.\n")
    print("Which is " + str(change//100) + " dollars and " + str(change % 100) + " cents.\n")

    total += change
    
    choice = input("\nDo you have more change? (y/n)\n")  #Asks if the user has any more change (takes in string)
    print()


print("\nThank you for using this change calculator!\n")

print("You had a total of ", total, " cents.")

if total != 0:
    print("Which is ", total // 100, " dollars and ", total %100, " cents.\n")







