// Ch10-P-chal-1-Nevin-Ndonwi.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

using namespace std;

// Programming Challenge 1 page 715


void sort(double* arr, int size)
{
    for (int y = 0; y < size; y++) {

        for (int z = y + 1; z < size; z++) {

            if ( *(arr+z) < *(arr+y)  ) {

                double temp = *(arr + y);
                *(arr + y) = *(arr + z);
                *(arr + z) = temp;
              
                
            }
        }

    }


    for (int x = 0; x < size; x++) {

        cout << arr[x] << "\n";
    }

}

void average(double* arr, int size)
{
    double total = 0;

    for (int a = 0; a < size; a++) {

        total += *(arr + a);
    }


    double average = (double) total / (double)size;

    cout << average << "\n";
}
int main()
{
    cout << "Input how many test scores you have:\n";
    int amount;
    cin >> amount;
    cout << "\nYou are going to input " << amount << " test score(s):\n";

    double *scores = new double[amount];

    int x = 0;
    double temp;
    while (x < amount) {

        cout << "Input a test score:\n";

        bool val = false;

        while (!val) {


            cin >> temp;
            if (temp < 0) {

                cout << "\nNo negative numbers allowed\n";
            }
            else {

                scores[x] = temp;
                val = true;
            }
        }
       
        x++;
    }


    cout << "\nAll scores have been inputted.\n";

    cout << "\n\nHere is the list of scores(unsorted) :\n\n";

    for (int x = 0; x < amount; x++) {

        cout << scores[x] << "\n";
    }



    cout << "\n\nHere is the list of scores(sorted) :\n\n";

    sort(scores, amount);

  
    cout << "\n\nHere is the average:\n\n";
    average(scores, amount);



    delete[] scores;

    system("pause");

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
