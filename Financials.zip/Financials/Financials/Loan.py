#Loan Class
from math import *

class Loan:
    """ Loan Calculator """
    def __init__(self,a = 0.0,r = 0.0,t= 0):
        #complete constructor to store the starting values in private variables, check validity, build if okay,
             #create 'private' variables for class values
        self.setAmt(a)
        self.setRate(r)
        self.setTerm(t)
        self._error = ""

        if self.isValid():
            self.buildLoan()

 #self and get methods 'encapsulate' data values 

    def setAmt(self, value):
        self._amt = value

    def getAmt(self):
        return self._amt

    def setRate(self,value):
        self._rate = value

    def getRate(self):
        return self._rate

    def setTerm(self, value):
        self._term = value

    def getTerm(self):
        return self._term



    

    def isValid(self):
        valid = True

        if self._amt <= 0:
            self._error = "Amount must be positive.\n"
            valid = False 

        elif self._rate > 25 or self._rate < 1:
            self._error = "Rate out of bounds, Rate must be 1 to 25.\n"
            valid = False 

        elif self._term <= 0:
            self._error = "Term must be positive.\n"
            valid = False 

        return valid 

    def getError(self):
        return self._error

    
    def getLoanmo(self, mo): #gets the loan monthly payment 
        

        morate = self._rate /12/100 #converts yearly rate to monthly rate in fractional form

        part1 = pow((1+morate), (mo)) - 1

        part2 = morate/part1
    
        part3 = morate + part2

        part4 = part3 * self._amt
       

        mopay = part4 
        

        return mopay





           



    def buildLoan(self):
    
        #monthly payments calculation
        #calculate monthly rate
        #calculate the denomenator
        # (Loan formula: monthlypayment = (monthly rate + ((monthly rate)/(1 + rate) ^( months -1))^principAL
          #create all values needed for annuity schedule
        self._bbal = [0] * self._term #creates a list of size term storing begining balances
        self._intcharge =[0] * self._term #creates a list of size term storing money charged
        self._ebal = [0] * self._term #creates a list of size term storing end balance 
         


     

        morate = self._rate /12/100 #converts yearly rate to monthly rate in fractional form

        self._bbal[0] = self._amt #the first element of the begining balance is the starting amount 


        for i in range(1, self._term):
           
            self._intcharge[i-1] = (self._bbal[i-1]) *morate #interest charged in that month calculation
            self._ebal[i-1] = self._bbal[i-1] + self._intcharge[i-1] - self.getLoanmo(self._term) #end balance

            self._bbal[i] = self._bbal[i-1] + self._intcharge[i-1] - self.getLoanmo(self._term) #begining balance for next month


        self._intcharge[self._term-1] = (self._bbal[self._term-1]) *morate 
             


        
    def getEbal(self):
        return self._ebal[self._term-1]

    #interest = final value less total of deposits
    def getLoanInterest(self): #gets total interest of loan
        total =0
        for x in range (0, len(self._intcharge)):
            total = total + self._intcharge[x]

        return total

    def getLoanBbal(self, mo):
        # month that user requests  is assumed to be 1 (including term ) month 1 or 2 (not month 0) 
        return self._bbal[mo - 1]

    def getLoanInt(self,mo):
        return self._intcharge[mo - 1]

    def getLoanEbal(self,mo):
        return self._ebal[mo-1] 
