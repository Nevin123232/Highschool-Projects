#Annuity Logic file by Nevin Ndonwi



class Annuity:

    #constructor method for class
    def __init__(self, a = 0.0,r = 0.0,t = 0):

        #create 'private' variables for class values
        self.setAmt(a)
        self.setRate(r)
        self.setTerm(t)
        self._error = ""

        if self.isValid():
            self.buildAnnuity()



    #self and get methods 'encapsulate' data values 

    def setAmt(self, value):
        self._amt = value

    def getAmt(self):
        return self._amt

    def setRate(self,value):
        self._rate = value

    def getRate(self):
        return self._rate

    def setTerm(self, value):
        self._term = value

    def getTerm(self):
        return self._term





    def isValid(self):
        valid = True

        if self._amt <= 0:
            self._error = "Amount must be positive.\n"
            valid = False 

        elif self._rate > 25 or self._rate < 1:
            self._error = "Rate out of bounds, Rate must be 1 to 25.\n"
            valid = False 

        elif self._term <= 0:
            self._error = "Term must be positive.\n"
            valid = False 

        return valid 

    def getError(self):
        return self._error


    def buildAnnuity(self):
        #create all values needed for annuity schedule
        self._bbal = [0] * self._term #creates a list of size term storing begining balances
        self._intearn =[0] * self._term #creates a list of size term storing money earned
        self._ebal = [0] * self._term #creates a list of size term storing end balance 

        self._bbal[0] = 0

       

        morate = self._rate /12/100 #converts yearly rate to monthly rate in fractional form

        for i in range(0, self._term):
            if i > 0:
                self._bbal[i] = self._ebal[i-1]


            self._intearn[i] = (self._bbal[i] + self._amt) *morate #interest earned in that month calculation
            self._ebal[i] = (self._bbal[i] + self._amt) + self._intearn[i] #interest earned in that month calculation
            

    def getFVA(self):
        return self._ebal[self._term-1]

    #interest = final value less total of deposits
    def getFVAInterest(self):
        return (self._ebal[self._term-1]) - (self._amt * self._term) 

    def getFVABbal(self, mo):
        # month that user requests  is assumed to be 1 (including term ) month 1 or 2 (not month 0) 
        return self._bbal[mo - 1]

    def getFVAInt(self,mo):
        return self._intearn[mo - 1]

    def getFVAEbal(self,mo):
        return self._ebal[mo-1] 









