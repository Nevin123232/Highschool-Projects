#Financials by Nevin Ndonwi

import locale 
from Annuity import Annuity
from Loan import Loan


def getChoice():
    goodVal = False 
    while not goodVal:
        try:
            choice = int(input("Select Operation: 1 = Annuity, 2 = Loan, 0 = Quit:  \n"))
            if choice < 0 or choice > 2:
                print("Unknown Operation: input 1,2,0 only.\n")
            else:
                goodVal = True
        except ValueError:
            print("Illegal input: integers 0,1,2 only\n")
            goodVal = False
    return choice 


def getValue(prompt, vType):
    #(prompt) , i is integer, f is float 
    goodVal = False 
    while not goodVal:
#if we would like to return an integer
        if vType == "i":
          try:
            amount = int(input(prompt))
            goodVal = True 
          except ValueError as ex:
            print("Illegal Value: " + str(ex) + "\n")
            goodVal = False
           

#if we want to return a float 
        elif vType == "f":
    
            try:
                amount = float(input(prompt))
                goodVal = True 
            except ValueError as ex:
                  print("Illegal Value: " + str(ex) + "\n")
                  goodVal = False
       
        else:
            print("Unknown operation!\n")
  
 

    return amount 


def doAnnuity():
    
    amt = getValue("Input the Monthly Deposit:\n", "f")
    rate = getValue("Input the Annual Interest Rate(input 6 for 6%):\n", "f")
    term = getValue("Input the (term in months):\n", "i")
    ann = Annuity(amt,rate,term) #instantiation call, creates object based on class requirements

    if ann.isValid():
        print("The monthly deposit of %s" %locale.currency(amt,grouping = True) , 
              "earning"  ,"{:.2%}".format(ann.getRate()/100),
              "annually after", term, "months", "will have a",
             "final value of: %s"  % locale.currency(ann.getFVA(), grouping = True ))

        print("\nThat includes interest earned of %s" % locale.currency(ann.getFVAInterest(), grouping = True ), "\n")
        sched = input("Full Schedule(Y/N)?\n")

        if len(sched) > 0 and (sched[0].upper() == "Y") :
            print("Month    Beg.Bal       Deposit     Int.Earned      End.Bal.")

            for i in range(1, ann.getTerm() + 1):
                print( ("{:4}".format(i)) + 
                      "{:12,.2f} {:12,.2f} {:12,.2f} {:15,.2f}".format(ann.getFVABbal(i),ann.getAmt(), ann.getFVAInt(i), ann.getFVAEbal(i)  ))
        

    else:
        print("Annuity Error: " + ann.getError())






def doLoan():
    
    amt = getValue("Input the Loan Amount:\n", "f")
    rate = getValue("Input the Annual Interest Rate(input 6 for 6%):\n", "f")
    term = getValue("Input the (term in months):\n", "i")
    loan = Loan(amt,rate,term) #instantiation call, creates object based on class requirements

    if loan.isValid():
        print("A Loan of %s" %locale.currency(amt,grouping = True) , 
              "charging"  ,"{:.2%}".format(loan.getRate()/100),
              "annually after", term, "months", "will require a monthly payment",
             "of: %s"  % locale.currency(loan.getLoanmo(term), grouping = True ))

        print("\nThat includes interest earned of %s" % locale.currency(loan.getLoanInterest(), grouping = True ), "\n")
        sched = input("Full Schedule(Y/N)?\n")

        if len(sched) > 0 and (sched[0].upper() == "Y") :
            print("Month    Beg.Bal       Payment     Int.Charged      End.Bal.")

            for i in range(1, loan.getTerm() + 1):
                print( ("{:4}".format(i)) + 
                      "{:12,.2f} {:12,.2f} {:12,.2f} {:15,.2f}".format(loan.getLoanBbal(i),loan.getLoanmo(term), loan.getLoanInt(i), loan.getLoanEbal(i)  ))
        

    else:
        print("Loan Error: " + loan.getError())





def main():
    result = locale.setlocale(locale.LC_ALL, '')
    if result == "C" or result.startswith("C/"):
        localse.setlocale(locale.LC_ALL, 'en_US')

    print("Welcome to the Financials Calculator")

    choice = getChoice()

    while choice != 0:
        if choice == 1:
            doAnnuity()
        
        elif choice == 2:
            doLoan()

        else:
            print("Unknown or not implimented")

        choice = getChoice()
        print()


    print("Thank you for utilising the Calculator.\n") 



if __name__ == "__main__":
    main()

