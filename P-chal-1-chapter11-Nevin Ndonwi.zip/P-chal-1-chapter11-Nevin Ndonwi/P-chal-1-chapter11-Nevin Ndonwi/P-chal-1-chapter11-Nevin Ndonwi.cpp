// P-chal-1-chapter11-Nevin Ndonwi.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string> 

using namespace std;

//Chapter 11, Programming challenge 2 page 816

class DayOfYear {
    static string temp;
private:
    int day;

public:
    //constructor that takes the day of the year in an int
    DayOfYear(int d) {

        day = d;
    };
    //prints the day in a month-day format
    void print() {
        /* Normal years.  */
        int months[] = { 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365 };

        //month names
        string monthnames[] = { "January", "February", "March", "April", "May", "June", "July", "August",
        "September", "October", "November", "December" };

        int i = 0;

        while (months[i] < day) {

            ++i;
        }

        int output = abs(months[i - 1] - day);


        //converts input to string
        string s = to_string(output);

        //gets the month to string 
        string  t = monthnames[i - 1] + " ";


        //outputs the information
        cout << t << s <<"\n";

    }

};
int main()
{


    cout << "\nInput a day number of the year(1-365)(This also assumes that it ISN'T a leap year)\n";
    int input = 0;


    bool goodval = false;


    cin >> input;
    if ((input < 1) || (input > 365)) {
        goodval = false;

    }
    else {

        goodval = true;
    }



    while (!goodval) {
        cout << "\nYour previous input was invalid. Input a number (lowest is 1 highest is 365) \n";

        cin >> input;
        if ((input < 1) || (input > 365)) {
            goodval = false;

        }
        else {

            goodval = true;
        }



    }


    DayOfYear x = DayOfYear(input);

    cout << "You inputted day number: " << input << "\nThe date in month-day format is "; x.print();




    system("pause");



}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
