#Conversions Program by Nevin Ndonwi 
# Will use bubble up/ layered exception handeling 

#imports Conversions class from Converter
from Converter import Conversions


def getChoice():
    #use boolean variable for loop control..
    val = False
    while not val:
        try:
             c = int(input("Conversion? Input: (1 = Mi-to-Km), (2 = Oz-to-Gr), (3 = F-to-C), (4 = C-to-F), (5 = M-to-Ft), (6 = Li-to-Gal) (0 = end)\n"))
             if (c < 0 or c > 6):
                 #illegitimate input
                 print("Illegal input, (only 0,1,2,3,4,5, and 6 are valid inputs) Please try again\n")
                 
                 val = False
             else:
                 #legal input
                 val = True 

           

        except ValueError:
            print("Illegal input, (only 0,1,2,3,4,5, and 6 are valid inputs) Please try again\n")
           
            val = False

    #returns user input to the main function
    return c


def main():
    print("Welcome to the English-Metric Converter\n")

    #Remember to ask Kelvin y/n and set condition accordingly

    k = input("On Temp conversions, Would you like to see degrees kelvin (K) in the results? (Y/N):")

    while k != "Y" and k != "N" and k != "y" and k != "n":
        print("\nPlease input Y/N for this prompt")
        k = input("On Temp conversions, Would you like to see degrees kelvin (K) in the results? (Y/N):")


    kelvinincluded = True
    
    if k == "Y" or k == "y":
        kelvinincluded = True
    elif k == "N" and k == "n":
        kelvinincluded = False



  #declaring choice variable and assigning a value to the choice variable
    choice = getChoice()
    while choice != 0:

        #All need to be robust and handle exceptions 
      
        try:
            if choice == 1:
                #miles to Kilometers 
                mi = input("Enter your miles:\n")

                output = Conversions.MitoKm(mi) 
                print(output)

                #outputting the menu contents again
                choice = getChoice()

            elif choice == 2:
                #Oz to Gr  
                oz = input("Enter your ounces:\n")

                output = Conversions.OztoGr(oz)
                print(output)

                #outputting the menu contents again
                choice = getChoice()

            elif choice == 3:
                #Fahrenheit to Celsius 
                f = input("Enter your temperature in degrees Fahrenheit:\n")



                output = Conversions.FtoC(f,kelvinincluded)              
                print(output)


                #outputting the menu contents again
                choice = getChoice()

            elif choice == 4:
             #Celsius to Fahrenheit
                c = input("Enter your temperature in degrees Celsius:\n")

                
                output = Conversions.CtoF(c,kelvinincluded)              
                print(output)



                #outputting the menu contents again
                choice = getChoice()

            elif choice == 5:
             #Meters to Feet
                m = input("Enter your measurement in meters:\n")

                output = Conversions.MtoF(m)
                print(output)

                #outputting the menu contents again
                choice = getChoice()

            elif choice == 6:
             #Liters to Gallons
                l = input("Enter your liquid-measurement in liters:\n")

                output = Conversions.LitoGa(l)
                print(output)


                #outputting the menu contents again
                choice = getChoice()
            else:
                print("Unknown Operation")

                #outputting the menu contents again
                choice = getChoice()

        except ValueError as e:
            print("Data Error: " + str(e) + "\n")
            
            #outputting the menu contents again
            choice = getChoice()
        except Exception as ex:
            print("General Error: " + str(ex) + "\n")
            
            #outputting the menu contents again
            choice = getChoice()










    print("\nThank you for using this Converter Program")

if __name__ == "__main__":
    main()


