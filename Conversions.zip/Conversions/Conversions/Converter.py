#Converter methods/algorithms by Nevin Ndonwi



class Conversions:
    """ Conversion Algorithms """
    
    def MitoKm(mi): #Converts Miles to Kilometers


        #check miles variable to see if it is workable
        if not isinstance(mi,(int,float)):
            try:
                mi = float(mi) # convers mi to a float but is risky
            except ValueError:
                raise Exception( "Invalid Input, Unable to be Converted (Input must be numeric)" )
          
       
        if mi <= 0: #value is less than 0
            raise ValueError( "Invalid Input, Unable to be Converted (Input must be positive)" )


        #converts miles to kilometers
        km = mi * 1.60934

        km = "%.3f" % round(km, 3)

        output = str(mi) + " miles is " + str(km) + " kilometers\n"
        return output



    def OztoGr(oz): # Converts Ounces to Grams



        #check  variable to see if it is workable
        if not isinstance(oz,(int,float)):
            try:
                oz = float(oz) # convers to a float but is risky
            except ValueError:
                raise Exception( "Invalid Input, Unable to be Converted (Input must be numeric)" )
          
       
        if oz <= 0: #value is less than 0
            raise ValueError( "Invalid Input, Unable to be Converted (Input must be positive)" )


        #converts ounces to grams
        gr = oz * 28.3495

        gr = "%.3f" %  round(gr, 3)

        output = str(oz) + " ounces is " + str(gr) + " grams\n"
        return output





    def MtoF(m): #Converts Meters to Feet


        #check variable to see if it is workable
        if not isinstance(m,(int,float)):
            try:
                m = float(m) # convers to a float but is risky
            except ValueError:
                raise Exception( "Invalid Input, Unable to be Converted (Input must be numeric)" )
          
       
        if m <= 0: #value is less than 0
            raise ValueError( "Invalid Input, Unable to be Converted (Input must be positive)" )


        #converts meters to feet
        f = m * 3.2808

        f = "%.3f" % round(f, 3)

        output = str(m) + " meters is " + str(f) + " feet\n"
        return output



    def LitoGa(li): #Converts Liters to Gallons 


        #check variable to see if it is workable
        if not isinstance(li,(int,float)):
            try:
                li = float(li) # convers to a float but is risky
            except ValueError:
                raise Exception( "Invalid Input, Unable to be Converted (Input must be numeric)" )
         
       
        if li <= 0: #value is less than 0
            raise ValueError( "Invalid Input, Unable to be Converted (Input must be positive)" )


        #converts liters to gallons
        ga = li * 0.26417

        ga = "%.3f" % round(ga, 3)

        output = str(li) + " liters is " + str( ga  ) + " gallons\n"
        return output


    def CtoF(c, kinclude): #Converts Celsius to Fahrenheit 


        #check variable to see if it is workable
        if not isinstance(c,(int,float)):
            try:
                c = float(c) # convers to a float but is risky
            except ValueError:
                raise Exception( "Invalid Input, Unable to be Converted (Input must be numeric)" )
         
       
        if c < -273: #value is less than 0
            raise ValueError( "Invalid Input, Unable to be Converted (Temperature input must be above -273 celsius (anything below that is below 0 kelvin which is impossible) )" )


        #converts Celsius to Fahrenheit
        f = (c * (9/5)) + 32

        kelvin = c + 273.15

        f = "%.3f" % round(f, 3)

        kelvin = "%.3f" % round(kelvin, 3)


        if kinclude == True:
            #output with kelvin

            
            output = str(c) + " degrees celsius is " + str( f  ) + " degrees fahrenheit which is also " + str(kelvin) + " kelvin.\n"
        else:
            #Output without kelvin


            output = str(c) + " degrees celsius is " + str( f  ) + " degrees fahrenheit\n"

        return output



    def FtoC(f, kinclude): #Converts Fahrenheit to Celsius 
         

        
        #check variable to see if it is workable
        if not isinstance(f,(int,float)):
            try:
                f = float(f) # convers to a float but is risky
            except ValueError:
                raise Exception( "Invalid Input, Unable to be Converted (Input must be numeric)" )
         
       
        #Converts fahrenheit to celsius
        c = (5/9) * (f-32)


        if c < -273: #value is less than 0
            raise ValueError( "Invalid Input, Unable to be Converted (Temperature input must be above about -459.67 fahrenheit  (anything below that is below 0 kelvin which is impossible) )" )


    

        kelvin = c + 273.15

        c = "%.3f" % round(c, 3)

        kelvin = "%.3f" % round(kelvin, 3)


        if kinclude == True:
            #output with kelvin

            
            output = str(f) + " degrees fahrenheit is " + str( c  ) + " degrees celsius which is also " + str(kelvin) + " kelvin.\n"
        else:
            #Output without kelvin


            output = str(f) + " degrees fahrenheit is " + str( c ) + " degrees celsius\n"

        return output





    






    
    



            

         

        


