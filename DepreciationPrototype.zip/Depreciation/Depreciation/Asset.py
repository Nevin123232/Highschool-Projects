from math import*

class Asset:
    
    def __init__(self,c,av,l,e):   #cost,salvage value, life in years, error 
        self._cost = c
        self._sv = av
        self._life = l
        self._error = e
        self._sl = 0
        self._syd = 0

        try:
     
            self._life = int(self._life)
            
        except Exception as c:
            return 

       
        self._lstbbal = [0] * self._life
        self._lstsyddep = [0] * self._life
        self._lstsydrate = [0] * self._life
        self._lstendbal = [0] * self._life
        self._lstslendbal = [0] * self._life
        
     
            

        
    def calculateSL(self):
        self._sl = round(((self._cost - self._sv)/self._life),2)

        

    def calculatesyd(self):
        self._syd =  round( ((self._life/ self.getSum(self._life )) * (self._cost - self._sv)) , 2) 

      
    def getSum(self,years):
        sum = 0
        for x in range(1, years + 1):
            sum += x

        return sum

    def getSL(self):
        return self._sl

    def getsyd(self):
        return self._syd
        
    def isValid(self):

        legit = True

        try:
            self._cost = float(self._cost)
            self._sv = float(self._sv)
            self._life = int(self._life)
            
        except Exception as c:
            self._error += "Asset Error: The inputs must be numbers (that are above 0), life must be a whole number\n"
            return False



        if self._sv >= self._cost:
            self._error += "Asset Error: Salvage Value must be less than cost.\n"
            legit = False


        if self._life <= 0 or self._cost <= 0:
            self._error += "Asset Error: Life and Cost must be greater than 0.\n"
            legit = False

        
        return legit

    def createSchedule(self):

        co = self._cost
        cos = self._cost
        l = self._life

        for x in range (0, self._life):
            self._lstbbal[x] = co
            self._lstsyddep[x] =  (l/ self.getSum(l ))   * self._lstbbal[x]
            self._lstsydrate[x] = (   (self._lstsyddep[x]/ self._lstbbal[0]) * 100  )  
            self._lstendbal[x]  = self._lstbbal[x] -  self._lstsyddep[x]
            self._lstslendbal[x] = cos - self._sl


            co = self._lstbbal[x] - self._lstsyddep[x]
            cos = self._lstslendbal[x]
            l = l - 1


        #self._lstbbal = [0] * self._life
        #self._lstsyddep = [0] * self._life
        #self._lstsydrate = [0] * self._life
        #self._lstendbal = [0] * self._life
        #self._lstslendbal = [0] * self._life
        
     
        



    def getBegBal(self, yr):
        return self._lstbbal[yr]
    
     
    def getAnnDepRate(self, yr):
        return self._lstsyddep[yr]
 
 
    def getEndBal(self, yr):
        return self.__lstendbal[yr]
 
 
    def getEndBalSL(self, yr): 
        return self._lstslendbal[yr]


    def getCost(self):
        return self._cost

    def getSalvage(self):
        return self._sv

    def getLife(self):
        return self._life

