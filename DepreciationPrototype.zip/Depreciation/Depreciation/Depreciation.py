
from Asset import Asset
from locale import*

#NO WHILE(True) Loops, Proffesor Daniel has taught me well in warning me not to use those. 

def useagain(prompt):

    notgoodval = True

    while( notgoodval):
        u = input(prompt)
        if u.lower() == "y" or u.lower() == "n":
            notgoodval = False
        else:
            print("Your input must be 'Y' or 'N', Please try again.")

    return u


def main():
    print("Welcome to the Depreciation Calculator\n")
    
    start = useagain("Do you have an Asset?(Y/N)\n")



    result = setlocale(LC_ALL, '')

    if result == "C" or result.startswith("C/"):
        setlocale(LC_ALL, 'en_US')



    while(start.lower() != "n"):
        #process

        #get inputs
        cost = input("Asset cost (Input a number greater than 0): \n")
        salvagevalue = input("Salvage Value (Input a number greater than 0 and less than cost): \n")
        life = input("Life (in years, must be greater than 0) :\n")

        Asset1 = Asset(cost,salvagevalue,life,"") 

        if(Asset1.isValid() == True):
            #calculate sl and syd
            sl = Asset1.calculateSL()
            syd = Asset1.calculatesyd()

            print("For Straight Line the annual depreciation is:", currency(Asset1.getSL(), grouping = True))
            print("For SYD the first year depreciation is:", currency(Asset1.getsyd(),grouping = True))




            #Ask for schedule
            s = useagain("Would you like a schedule?(Y/N)\n")
            if s.lower() == "y":
                #make a schedule
                print("Here is the schedule:\n\n")
                Asset1.createSchedule()


                print("Year         SYD Beg.Bal.    SYD Dep,    SYD Rate     SYD End.Bal    SL End.Bal.\n")

                for x in range(0, Asset1._life):
                    print(x + 1,  "         ",round( Asset1._lstbbal[x], 2)   , "       ", round(Asset1._lstsyddep[x],2 )   , "      ", round(Asset1._lstsydrate[x],3)   , "%        ", round(Asset1._lstendbal[x],2)   , "        ",round(Asset1._lstslendbal[x],2)   )



        else:
            #prints error
            print(Asset1._error)



        #if the user would like to keep using the program
        start = useagain("Do you have an Asset?(Y/N)\n")
       

    print("Thank you for using this Depreciation Calculator!\n")



if __name__ == "__main__":
    main()
