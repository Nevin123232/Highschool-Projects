// p-chal-ch9-2-NevinNdonwi.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
//Programming Challenge 6 on page 656.

using namespace std;

void swap(string& a, string& b) {

    string temp = a;
    a = b;
    b = temp;
}
int main()

{

    const int SIZE = 20;
    string name[SIZE] = {
        "Collins, Bill", "Smith, Bart", "Michalski, Joe", "Griffin, Jim",
        "Sanchez, Manny", "Rubin, Sarah" , "Taylor, Tyrone", "Johnson, Jill",
        "Allison, Jeff", "Moreno, Juan" , "Wolfe, Bill" , "Whitman, Jean",
        "Moretti, Bella", "Wu, Eric", "Patel, Renee", "Harrison, Rose",
        "Smith, Cathy", "Conroy, Pat", "Kelly, Sean", "Holland, Beth" };

    //output array before sort


    cout << "\n\n***HERE ARE THE NAMES PRIOR TO SORTING***\n\n";

    for (int p = 0; p < SIZE; p++) {

        cout << "\n" << name[p];
    }


    //system("pause");


    //Selectiomnsort  (The book does not specify so I sorted them in alphebetical order based on last name)


    int mini;
    string minv;

    for (int start = 0; start < SIZE - 1; start++) {

        mini = start;
        minv = name[start];

        for (int index = start + 1; index < SIZE; index++) {

            if (name[index] < minv) {

                minv = name[index];
                mini = index;
            }
        }

        swap(name[mini], name[start]);


    }

    

    cout << "\n\n\n\n***HERE ARE THE NAMES AFTER SORTING***\n\n";

    for (int p = 0; p < SIZE; p++) {

        cout << "\n" << name[p];
    }
    cout << "\n";
    system("pause");
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
