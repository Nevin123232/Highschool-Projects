package mathTutor;
import java.util.*;


public class Tutor {
	
	/*
	 * In this program
	 *im planning to make it so that addition, subtraction,
	 *division, multiplication are all possible 
	 *math functions the user can do. The user will choose what type 
	 *of problem they want to complete at the beggining of the
	 *program. 
	 */
	
	static Scanner scan = new Scanner(System.in);

	public static void main (String[] args) {
		
		String operation = "add"; // the type of mathematical operation that the user will perform
		
		
		String fail = "", success = "", choice = "y";
		
		
		
		while (choice.equalsIgnoreCase("y")) {
			
			
			//use math.random to generate 2 random numbers 
			
			int num1 = (int) (Math.random() * 10) + 1;
			int num2 = (int) (Math.random() * 10) + 1; 
			int randMsg = (int) (Math.random() * 4);
			// set up random message for success and failure 
			
			switch (randMsg) {
			
			case 0: fail = "Don't give up"; success = "You should be proud";
			break;
			case 1: fail = "No. Nice try anyway!"; success = "Way to go";
			break;
			case 2: fail = "Incorrect. Once more!"; success = "Keep up the good work";
			break;
			case 3: fail = "Incorrect. Try again. "; success = "Rock on";
			break;
			default: System.out.println("Something went wrong");
			break;
			
			
			}
			
			
			
			// If the user chooses to do addition 
			if (operation.equals("add")) {
			//prompt for input 
			System.out.println("What's " + num1 + " + " + num2 + "?");
			
			// read user input
			
			int input = scan.nextInt();
			int answer = num1 + num2;
			
			
			// compare user input to result
			if (input == answer) {
				
				System.out.println(success);
				
			}
			else {
				
				System.out.println(fail);
				System.out.println(num1 + " + " + num2 + " = " + input + " is " + (num1 + num2 == input) );
				System.out.println("The correct answer is " + answer);
				
				
			}
			
			} // If division is chosen by the user
			else if (operation.equals("divide")) {
				
				
				while( (num1 == 0) || (num2 == 0) ) {
					 num1 = (int) (Math.random() * 10) + 1;
					 num2 = (int) (Math.random() * 10) + 1; 
					// makes it so that num1 and num2 are never 0
				}
				
				
				//prompt for input 
				System.out.println("What's " + num1 + " / " + num2 + " (rounded to the nearest whole number) ?");
				
				// read user input
				
				int attempt = scan.nextInt();

				int answer =  num1 / num2;

				// compare user input to result
				if (Math.round(attempt) == Math.round(answer)) {
					
					System.out.println(success);
					
				}
				else {
					
					System.out.println(fail);
					System.out.println(num1 + " / " + num2 + " = " + (attempt) + " is " + ("wrong") );
					System.out.println("The correct answer is " + (answer));
					
					
				}
				
		  }
		else if (operation.equals("subtract")) { // If user chooses subtraction
				//prompt for input 
				System.out.println("What's " + num1 + " - " + num2 + "?");
				
				// read user input
				
				int input = scan.nextInt();
				int answer = num1 - num2;
				
				
				// compare user input to result
				if (input == answer) {
					
					System.out.println(success);
					
				}
				else {
					
					System.out.println(fail);
					System.out.println(num1 + " - " + num2 + " = " + input + " is " + (num1 - num2 == input) );
					System.out.println("The correct answer is " + answer);
					
					
				}
				
		  }
		else if (operation.equals("multiply")) { // If user chooses multiplication
			//prompt for input 
			System.out.println("What's " + num1 + " * " + num2 + "?");
			
			// read user input
			
			int input = scan.nextInt();
			int answer = num1 * num2;
			
			
			// compare user input to result
			if (input == answer) {
				
				System.out.println(success);
				
			}
			else {
				
				System.out.println(fail);
				System.out.println(num1 + " * " + num2 + " = " + input + " is " + (num1 * num2 == input) );
				System.out.println("The correct answer is about " + answer);
				
				
			}
			
	  }
			
			
			
		
			
			// Ask if the user wants to continue and what mathematical operation they want to perform next
			
			
			System.out.println("Continue? input 'y' for yes (without quotes): ");
			choice = scan.next();
			
			if( !(choice.equals("y")) ) {
				
				break;
			}
			
			System.out.println("What mathematical operation would you like to complete? ");
			System.out.println("Input 'a' for addition: " ); // If the user wants to complete addition
			System.out.println("Input 's' for subtraction: ");// If the user wants to complete subtraction
			System.out.println("Input 'm' for multiplication: ");// If the user wants to complete multiplication
			System.out.println("Input 'd' for division: ");// If the user wants to complete division
			System.out.println("Input 'n' if you would like to end the program");
			operation = scan.next();
			
            switch (operation) { // checks what the user inputted and determines the operation based on the inputs
			
			case "a": operation = "add"; // If the user inputted 'a' then addition is completed
			break;
			case "s": operation = "subtract";// If the user inputted 's' then subtraction is completed
			break;
			case "m": operation = "multiply";// If the user inputted 'm' then multiplication is completed
			break;
			case "d": operation = "divide";// If the user inputted 'd' then division is completed
			break;
			case "n":System.out.println("You have ended the program. Have a nice day!!"); System.exit(0); //If the user inputted 'n' then the program ends
			//forcibly exits program since break won't break out of the loop here 
			break;
			default: System.out.println("Something went wrong, Next time input a legitimate operation. ");
			break;
			
			
			}
			


			
			
		}
		
		System.out.println("You have ended the program. Have a nice day!!");
		
	}
	
	
}
