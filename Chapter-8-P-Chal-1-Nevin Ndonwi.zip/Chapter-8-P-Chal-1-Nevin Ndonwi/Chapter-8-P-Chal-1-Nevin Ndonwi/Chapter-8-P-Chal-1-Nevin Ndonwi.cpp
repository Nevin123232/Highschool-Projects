// Chapter-8-P-Chal-1-Nevin Ndonwi.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <vector>

using namespace std;

//Programming Challenge 1 page 602

int countPerfect(int scores[]) {

    int amount = 0;

    for (int i = 0; i <20; i++) {

        if (scores[i] == 100) {
            amount++;
        }
    }

    return amount;

}


int main()
{
    //Gain test score inputs

    int x = 0;
    int test = 0; //variable for user input
    int scores[20] = { 0 }; // creation of scores array

    while (x < 20) {
        cout << "Input a test score(0-100) or input -1 to stop adding scores: \n";
        cin >> test;
       
        if (test == -1) {

            x = 20;

            //ends loop
            cout << "No more scores will be entered.\n";
        }
        else if ((test > 100) || (test < -1)) {

            cout << "That was an invalid input. Input (0-100) or -1\n";
        }
        else {

            //adds a score to the scores vector
            scores[x] = test;
            x++;
        }


        //increase x by 1
        

    }


    cout << countPerfect(scores) << " perfect scores were entered.\nHave a nice day!\n";

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
