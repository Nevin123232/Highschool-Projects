﻿Public Class frmpoknames



    Private Sub btnintro_Click(sender As Object, e As EventArgs) Handles btnintro.Click
        Me.Close()
    End Sub

    Private Sub lboenglish_SelectedValueChanged(sender As Object, e As EventArgs) Handles lboenglish.SelectedValueChanged

        pboaegislash.Visible = False
        pboblaze.Visible = False
        pboBulbizarre.Visible = False
        pbolugularbre.Visible = False
        pbodracaufeu.Visible = False
        pbocorvaillus.Visible = False
        pboarcheduc.Visible = False
        pbolanssorien.Visible = False
        pbodracolosse.Visible = False
        pboevoli.Visible = False
        pbogardevoir.Visible = False
        pbolibegon.Visible = False
        pbominotaupe.Visible = False
        pbocharchacroc.Visible = False
        pboscorvol.Visible = False
        pboectoplasma.Visible = False
        pbosarmurai.Visible = False
        pbosimiabraz.Visible = False
        pboamphinobi.Visible = False
        pbotrioxhydre.Visible = False
        pbocrocorible.Visible = False
        pbointro.Visible = False
        pboluxray.Visible = False
        pbolougaroc.Visible = False
        pbolucario.Visible = False
        pbolugia.Visible = False
        pbomew.Visible = False
        pbomewtwo.Visible = False
        pbomelmetal.Visible = False
        pbometalosse.Visible = False
        pbomimiqui.Visible = False
        pbobrindibou.Visible = False
        pboroserade.Visible = False
        pborayquaza.Visible = False
        pbopikachu.Visible = False
        pbonymphalli.Visible = False
        pbocizayox.Visible = False
        pbojungko.Visible = False
        pboetouraptor.Visible = False
        pbofrissonille.Visible = False
        pboronflex.Visible = False
        pboflambusard.Visible = False
        pbotogekiss.Visible = False
        pbotyranocif.Visible = False
        pbosalarsen.Visible = False
        pbonoctali.Visible = False
        pbolucanon.Visible = False
        pbopyrax.Visible = False
        pbozeraora.Visible = False
        pbozoroark.Visible = False
        pbodimoret.Visible = False





        lblsurpris.Visible = False
        lbljackbot.Visible = False

        lblsurpris.ForeColor = Color.Green
        lbljackbot.ForeColor = Color.Green

        lbofrenchpok.SelectedIndex = lboenglish.SelectedIndex
        If lboenglish.SelectedItem.ToString = "Aegislash" Then
            pboaegislash.Visible = True
        End If



        If lboenglish.SelectedItem.ToString = "Blaziken" Then
            pboblaze.Visible = True
        End If



        If lboenglish.SelectedItem.ToString = "Bulbasaur" Then
            pboBulbizarre.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Chandelure" Then
            pbolugularbre.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Charizard" Then
            pbodracaufeu.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Corviknight" Then
            pbocorvaillus.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Decidueye" Then
            pboarcheduc.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Dragapult" Then
            pbolanssorien.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Dragonite" Then
            pbodracolosse.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Eevee" Then
            pboevoli.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Gardevoir" Then
            pbogardevoir.Visible = True
        End If


        If lboenglish.SelectedItem.ToString = "Excadrill" Then
            pbominotaupe.Visible = True
        End If


        If lboenglish.SelectedItem.ToString = "Flygon" Then
            pbolibegon.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Garchomp" Then
            pbocharchacroc.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Gliscor" Then
            pboscorvol.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Gengar" Then
            pboectoplasma.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Greninja" Then
            pboamphinobi.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Infernape" Then
            pbosimiabraz.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Golisopod" Then
            pbosarmurai.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Krookodile" Then
            pbocrocorible.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Hydreigon" Then
            pbotrioxhydre.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Luxray" Then
            pboluxray.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Lycanrock" Then
            pbolougaroc.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Lucario" Then
            pbolucario.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Lugia" Then
            pbolugia.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Melmetal" Then
            pbomelmetal.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Metagross" Then
            pbometalosse.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Mimikyu" Then
            pbomimiqui.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Mew" Then
            pbomew.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Mewtwo" Then
            pbomewtwo.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Pikachu" Then
            pbopikachu.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Rayquaza" Then
            pborayquaza.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Rowlet" Then
            pbobrindibou.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Roserade" Then
            pboroserade.Visible = True
        End If



        If lboenglish.SelectedItem.ToString = "Sceptile" Then
            pbojungko.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Scizor" Then
            pbocizayox.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Snom" Then
            pbofrissonille.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Snorlax" Then
            pboronflex.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Staraptor" Then
            pboetouraptor.Visible = True
        End If

        If lboenglish.SelectedItem.ToString = "Sylveon" Then
            pbonymphalli.Visible = True
        End If





        If lboenglish.SelectedItem.ToString = "Togekiss" Then
            pbotogekiss.Visible = True
        End If


        If lboenglish.SelectedItem.ToString = "Talonflame" Then
            pboflambusard.Visible = True
        End If


        If lboenglish.SelectedItem.ToString = "Tyranitar" Then
            pbotyranocif.Visible = True
        End If


        If lboenglish.SelectedItem.ToString = "Toxtricity" Then
            pbosalarsen.Visible = True

        End If





        If lboenglish.SelectedItem.ToString = "Umbreon" Then
            pbonoctali.Visible = True

        End If
        If lboenglish.SelectedItem.ToString = "Volcorona" Then
            pbopyrax.Visible = True

        End If
        If lboenglish.SelectedItem.ToString = "Vikavolt" Then
            pbolucanon.Visible = True

        End If


        If lboenglish.SelectedItem.ToString = "Zeraora" Then
            pbozeraora.Visible = True

        End If

        If lboenglish.SelectedItem.ToString = "Zoroark" Then
            pbozoroark.Visible = True

        End If

        If lboenglish.SelectedItem.ToString = "Weavile" Then
            pbodimoret.Visible = True

        End If




        If lboenglish.SelectedItem.ToString = lbofrenchpok.SelectedItem.ToString Then
            lblsurpris.Visible = True
            lbljackbot.Visible = True
        End If
        lblresult.Text = lboenglish.SelectedItem.ToString + " in french is " + lbofrenchpok.SelectedItem.ToString
    End Sub

    Private Sub lbofrenchpok_SelectedValueChanged(sender As Object, e As EventArgs) Handles lbofrenchpok.SelectedValueChanged


        pboaegislash.Visible = False
        pboblaze.Visible = False
        pboBulbizarre.Visible = False
        pbolugularbre.Visible = False
        pbocorvaillus.Visible = False
        pbolanssorien.Visible = False
        pbodracolosse.Visible = False
        pboevoli.Visible = False
        pbogardevoir.Visible = False
        pbolibegon.Visible = False
        pbominotaupe.Visible = False
        pbocharchacroc.Visible = False
        pboscorvol.Visible = False
        pboectoplasma.Visible = False
        pbosarmurai.Visible = False
        pbosimiabraz.Visible = False
        pboamphinobi.Visible = False
        pbotrioxhydre.Visible = False
        pbocrocorible.Visible = False
        pbointro.Visible = False
        pboluxray.Visible = False
        pbolougaroc.Visible = False
        pbolucario.Visible = False
        pbolugia.Visible = False
        pbomew.Visible = False
        pbomewtwo.Visible = False
        pbomelmetal.Visible = False
        pbometalosse.Visible = False
        pbomimiqui.Visible = False
        pbobrindibou.Visible = False
        pboroserade.Visible = False
        pborayquaza.Visible = False
        pbopikachu.Visible = False
        pbonymphalli.Visible = False
        pbocizayox.Visible = False
        pbojungko.Visible = False
        pboetouraptor.Visible = False
        pbofrissonille.Visible = False
        pboronflex.Visible = False
        pboflambusard.Visible = False
        pbotogekiss.Visible = False
        pbotyranocif.Visible = False
        pbosalarsen.Visible = False
        pbonoctali.Visible = False
        pbolucanon.Visible = False
        pbopyrax.Visible = False
        pbozeraora.Visible = False
        pbozoroark.Visible = False
        pbodimoret.Visible = False



        lblsurpris.Visible = False
        lbljackbot.Visible = False

        lblsurpris.ForeColor = Color.Green
        lbljackbot.ForeColor = Color.Green



        lboenglish.SelectedIndex = lbofrenchpok.SelectedIndex


        If lbofrenchpok.SelectedItem.ToString = lboenglish.SelectedItem.ToString Then
            lblsurpris.Visible = True
            lbljackbot.Visible = True
        End If



        lboenglish.SelectedIndex = lbofrenchpok.SelectedIndex
        If lbofrenchpok.SelectedItem.ToString = "Brasegali" Then
            pboblaze.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Exagide" Then
            pboaegislash.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Bulbizarre" Then
            pboBulbizarre.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Lugularbre" Then
            pbolugularbre.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Dracaufeu" Then
            pbodracaufeu.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Corvaillus" Then
            pbocorvaillus.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Archeduc" Then
            pboarcheduc.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Lanssorien" Then
            pbolanssorien.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Dracolosse" Then
            pbodracolosse.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Evoli" Then
            pboevoli.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Libegon" Then
            pbolibegon.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Minotaupe" Then
            pbominotaupe.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Gardevoir" Then
            pbogardevoir.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Scorvol" Then
            pboscorvol.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Charchacroc" Then
            pbocharchacroc.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "ectoplasma" Then
            pboectoplasma.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Amphinobi" Then
            pboamphinobi.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Crocorible" Then
            pbocrocorible.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Sarmurai" Then
            pbosarmurai.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Simiabraz" Then
            pbosimiabraz.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Trioxhydre" Then
            pbotrioxhydre.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Luxray" Then
            pboluxray.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Lucario" Then
            pbolucario.Visible = True
        End If


        If lbofrenchpok.SelectedItem.ToString = "Lugia" Then
            pbolugia.Visible = True
        End If


        If lbofrenchpok.SelectedItem.ToString = "Lougaroc" Then
            pbolougaroc.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Metalosse" Then
            pbometalosse.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Mew" Then
            pbomew.Visible = True
        End If


        If lbofrenchpok.SelectedItem.ToString = "Mewtwo" Then
            pbomewtwo.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Melmetal" Then
            pbomelmetal.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Mimiqui" Then
            pbomimiqui.Visible = True
        End If


        If lbofrenchpok.SelectedItem.ToString = "Rayquaza" Then
            pborayquaza.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Roserade" Then
            pboroserade.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Pikachu" Then
            pbopikachu.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Brindibou" Then
            pbobrindibou.Visible = True
        End If




        If lbofrenchpok.SelectedItem.ToString = "Jungko" Then
            pbojungko.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Cizayox" Then
            pbocizayox.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Frissonille" Then
            pbofrissonille.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Ronflex" Then
            pboronflex.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Etouraptor" Then
            pboetouraptor.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Nymphalli" Then
            pbonymphalli.Visible = True
        End If


        If lbofrenchpok.SelectedItem.ToString = "Togekiss" Then
            pbotogekiss.Visible = True
        End If


        If lbofrenchpok.SelectedItem.ToString = "Salarsen" Then
            pbosalarsen.Visible = True
        End If


        If lbofrenchpok.SelectedItem.ToString = "Tyranocif" Then
            pbotyranocif.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Flambusard" Then
            pboflambusard.Visible = True
        End If


        If lbofrenchpok.SelectedItem.ToString = "Pyrax" Then
            pbopyrax.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Lucanon" Then
            pbolucanon.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Dimoret" Then
            pbodimoret.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Noctali" Then
            pbonoctali.Visible = True

        End If

        If lbofrenchpok.SelectedItem.ToString = "Zeraora" Then
            pbozeraora.Visible = True
        End If

        If lbofrenchpok.SelectedItem.ToString = "Zoroark" Then
            pbozoroark.Visible = True
        End If



        lblresult.Text = lbofrenchpok.SelectedItem.ToString + " in english is " + lboenglish.SelectedItem.ToString
    End Sub

    Private Sub frmpoknames_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        pbointro.Visible = True

    End Sub
End Class