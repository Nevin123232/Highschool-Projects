﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmpoknames
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmpoknames))
        Me.btnintro = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lboenglish = New System.Windows.Forms.ListBox()
        Me.lbofrenchpok = New System.Windows.Forms.ListBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lbltest = New System.Windows.Forms.Label()
        Me.lblresult = New System.Windows.Forms.Label()
        Me.pboaegislash = New System.Windows.Forms.PictureBox()
        Me.lbljackbot = New System.Windows.Forms.Label()
        Me.lblsurpris = New System.Windows.Forms.Label()
        Me.pboblaze = New System.Windows.Forms.PictureBox()
        Me.pboBulbizarre = New System.Windows.Forms.PictureBox()
        Me.pbolugularbre = New System.Windows.Forms.PictureBox()
        Me.pbodracaufeu = New System.Windows.Forms.PictureBox()
        Me.pbocorvaillus = New System.Windows.Forms.PictureBox()
        Me.pboarcheduc = New System.Windows.Forms.PictureBox()
        Me.pbolanssorien = New System.Windows.Forms.PictureBox()
        Me.pbodracolosse = New System.Windows.Forms.PictureBox()
        Me.pboevoli = New System.Windows.Forms.PictureBox()
        Me.pbogardevoir = New System.Windows.Forms.PictureBox()
        Me.pbolibegon = New System.Windows.Forms.PictureBox()
        Me.pbominotaupe = New System.Windows.Forms.PictureBox()
        Me.pboscorvol = New System.Windows.Forms.PictureBox()
        Me.pboectoplasma = New System.Windows.Forms.PictureBox()
        Me.pbocharchacroc = New System.Windows.Forms.PictureBox()
        Me.pbocrocorible = New System.Windows.Forms.PictureBox()
        Me.pbosimiabraz = New System.Windows.Forms.PictureBox()
        Me.pbotrioxhydre = New System.Windows.Forms.PictureBox()
        Me.pboamphinobi = New System.Windows.Forms.PictureBox()
        Me.pbosarmurai = New System.Windows.Forms.PictureBox()
        Me.pbointro = New System.Windows.Forms.PictureBox()
        Me.pbolucario = New System.Windows.Forms.PictureBox()
        Me.pbolugia = New System.Windows.Forms.PictureBox()
        Me.pbolougaroc = New System.Windows.Forms.PictureBox()
        Me.pboluxray = New System.Windows.Forms.PictureBox()
        Me.pbomelmetal = New System.Windows.Forms.PictureBox()
        Me.pbometalosse = New System.Windows.Forms.PictureBox()
        Me.pbomew = New System.Windows.Forms.PictureBox()
        Me.pbomewtwo = New System.Windows.Forms.PictureBox()
        Me.pbomimiqui = New System.Windows.Forms.PictureBox()
        Me.pbopikachu = New System.Windows.Forms.PictureBox()
        Me.pborayquaza = New System.Windows.Forms.PictureBox()
        Me.pboroserade = New System.Windows.Forms.PictureBox()
        Me.pbobrindibou = New System.Windows.Forms.PictureBox()
        Me.pbojungko = New System.Windows.Forms.PictureBox()
        Me.pbocizayox = New System.Windows.Forms.PictureBox()
        Me.pboetouraptor = New System.Windows.Forms.PictureBox()
        Me.pbofrissonille = New System.Windows.Forms.PictureBox()
        Me.pboronflex = New System.Windows.Forms.PictureBox()
        Me.pbonymphalli = New System.Windows.Forms.PictureBox()
        Me.pboflambusard = New System.Windows.Forms.PictureBox()
        Me.pbotogekiss = New System.Windows.Forms.PictureBox()
        Me.pbosalarsen = New System.Windows.Forms.PictureBox()
        Me.pbotyranocif = New System.Windows.Forms.PictureBox()
        Me.pbonoctali = New System.Windows.Forms.PictureBox()
        Me.pbozoroark = New System.Windows.Forms.PictureBox()
        Me.pbozeraora = New System.Windows.Forms.PictureBox()
        Me.pbodimoret = New System.Windows.Forms.PictureBox()
        Me.pbopyrax = New System.Windows.Forms.PictureBox()
        Me.pbolucanon = New System.Windows.Forms.PictureBox()
        CType(Me.pboaegislash, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pboblaze, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pboBulbizarre, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbolugularbre, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbodracaufeu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbocorvaillus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pboarcheduc, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbolanssorien, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbodracolosse, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pboevoli, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbogardevoir, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbolibegon, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbominotaupe, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pboscorvol, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pboectoplasma, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbocharchacroc, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbocrocorible, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbosimiabraz, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbotrioxhydre, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pboamphinobi, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbosarmurai, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbointro, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbolucario, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbolugia, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbolougaroc, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pboluxray, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbomelmetal, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbometalosse, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbomew, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbomewtwo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbomimiqui, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbopikachu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pborayquaza, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pboroserade, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbobrindibou, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbojungko, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbocizayox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pboetouraptor, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbofrissonille, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pboronflex, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbonymphalli, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pboflambusard, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbotogekiss, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbosalarsen, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbotyranocif, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbonoctali, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbozoroark, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbozeraora, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbodimoret, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbopyrax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbolucanon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnintro
        '
        Me.btnintro.Location = New System.Drawing.Point(462, 364)
        Me.btnintro.Name = "btnintro"
        Me.btnintro.Size = New System.Drawing.Size(131, 30)
        Me.btnintro.TabIndex = 1
        Me.btnintro.Text = "Back to i&ntro screen"
        Me.btnintro.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!)
        Me.Label1.Location = New System.Drawing.Point(12, -3)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(593, 97)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Welcome to the pokemon translator. Click the name of a pokemon in english and it " &
    "will show you the equivilent in french."
        '
        'lboenglish
        '
        Me.lboenglish.FormattingEnabled = True
        Me.lboenglish.Items.AddRange(New Object() {"Aegislash", "Blaziken", "Bulbasaur", "Chandelure", "Charizard", "Corviknight", "Decidueye", "Dragapult", "Dragonite", "Eevee", "Excadrill", "Flygon", "Gardevoir", "Garchomp", "Gengar", "Gliscor", "Golisopod", "Greninja", "Hydreigon", "Infernape", "Krookodile", "Lucario", "Lugia", "Luxray", "Lycanrock", "Melmetal", "Metagross", "Mew", "Mewtwo", "Mimikyu", "Pikachu", "Rayquaza", "Roserade", "Rowlet", "Sceptile", "Scizor", "Staraptor", "Snom", "Snorlax", "Sylveon", "Talonflame", "Togekiss", "Toxtricity", "Tyranitar", "Umbreon", "Vikavolt", "Volcorona", "Weavile", "Zeraora", "Zoroark"})
        Me.lboenglish.Location = New System.Drawing.Point(27, 134)
        Me.lboenglish.Name = "lboenglish"
        Me.lboenglish.Size = New System.Drawing.Size(125, 212)
        Me.lboenglish.TabIndex = 4
        '
        'lbofrenchpok
        '
        Me.lbofrenchpok.FormattingEnabled = True
        Me.lbofrenchpok.Items.AddRange(New Object() {"Exagide", "Brasegali", "Bulbizarre", "Lugularbre", "Dracaufeu", "Corvaillus", "Archeduc", "Lanssorien", "Dracolosse", "Evoli", "Minotaupe", "Libegon", "Gardevoir", "Charchacroc", "Ectoplasma", "Scorvol", "Sarmurai", "Amphinobi", "Trioxhydre", "Simiabraz", "Crocorible", "Lucario", "Lugia", "Luxray", "Lougaroc", "Melmetal", "Metalosse", "Mew", "Mewtwo", "Mimiqui", "Pikachu", "Rayquaza", "Roserade", "Brindibou", "Jungko", "Cizayox", "Etouraptor", "Frissonille", "Ronflex", "Nymphalli", "Flambusard", "Togekiss", "Salarsen", "Tyranocif", "Noctali", "Lucanon", "Pyrax", "Dimoret", "Zeraora", "Zoroark"})
        Me.lbofrenchpok.Location = New System.Drawing.Point(450, 134)
        Me.lbofrenchpok.Name = "lbofrenchpok"
        Me.lbofrenchpok.Size = New System.Drawing.Size(120, 212)
        Me.lbofrenchpok.TabIndex = 5
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(24, 115)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(192, 16)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Pokemon Name in english:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(326, 115)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(231, 16)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Le nom du pokemon en francais:"
        '
        'lbltest
        '
        Me.lbltest.Location = New System.Drawing.Point(3, 349)
        Me.lbltest.Name = "lbltest"
        Me.lbltest.Size = New System.Drawing.Size(204, 41)
        Me.lbltest.TabIndex = 8
        Me.lbltest.Text = "*Pokemon are based on the pokemon of the year poll and my personal favorites (50 " &
    "pokemon total)" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'lblresult
        '
        Me.lblresult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblresult.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblresult.Location = New System.Drawing.Point(158, 303)
        Me.lblresult.Name = "lblresult"
        Me.lblresult.Size = New System.Drawing.Size(286, 43)
        Me.lblresult.TabIndex = 9
        '
        'pboaegislash
        '
        Me.pboaegislash.Image = CType(resources.GetObject("pboaegislash.Image"), System.Drawing.Image)
        Me.pboaegislash.Location = New System.Drawing.Point(158, 134)
        Me.pboaegislash.Name = "pboaegislash"
        Me.pboaegislash.Size = New System.Drawing.Size(286, 166)
        Me.pboaegislash.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pboaegislash.TabIndex = 10
        Me.pboaegislash.TabStop = False
        Me.pboaegislash.Visible = False
        '
        'lbljackbot
        '
        Me.lbljackbot.AutoSize = True
        Me.lbljackbot.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.lbljackbot.Location = New System.Drawing.Point(88, 90)
        Me.lbljackbot.Name = "lbljackbot"
        Me.lbljackbot.Size = New System.Drawing.Size(193, 25)
        Me.lbljackbot.TabIndex = 11
        Me.lbljackbot.Text = "They are the same!!!"
        Me.lbljackbot.Visible = False
        '
        'lblsurpris
        '
        Me.lblsurpris.AutoSize = True
        Me.lblsurpris.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.lblsurpris.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblsurpris.Location = New System.Drawing.Point(324, 90)
        Me.lblsurpris.Name = "lblsurpris"
        Me.lblsurpris.Size = New System.Drawing.Size(212, 25)
        Me.lblsurpris.TabIndex = 12
        Me.lblsurpris.Text = "C'est la meme chose!!!"
        Me.lblsurpris.Visible = False
        '
        'pboblaze
        '
        Me.pboblaze.Image = CType(resources.GetObject("pboblaze.Image"), System.Drawing.Image)
        Me.pboblaze.Location = New System.Drawing.Point(158, 134)
        Me.pboblaze.Name = "pboblaze"
        Me.pboblaze.Size = New System.Drawing.Size(286, 166)
        Me.pboblaze.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pboblaze.TabIndex = 13
        Me.pboblaze.TabStop = False
        Me.pboblaze.Visible = False
        '
        'pboBulbizarre
        '
        Me.pboBulbizarre.Image = CType(resources.GetObject("pboBulbizarre.Image"), System.Drawing.Image)
        Me.pboBulbizarre.Location = New System.Drawing.Point(158, 134)
        Me.pboBulbizarre.Name = "pboBulbizarre"
        Me.pboBulbizarre.Size = New System.Drawing.Size(286, 166)
        Me.pboBulbizarre.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pboBulbizarre.TabIndex = 14
        Me.pboBulbizarre.TabStop = False
        Me.pboBulbizarre.Visible = False
        '
        'pbolugularbre
        '
        Me.pbolugularbre.Image = CType(resources.GetObject("pbolugularbre.Image"), System.Drawing.Image)
        Me.pbolugularbre.Location = New System.Drawing.Point(158, 134)
        Me.pbolugularbre.Name = "pbolugularbre"
        Me.pbolugularbre.Size = New System.Drawing.Size(286, 166)
        Me.pbolugularbre.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbolugularbre.TabIndex = 15
        Me.pbolugularbre.TabStop = False
        Me.pbolugularbre.Visible = False
        '
        'pbodracaufeu
        '
        Me.pbodracaufeu.Image = CType(resources.GetObject("pbodracaufeu.Image"), System.Drawing.Image)
        Me.pbodracaufeu.Location = New System.Drawing.Point(158, 134)
        Me.pbodracaufeu.Name = "pbodracaufeu"
        Me.pbodracaufeu.Size = New System.Drawing.Size(286, 166)
        Me.pbodracaufeu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbodracaufeu.TabIndex = 16
        Me.pbodracaufeu.TabStop = False
        Me.pbodracaufeu.Visible = False
        '
        'pbocorvaillus
        '
        Me.pbocorvaillus.Image = CType(resources.GetObject("pbocorvaillus.Image"), System.Drawing.Image)
        Me.pbocorvaillus.Location = New System.Drawing.Point(158, 134)
        Me.pbocorvaillus.Name = "pbocorvaillus"
        Me.pbocorvaillus.Size = New System.Drawing.Size(286, 166)
        Me.pbocorvaillus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbocorvaillus.TabIndex = 17
        Me.pbocorvaillus.TabStop = False
        Me.pbocorvaillus.Visible = False
        '
        'pboarcheduc
        '
        Me.pboarcheduc.Image = CType(resources.GetObject("pboarcheduc.Image"), System.Drawing.Image)
        Me.pboarcheduc.Location = New System.Drawing.Point(158, 134)
        Me.pboarcheduc.Name = "pboarcheduc"
        Me.pboarcheduc.Size = New System.Drawing.Size(286, 166)
        Me.pboarcheduc.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pboarcheduc.TabIndex = 18
        Me.pboarcheduc.TabStop = False
        Me.pboarcheduc.Visible = False
        '
        'pbolanssorien
        '
        Me.pbolanssorien.Image = CType(resources.GetObject("pbolanssorien.Image"), System.Drawing.Image)
        Me.pbolanssorien.Location = New System.Drawing.Point(158, 134)
        Me.pbolanssorien.Name = "pbolanssorien"
        Me.pbolanssorien.Size = New System.Drawing.Size(286, 166)
        Me.pbolanssorien.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbolanssorien.TabIndex = 19
        Me.pbolanssorien.TabStop = False
        Me.pbolanssorien.Visible = False
        '
        'pbodracolosse
        '
        Me.pbodracolosse.Image = CType(resources.GetObject("pbodracolosse.Image"), System.Drawing.Image)
        Me.pbodracolosse.Location = New System.Drawing.Point(158, 134)
        Me.pbodracolosse.Name = "pbodracolosse"
        Me.pbodracolosse.Size = New System.Drawing.Size(286, 166)
        Me.pbodracolosse.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbodracolosse.TabIndex = 20
        Me.pbodracolosse.TabStop = False
        Me.pbodracolosse.Visible = False
        '
        'pboevoli
        '
        Me.pboevoli.Image = CType(resources.GetObject("pboevoli.Image"), System.Drawing.Image)
        Me.pboevoli.Location = New System.Drawing.Point(158, 134)
        Me.pboevoli.Name = "pboevoli"
        Me.pboevoli.Size = New System.Drawing.Size(286, 166)
        Me.pboevoli.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pboevoli.TabIndex = 21
        Me.pboevoli.TabStop = False
        Me.pboevoli.Visible = False
        '
        'pbogardevoir
        '
        Me.pbogardevoir.Image = CType(resources.GetObject("pbogardevoir.Image"), System.Drawing.Image)
        Me.pbogardevoir.Location = New System.Drawing.Point(158, 134)
        Me.pbogardevoir.Name = "pbogardevoir"
        Me.pbogardevoir.Size = New System.Drawing.Size(286, 166)
        Me.pbogardevoir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbogardevoir.TabIndex = 22
        Me.pbogardevoir.TabStop = False
        Me.pbogardevoir.Visible = False
        '
        'pbolibegon
        '
        Me.pbolibegon.Image = CType(resources.GetObject("pbolibegon.Image"), System.Drawing.Image)
        Me.pbolibegon.Location = New System.Drawing.Point(158, 134)
        Me.pbolibegon.Name = "pbolibegon"
        Me.pbolibegon.Size = New System.Drawing.Size(286, 166)
        Me.pbolibegon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbolibegon.TabIndex = 23
        Me.pbolibegon.TabStop = False
        Me.pbolibegon.Visible = False
        '
        'pbominotaupe
        '
        Me.pbominotaupe.Image = CType(resources.GetObject("pbominotaupe.Image"), System.Drawing.Image)
        Me.pbominotaupe.Location = New System.Drawing.Point(158, 134)
        Me.pbominotaupe.Name = "pbominotaupe"
        Me.pbominotaupe.Size = New System.Drawing.Size(286, 166)
        Me.pbominotaupe.TabIndex = 24
        Me.pbominotaupe.TabStop = False
        Me.pbominotaupe.Visible = False
        '
        'pboscorvol
        '
        Me.pboscorvol.Image = CType(resources.GetObject("pboscorvol.Image"), System.Drawing.Image)
        Me.pboscorvol.Location = New System.Drawing.Point(158, 134)
        Me.pboscorvol.Name = "pboscorvol"
        Me.pboscorvol.Size = New System.Drawing.Size(286, 166)
        Me.pboscorvol.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pboscorvol.TabIndex = 25
        Me.pboscorvol.TabStop = False
        Me.pboscorvol.Visible = False
        '
        'pboectoplasma
        '
        Me.pboectoplasma.Image = CType(resources.GetObject("pboectoplasma.Image"), System.Drawing.Image)
        Me.pboectoplasma.Location = New System.Drawing.Point(158, 134)
        Me.pboectoplasma.Name = "pboectoplasma"
        Me.pboectoplasma.Size = New System.Drawing.Size(286, 166)
        Me.pboectoplasma.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pboectoplasma.TabIndex = 26
        Me.pboectoplasma.TabStop = False
        Me.pboectoplasma.Visible = False
        '
        'pbocharchacroc
        '
        Me.pbocharchacroc.Image = CType(resources.GetObject("pbocharchacroc.Image"), System.Drawing.Image)
        Me.pbocharchacroc.Location = New System.Drawing.Point(158, 134)
        Me.pbocharchacroc.Name = "pbocharchacroc"
        Me.pbocharchacroc.Size = New System.Drawing.Size(286, 166)
        Me.pbocharchacroc.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbocharchacroc.TabIndex = 27
        Me.pbocharchacroc.TabStop = False
        Me.pbocharchacroc.Visible = False
        '
        'pbocrocorible
        '
        Me.pbocrocorible.Image = CType(resources.GetObject("pbocrocorible.Image"), System.Drawing.Image)
        Me.pbocrocorible.Location = New System.Drawing.Point(158, 134)
        Me.pbocrocorible.Name = "pbocrocorible"
        Me.pbocrocorible.Size = New System.Drawing.Size(286, 166)
        Me.pbocrocorible.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbocrocorible.TabIndex = 28
        Me.pbocrocorible.TabStop = False
        Me.pbocrocorible.Visible = False
        '
        'pbosimiabraz
        '
        Me.pbosimiabraz.Image = CType(resources.GetObject("pbosimiabraz.Image"), System.Drawing.Image)
        Me.pbosimiabraz.Location = New System.Drawing.Point(158, 134)
        Me.pbosimiabraz.Name = "pbosimiabraz"
        Me.pbosimiabraz.Size = New System.Drawing.Size(286, 166)
        Me.pbosimiabraz.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbosimiabraz.TabIndex = 29
        Me.pbosimiabraz.TabStop = False
        Me.pbosimiabraz.Visible = False
        '
        'pbotrioxhydre
        '
        Me.pbotrioxhydre.Image = CType(resources.GetObject("pbotrioxhydre.Image"), System.Drawing.Image)
        Me.pbotrioxhydre.Location = New System.Drawing.Point(158, 134)
        Me.pbotrioxhydre.Name = "pbotrioxhydre"
        Me.pbotrioxhydre.Size = New System.Drawing.Size(286, 166)
        Me.pbotrioxhydre.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbotrioxhydre.TabIndex = 30
        Me.pbotrioxhydre.TabStop = False
        Me.pbotrioxhydre.Visible = False
        '
        'pboamphinobi
        '
        Me.pboamphinobi.Image = CType(resources.GetObject("pboamphinobi.Image"), System.Drawing.Image)
        Me.pboamphinobi.Location = New System.Drawing.Point(158, 134)
        Me.pboamphinobi.Name = "pboamphinobi"
        Me.pboamphinobi.Size = New System.Drawing.Size(286, 166)
        Me.pboamphinobi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pboamphinobi.TabIndex = 31
        Me.pboamphinobi.TabStop = False
        Me.pboamphinobi.Visible = False
        '
        'pbosarmurai
        '
        Me.pbosarmurai.Image = CType(resources.GetObject("pbosarmurai.Image"), System.Drawing.Image)
        Me.pbosarmurai.Location = New System.Drawing.Point(158, 134)
        Me.pbosarmurai.Name = "pbosarmurai"
        Me.pbosarmurai.Size = New System.Drawing.Size(286, 166)
        Me.pbosarmurai.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbosarmurai.TabIndex = 32
        Me.pbosarmurai.TabStop = False
        Me.pbosarmurai.Visible = False
        '
        'pbointro
        '
        Me.pbointro.Image = CType(resources.GetObject("pbointro.Image"), System.Drawing.Image)
        Me.pbointro.Location = New System.Drawing.Point(158, 134)
        Me.pbointro.Name = "pbointro"
        Me.pbointro.Size = New System.Drawing.Size(286, 166)
        Me.pbointro.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbointro.TabIndex = 33
        Me.pbointro.TabStop = False
        Me.pbointro.Visible = False
        '
        'pbolucario
        '
        Me.pbolucario.Image = CType(resources.GetObject("pbolucario.Image"), System.Drawing.Image)
        Me.pbolucario.Location = New System.Drawing.Point(158, 134)
        Me.pbolucario.Name = "pbolucario"
        Me.pbolucario.Size = New System.Drawing.Size(286, 166)
        Me.pbolucario.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbolucario.TabIndex = 34
        Me.pbolucario.TabStop = False
        Me.pbolucario.Visible = False
        '
        'pbolugia
        '
        Me.pbolugia.Image = CType(resources.GetObject("pbolugia.Image"), System.Drawing.Image)
        Me.pbolugia.Location = New System.Drawing.Point(158, 134)
        Me.pbolugia.Name = "pbolugia"
        Me.pbolugia.Size = New System.Drawing.Size(286, 166)
        Me.pbolugia.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbolugia.TabIndex = 35
        Me.pbolugia.TabStop = False
        Me.pbolugia.Visible = False
        '
        'pbolougaroc
        '
        Me.pbolougaroc.Image = CType(resources.GetObject("pbolougaroc.Image"), System.Drawing.Image)
        Me.pbolougaroc.Location = New System.Drawing.Point(158, 134)
        Me.pbolougaroc.Name = "pbolougaroc"
        Me.pbolougaroc.Size = New System.Drawing.Size(286, 166)
        Me.pbolougaroc.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbolougaroc.TabIndex = 36
        Me.pbolougaroc.TabStop = False
        Me.pbolougaroc.Visible = False
        '
        'pboluxray
        '
        Me.pboluxray.Image = CType(resources.GetObject("pboluxray.Image"), System.Drawing.Image)
        Me.pboluxray.Location = New System.Drawing.Point(158, 134)
        Me.pboluxray.Name = "pboluxray"
        Me.pboluxray.Size = New System.Drawing.Size(286, 166)
        Me.pboluxray.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pboluxray.TabIndex = 37
        Me.pboluxray.TabStop = False
        Me.pboluxray.Visible = False
        '
        'pbomelmetal
        '
        Me.pbomelmetal.Image = CType(resources.GetObject("pbomelmetal.Image"), System.Drawing.Image)
        Me.pbomelmetal.Location = New System.Drawing.Point(158, 134)
        Me.pbomelmetal.Name = "pbomelmetal"
        Me.pbomelmetal.Size = New System.Drawing.Size(286, 166)
        Me.pbomelmetal.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbomelmetal.TabIndex = 38
        Me.pbomelmetal.TabStop = False
        Me.pbomelmetal.Visible = False
        '
        'pbometalosse
        '
        Me.pbometalosse.Image = CType(resources.GetObject("pbometalosse.Image"), System.Drawing.Image)
        Me.pbometalosse.Location = New System.Drawing.Point(158, 134)
        Me.pbometalosse.Name = "pbometalosse"
        Me.pbometalosse.Size = New System.Drawing.Size(286, 166)
        Me.pbometalosse.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbometalosse.TabIndex = 39
        Me.pbometalosse.TabStop = False
        Me.pbometalosse.Visible = False
        '
        'pbomew
        '
        Me.pbomew.Image = CType(resources.GetObject("pbomew.Image"), System.Drawing.Image)
        Me.pbomew.Location = New System.Drawing.Point(158, 134)
        Me.pbomew.Name = "pbomew"
        Me.pbomew.Size = New System.Drawing.Size(286, 166)
        Me.pbomew.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbomew.TabIndex = 40
        Me.pbomew.TabStop = False
        Me.pbomew.Visible = False
        '
        'pbomewtwo
        '
        Me.pbomewtwo.Image = CType(resources.GetObject("pbomewtwo.Image"), System.Drawing.Image)
        Me.pbomewtwo.Location = New System.Drawing.Point(158, 134)
        Me.pbomewtwo.Name = "pbomewtwo"
        Me.pbomewtwo.Size = New System.Drawing.Size(286, 166)
        Me.pbomewtwo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbomewtwo.TabIndex = 41
        Me.pbomewtwo.TabStop = False
        Me.pbomewtwo.Visible = False
        '
        'pbomimiqui
        '
        Me.pbomimiqui.Image = CType(resources.GetObject("pbomimiqui.Image"), System.Drawing.Image)
        Me.pbomimiqui.Location = New System.Drawing.Point(158, 134)
        Me.pbomimiqui.Name = "pbomimiqui"
        Me.pbomimiqui.Size = New System.Drawing.Size(286, 166)
        Me.pbomimiqui.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbomimiqui.TabIndex = 42
        Me.pbomimiqui.TabStop = False
        Me.pbomimiqui.Visible = False
        '
        'pbopikachu
        '
        Me.pbopikachu.Image = CType(resources.GetObject("pbopikachu.Image"), System.Drawing.Image)
        Me.pbopikachu.Location = New System.Drawing.Point(158, 134)
        Me.pbopikachu.Name = "pbopikachu"
        Me.pbopikachu.Size = New System.Drawing.Size(286, 166)
        Me.pbopikachu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbopikachu.TabIndex = 43
        Me.pbopikachu.TabStop = False
        Me.pbopikachu.Visible = False
        '
        'pborayquaza
        '
        Me.pborayquaza.Image = CType(resources.GetObject("pborayquaza.Image"), System.Drawing.Image)
        Me.pborayquaza.Location = New System.Drawing.Point(158, 134)
        Me.pborayquaza.Name = "pborayquaza"
        Me.pborayquaza.Size = New System.Drawing.Size(286, 166)
        Me.pborayquaza.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pborayquaza.TabIndex = 44
        Me.pborayquaza.TabStop = False
        Me.pborayquaza.Visible = False
        '
        'pboroserade
        '
        Me.pboroserade.Image = CType(resources.GetObject("pboroserade.Image"), System.Drawing.Image)
        Me.pboroserade.Location = New System.Drawing.Point(158, 134)
        Me.pboroserade.Name = "pboroserade"
        Me.pboroserade.Size = New System.Drawing.Size(286, 166)
        Me.pboroserade.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pboroserade.TabIndex = 45
        Me.pboroserade.TabStop = False
        Me.pboroserade.Visible = False
        '
        'pbobrindibou
        '
        Me.pbobrindibou.Image = CType(resources.GetObject("pbobrindibou.Image"), System.Drawing.Image)
        Me.pbobrindibou.Location = New System.Drawing.Point(158, 134)
        Me.pbobrindibou.Name = "pbobrindibou"
        Me.pbobrindibou.Size = New System.Drawing.Size(286, 166)
        Me.pbobrindibou.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbobrindibou.TabIndex = 46
        Me.pbobrindibou.TabStop = False
        Me.pbobrindibou.Visible = False
        '
        'pbojungko
        '
        Me.pbojungko.Image = CType(resources.GetObject("pbojungko.Image"), System.Drawing.Image)
        Me.pbojungko.Location = New System.Drawing.Point(158, 134)
        Me.pbojungko.Name = "pbojungko"
        Me.pbojungko.Size = New System.Drawing.Size(286, 166)
        Me.pbojungko.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbojungko.TabIndex = 47
        Me.pbojungko.TabStop = False
        Me.pbojungko.Visible = False
        '
        'pbocizayox
        '
        Me.pbocizayox.Image = CType(resources.GetObject("pbocizayox.Image"), System.Drawing.Image)
        Me.pbocizayox.Location = New System.Drawing.Point(158, 134)
        Me.pbocizayox.Name = "pbocizayox"
        Me.pbocizayox.Size = New System.Drawing.Size(286, 166)
        Me.pbocizayox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbocizayox.TabIndex = 48
        Me.pbocizayox.TabStop = False
        Me.pbocizayox.Visible = False
        '
        'pboetouraptor
        '
        Me.pboetouraptor.Image = CType(resources.GetObject("pboetouraptor.Image"), System.Drawing.Image)
        Me.pboetouraptor.Location = New System.Drawing.Point(158, 134)
        Me.pboetouraptor.Name = "pboetouraptor"
        Me.pboetouraptor.Size = New System.Drawing.Size(286, 166)
        Me.pboetouraptor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pboetouraptor.TabIndex = 49
        Me.pboetouraptor.TabStop = False
        Me.pboetouraptor.Visible = False
        '
        'pbofrissonille
        '
        Me.pbofrissonille.Image = CType(resources.GetObject("pbofrissonille.Image"), System.Drawing.Image)
        Me.pbofrissonille.Location = New System.Drawing.Point(158, 134)
        Me.pbofrissonille.Name = "pbofrissonille"
        Me.pbofrissonille.Size = New System.Drawing.Size(286, 166)
        Me.pbofrissonille.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbofrissonille.TabIndex = 50
        Me.pbofrissonille.TabStop = False
        Me.pbofrissonille.Visible = False
        '
        'pboronflex
        '
        Me.pboronflex.Image = CType(resources.GetObject("pboronflex.Image"), System.Drawing.Image)
        Me.pboronflex.Location = New System.Drawing.Point(158, 134)
        Me.pboronflex.Name = "pboronflex"
        Me.pboronflex.Size = New System.Drawing.Size(286, 166)
        Me.pboronflex.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pboronflex.TabIndex = 51
        Me.pboronflex.TabStop = False
        Me.pboronflex.Visible = False
        '
        'pbonymphalli
        '
        Me.pbonymphalli.Image = CType(resources.GetObject("pbonymphalli.Image"), System.Drawing.Image)
        Me.pbonymphalli.Location = New System.Drawing.Point(158, 134)
        Me.pbonymphalli.Name = "pbonymphalli"
        Me.pbonymphalli.Size = New System.Drawing.Size(286, 166)
        Me.pbonymphalli.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbonymphalli.TabIndex = 52
        Me.pbonymphalli.TabStop = False
        Me.pbonymphalli.Visible = False
        '
        'pboflambusard
        '
        Me.pboflambusard.Image = CType(resources.GetObject("pboflambusard.Image"), System.Drawing.Image)
        Me.pboflambusard.Location = New System.Drawing.Point(158, 134)
        Me.pboflambusard.Name = "pboflambusard"
        Me.pboflambusard.Size = New System.Drawing.Size(286, 166)
        Me.pboflambusard.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pboflambusard.TabIndex = 53
        Me.pboflambusard.TabStop = False
        Me.pboflambusard.Visible = False
        '
        'pbotogekiss
        '
        Me.pbotogekiss.Image = CType(resources.GetObject("pbotogekiss.Image"), System.Drawing.Image)
        Me.pbotogekiss.Location = New System.Drawing.Point(158, 134)
        Me.pbotogekiss.Name = "pbotogekiss"
        Me.pbotogekiss.Size = New System.Drawing.Size(286, 166)
        Me.pbotogekiss.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbotogekiss.TabIndex = 54
        Me.pbotogekiss.TabStop = False
        Me.pbotogekiss.Visible = False
        '
        'pbosalarsen
        '
        Me.pbosalarsen.Image = CType(resources.GetObject("pbosalarsen.Image"), System.Drawing.Image)
        Me.pbosalarsen.Location = New System.Drawing.Point(158, 134)
        Me.pbosalarsen.Name = "pbosalarsen"
        Me.pbosalarsen.Size = New System.Drawing.Size(286, 166)
        Me.pbosalarsen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbosalarsen.TabIndex = 55
        Me.pbosalarsen.TabStop = False
        Me.pbosalarsen.Visible = False
        '
        'pbotyranocif
        '
        Me.pbotyranocif.Image = CType(resources.GetObject("pbotyranocif.Image"), System.Drawing.Image)
        Me.pbotyranocif.Location = New System.Drawing.Point(158, 134)
        Me.pbotyranocif.Name = "pbotyranocif"
        Me.pbotyranocif.Size = New System.Drawing.Size(286, 166)
        Me.pbotyranocif.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbotyranocif.TabIndex = 56
        Me.pbotyranocif.TabStop = False
        Me.pbotyranocif.Visible = False
        '
        'pbonoctali
        '
        Me.pbonoctali.Image = CType(resources.GetObject("pbonoctali.Image"), System.Drawing.Image)
        Me.pbonoctali.Location = New System.Drawing.Point(158, 134)
        Me.pbonoctali.Name = "pbonoctali"
        Me.pbonoctali.Size = New System.Drawing.Size(286, 166)
        Me.pbonoctali.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbonoctali.TabIndex = 58
        Me.pbonoctali.TabStop = False
        Me.pbonoctali.Visible = False
        '
        'pbozoroark
        '
        Me.pbozoroark.Image = CType(resources.GetObject("pbozoroark.Image"), System.Drawing.Image)
        Me.pbozoroark.Location = New System.Drawing.Point(158, 134)
        Me.pbozoroark.Name = "pbozoroark"
        Me.pbozoroark.Size = New System.Drawing.Size(286, 166)
        Me.pbozoroark.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbozoroark.TabIndex = 59
        Me.pbozoroark.TabStop = False
        Me.pbozoroark.Visible = False
        '
        'pbozeraora
        '
        Me.pbozeraora.Image = CType(resources.GetObject("pbozeraora.Image"), System.Drawing.Image)
        Me.pbozeraora.Location = New System.Drawing.Point(158, 134)
        Me.pbozeraora.Name = "pbozeraora"
        Me.pbozeraora.Size = New System.Drawing.Size(286, 166)
        Me.pbozeraora.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbozeraora.TabIndex = 60
        Me.pbozeraora.TabStop = False
        Me.pbozeraora.Visible = False
        '
        'pbodimoret
        '
        Me.pbodimoret.Image = CType(resources.GetObject("pbodimoret.Image"), System.Drawing.Image)
        Me.pbodimoret.Location = New System.Drawing.Point(158, 134)
        Me.pbodimoret.Name = "pbodimoret"
        Me.pbodimoret.Size = New System.Drawing.Size(286, 166)
        Me.pbodimoret.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbodimoret.TabIndex = 61
        Me.pbodimoret.TabStop = False
        Me.pbodimoret.Visible = False
        '
        'pbopyrax
        '
        Me.pbopyrax.Image = CType(resources.GetObject("pbopyrax.Image"), System.Drawing.Image)
        Me.pbopyrax.Location = New System.Drawing.Point(158, 134)
        Me.pbopyrax.Name = "pbopyrax"
        Me.pbopyrax.Size = New System.Drawing.Size(286, 166)
        Me.pbopyrax.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbopyrax.TabIndex = 62
        Me.pbopyrax.TabStop = False
        Me.pbopyrax.Visible = False
        '
        'pbolucanon
        '
        Me.pbolucanon.Image = CType(resources.GetObject("pbolucanon.Image"), System.Drawing.Image)
        Me.pbolucanon.Location = New System.Drawing.Point(158, 134)
        Me.pbolucanon.Name = "pbolucanon"
        Me.pbolucanon.Size = New System.Drawing.Size(286, 166)
        Me.pbolucanon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbolucanon.TabIndex = 63
        Me.pbolucanon.TabStop = False
        Me.pbolucanon.Visible = False
        '
        'frmpoknames
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(605, 406)
        Me.Controls.Add(Me.pbolucanon)
        Me.Controls.Add(Me.pbopyrax)
        Me.Controls.Add(Me.pbodimoret)
        Me.Controls.Add(Me.pbozeraora)
        Me.Controls.Add(Me.pbozoroark)
        Me.Controls.Add(Me.pbonoctali)
        Me.Controls.Add(Me.pbotyranocif)
        Me.Controls.Add(Me.pbosalarsen)
        Me.Controls.Add(Me.pbotogekiss)
        Me.Controls.Add(Me.pboflambusard)
        Me.Controls.Add(Me.pbonymphalli)
        Me.Controls.Add(Me.pboronflex)
        Me.Controls.Add(Me.pbofrissonille)
        Me.Controls.Add(Me.pboetouraptor)
        Me.Controls.Add(Me.pbocizayox)
        Me.Controls.Add(Me.pbojungko)
        Me.Controls.Add(Me.pbobrindibou)
        Me.Controls.Add(Me.pboroserade)
        Me.Controls.Add(Me.pborayquaza)
        Me.Controls.Add(Me.pbopikachu)
        Me.Controls.Add(Me.pbomimiqui)
        Me.Controls.Add(Me.pbomewtwo)
        Me.Controls.Add(Me.pbomew)
        Me.Controls.Add(Me.pbometalosse)
        Me.Controls.Add(Me.pbomelmetal)
        Me.Controls.Add(Me.pboluxray)
        Me.Controls.Add(Me.pbolougaroc)
        Me.Controls.Add(Me.pbolugia)
        Me.Controls.Add(Me.pbolucario)
        Me.Controls.Add(Me.pbointro)
        Me.Controls.Add(Me.lblsurpris)
        Me.Controls.Add(Me.lbljackbot)
        Me.Controls.Add(Me.lblresult)
        Me.Controls.Add(Me.lbltest)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lbofrenchpok)
        Me.Controls.Add(Me.lboenglish)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnintro)
        Me.Controls.Add(Me.pbosarmurai)
        Me.Controls.Add(Me.pboamphinobi)
        Me.Controls.Add(Me.pbotrioxhydre)
        Me.Controls.Add(Me.pbocharchacroc)
        Me.Controls.Add(Me.pboectoplasma)
        Me.Controls.Add(Me.pboscorvol)
        Me.Controls.Add(Me.pbominotaupe)
        Me.Controls.Add(Me.pbolibegon)
        Me.Controls.Add(Me.pbogardevoir)
        Me.Controls.Add(Me.pboevoli)
        Me.Controls.Add(Me.pbodracolosse)
        Me.Controls.Add(Me.pbolanssorien)
        Me.Controls.Add(Me.pboarcheduc)
        Me.Controls.Add(Me.pbocorvaillus)
        Me.Controls.Add(Me.pbodracaufeu)
        Me.Controls.Add(Me.pbolugularbre)
        Me.Controls.Add(Me.pboBulbizarre)
        Me.Controls.Add(Me.pboblaze)
        Me.Controls.Add(Me.pboaegislash)
        Me.Controls.Add(Me.pbosimiabraz)
        Me.Controls.Add(Me.pbocrocorible)
        Me.Name = "frmpoknames"
        Me.Text = "French Pokemon Names by Nevin Ndonwi"
        CType(Me.pboaegislash, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pboblaze, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pboBulbizarre, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbolugularbre, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbodracaufeu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbocorvaillus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pboarcheduc, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbolanssorien, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbodracolosse, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pboevoli, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbogardevoir, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbolibegon, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbominotaupe, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pboscorvol, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pboectoplasma, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbocharchacroc, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbocrocorible, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbosimiabraz, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbotrioxhydre, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pboamphinobi, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbosarmurai, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbointro, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbolucario, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbolugia, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbolougaroc, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pboluxray, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbomelmetal, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbometalosse, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbomew, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbomewtwo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbomimiqui, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbopikachu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pborayquaza, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pboroserade, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbobrindibou, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbojungko, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbocizayox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pboetouraptor, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbofrissonille, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pboronflex, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbonymphalli, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pboflambusard, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbotogekiss, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbosalarsen, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbotyranocif, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbonoctali, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbozoroark, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbozeraora, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbodimoret, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbopyrax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbolucanon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnintro As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents lboenglish As ListBox
    Friend WithEvents lbofrenchpok As ListBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lbltest As Label
    Friend WithEvents lblresult As Label
    Friend WithEvents pboaegislash As PictureBox
    Friend WithEvents lbljackbot As Label
    Friend WithEvents lblsurpris As Label
    Friend WithEvents pboblaze As PictureBox
    Friend WithEvents pboBulbizarre As PictureBox
    Friend WithEvents pbolugularbre As PictureBox
    Friend WithEvents pbodracaufeu As PictureBox
    Friend WithEvents pbocorvaillus As PictureBox
    Friend WithEvents pboarcheduc As PictureBox
    Friend WithEvents pbolanssorien As PictureBox
    Friend WithEvents pbodracolosse As PictureBox
    Friend WithEvents pboevoli As PictureBox
    Friend WithEvents pbogardevoir As PictureBox
    Friend WithEvents pbolibegon As PictureBox
    Friend WithEvents pbominotaupe As PictureBox
    Friend WithEvents pboscorvol As PictureBox
    Friend WithEvents pboectoplasma As PictureBox
    Friend WithEvents pbocharchacroc As PictureBox
    Friend WithEvents pbocrocorible As PictureBox
    Friend WithEvents pbosimiabraz As PictureBox
    Friend WithEvents pbotrioxhydre As PictureBox
    Friend WithEvents pboamphinobi As PictureBox
    Friend WithEvents pbosarmurai As PictureBox
    Friend WithEvents pbointro As PictureBox
    Friend WithEvents pbolucario As PictureBox
    Friend WithEvents pbolugia As PictureBox
    Friend WithEvents pbolougaroc As PictureBox
    Friend WithEvents pboluxray As PictureBox
    Friend WithEvents pbomelmetal As PictureBox
    Friend WithEvents pbometalosse As PictureBox
    Friend WithEvents pbomew As PictureBox
    Friend WithEvents pbomewtwo As PictureBox
    Friend WithEvents pbomimiqui As PictureBox
    Friend WithEvents pbopikachu As PictureBox
    Friend WithEvents pborayquaza As PictureBox
    Friend WithEvents pboroserade As PictureBox
    Friend WithEvents pbobrindibou As PictureBox
    Friend WithEvents pbojungko As PictureBox
    Friend WithEvents pbocizayox As PictureBox
    Friend WithEvents pboetouraptor As PictureBox
    Friend WithEvents pbofrissonille As PictureBox
    Friend WithEvents pboronflex As PictureBox
    Friend WithEvents pbonymphalli As PictureBox
    Friend WithEvents pboflambusard As PictureBox
    Friend WithEvents pbotogekiss As PictureBox
    Friend WithEvents pbosalarsen As PictureBox
    Friend WithEvents pbotyranocif As PictureBox
    Friend WithEvents pbonoctali As PictureBox
    Friend WithEvents pbozoroark As PictureBox
    Friend WithEvents pbozeraora As PictureBox
    Friend WithEvents pbodimoret As PictureBox
    Friend WithEvents pbopyrax As PictureBox
    Friend WithEvents pbolucanon As PictureBox
End Class
