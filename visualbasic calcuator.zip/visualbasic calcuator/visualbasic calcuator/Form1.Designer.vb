﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmmain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn0 = New System.Windows.Forms.Button()
        Me.btn9 = New System.Windows.Forms.Button()
        Me.btn6 = New System.Windows.Forms.Button()
        Me.btn7 = New System.Windows.Forms.Button()
        Me.btn8 = New System.Windows.Forms.Button()
        Me.btn3 = New System.Windows.Forms.Button()
        Me.btn2 = New System.Windows.Forms.Button()
        Me.btn5 = New System.Windows.Forms.Button()
        Me.btn4 = New System.Windows.Forms.Button()
        Me.btn1 = New System.Windows.Forms.Button()
        Me.btnequal = New System.Windows.Forms.Button()
        Me.btnmultiply = New System.Windows.Forms.Button()
        Me.btndivide = New System.Windows.Forms.Button()
        Me.btnadd = New System.Windows.Forms.Button()
        Me.btnsubtract = New System.Windows.Forms.Button()
        Me.txtnumberinput = New System.Windows.Forms.TextBox()
        Me.btnpoint = New System.Windows.Forms.Button()
        Me.btnclear = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btn0
        '
        Me.btn0.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btn0.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn0.Location = New System.Drawing.Point(12, 327)
        Me.btn0.Name = "btn0"
        Me.btn0.Size = New System.Drawing.Size(107, 65)
        Me.btn0.TabIndex = 0
        Me.btn0.Text = "0"
        Me.btn0.UseVisualStyleBackColor = False
        '
        'btn9
        '
        Me.btn9.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btn9.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn9.Location = New System.Drawing.Point(238, 105)
        Me.btn9.Name = "btn9"
        Me.btn9.Size = New System.Drawing.Size(107, 65)
        Me.btn9.TabIndex = 1
        Me.btn9.Text = "9"
        Me.btn9.UseVisualStyleBackColor = False
        '
        'btn6
        '
        Me.btn6.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btn6.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn6.Location = New System.Drawing.Point(238, 176)
        Me.btn6.Name = "btn6"
        Me.btn6.Size = New System.Drawing.Size(107, 65)
        Me.btn6.TabIndex = 2
        Me.btn6.Text = "6"
        Me.btn6.UseVisualStyleBackColor = False
        '
        'btn7
        '
        Me.btn7.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btn7.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn7.Location = New System.Drawing.Point(12, 105)
        Me.btn7.Name = "btn7"
        Me.btn7.Size = New System.Drawing.Size(107, 65)
        Me.btn7.TabIndex = 3
        Me.btn7.Text = "7"
        Me.btn7.UseVisualStyleBackColor = False
        '
        'btn8
        '
        Me.btn8.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btn8.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn8.Location = New System.Drawing.Point(125, 105)
        Me.btn8.Name = "btn8"
        Me.btn8.Size = New System.Drawing.Size(107, 65)
        Me.btn8.TabIndex = 4
        Me.btn8.Text = "8"
        Me.btn8.UseVisualStyleBackColor = False
        '
        'btn3
        '
        Me.btn3.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btn3.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn3.Location = New System.Drawing.Point(238, 247)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(107, 65)
        Me.btn3.TabIndex = 5
        Me.btn3.Text = "3"
        Me.btn3.UseVisualStyleBackColor = False
        '
        'btn2
        '
        Me.btn2.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btn2.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn2.Location = New System.Drawing.Point(125, 247)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(107, 65)
        Me.btn2.TabIndex = 6
        Me.btn2.Text = "2"
        Me.btn2.UseVisualStyleBackColor = False
        '
        'btn5
        '
        Me.btn5.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btn5.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn5.Location = New System.Drawing.Point(125, 176)
        Me.btn5.Name = "btn5"
        Me.btn5.Size = New System.Drawing.Size(107, 65)
        Me.btn5.TabIndex = 7
        Me.btn5.Text = "5"
        Me.btn5.UseVisualStyleBackColor = False
        '
        'btn4
        '
        Me.btn4.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btn4.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn4.Location = New System.Drawing.Point(12, 176)
        Me.btn4.Name = "btn4"
        Me.btn4.Size = New System.Drawing.Size(107, 65)
        Me.btn4.TabIndex = 8
        Me.btn4.Text = "4"
        Me.btn4.UseVisualStyleBackColor = False
        '
        'btn1
        '
        Me.btn1.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btn1.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn1.Location = New System.Drawing.Point(12, 247)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(107, 65)
        Me.btn1.TabIndex = 9
        Me.btn1.Text = "1"
        Me.btn1.UseVisualStyleBackColor = False
        '
        'btnequal
        '
        Me.btnequal.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnequal.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnequal.Location = New System.Drawing.Point(238, 327)
        Me.btnequal.Name = "btnequal"
        Me.btnequal.Size = New System.Drawing.Size(107, 65)
        Me.btnequal.TabIndex = 10
        Me.btnequal.Text = "="
        Me.btnequal.UseVisualStyleBackColor = False
        '
        'btnmultiply
        '
        Me.btnmultiply.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnmultiply.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnmultiply.Location = New System.Drawing.Point(351, 327)
        Me.btnmultiply.Name = "btnmultiply"
        Me.btnmultiply.Size = New System.Drawing.Size(107, 65)
        Me.btnmultiply.TabIndex = 14
        Me.btnmultiply.Text = "x"
        Me.btnmultiply.UseVisualStyleBackColor = False
        '
        'btndivide
        '
        Me.btndivide.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btndivide.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndivide.Location = New System.Drawing.Point(351, 247)
        Me.btndivide.Name = "btndivide"
        Me.btndivide.Size = New System.Drawing.Size(107, 65)
        Me.btndivide.TabIndex = 13
        Me.btndivide.Text = "/"
        Me.btndivide.UseVisualStyleBackColor = False
        '
        'btnadd
        '
        Me.btnadd.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnadd.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnadd.Location = New System.Drawing.Point(351, 176)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(107, 65)
        Me.btnadd.TabIndex = 12
        Me.btnadd.Text = "+"
        Me.btnadd.UseVisualStyleBackColor = False
        '
        'btnsubtract
        '
        Me.btnsubtract.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnsubtract.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsubtract.Location = New System.Drawing.Point(351, 105)
        Me.btnsubtract.Name = "btnsubtract"
        Me.btnsubtract.Size = New System.Drawing.Size(107, 65)
        Me.btnsubtract.TabIndex = 11
        Me.btnsubtract.Text = "-"
        Me.btnsubtract.UseVisualStyleBackColor = False
        '
        'txtnumberinput
        '
        Me.txtnumberinput.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtnumberinput.Location = New System.Drawing.Point(164, 19)
        Me.txtnumberinput.Name = "txtnumberinput"
        Me.txtnumberinput.Size = New System.Drawing.Size(294, 80)
        Me.txtnumberinput.TabIndex = 15
        '
        'btnpoint
        '
        Me.btnpoint.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnpoint.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpoint.Location = New System.Drawing.Point(125, 327)
        Me.btnpoint.Name = "btnpoint"
        Me.btnpoint.Size = New System.Drawing.Size(107, 65)
        Me.btnpoint.TabIndex = 16
        Me.btnpoint.Text = "."
        Me.btnpoint.UseVisualStyleBackColor = False
        '
        'btnclear
        '
        Me.btnclear.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnclear.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnclear.Location = New System.Drawing.Point(12, 34)
        Me.btnclear.Name = "btnclear"
        Me.btnclear.Size = New System.Drawing.Size(107, 65)
        Me.btnclear.TabIndex = 17
        Me.btnclear.Text = "&clear"
        Me.btnclear.UseVisualStyleBackColor = False
        '
        'frmmain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ClientSize = New System.Drawing.Size(469, 404)
        Me.Controls.Add(Me.btnclear)
        Me.Controls.Add(Me.btnpoint)
        Me.Controls.Add(Me.btnmultiply)
        Me.Controls.Add(Me.btndivide)
        Me.Controls.Add(Me.btnadd)
        Me.Controls.Add(Me.btnsubtract)
        Me.Controls.Add(Me.btnequal)
        Me.Controls.Add(Me.btn1)
        Me.Controls.Add(Me.btn4)
        Me.Controls.Add(Me.btn5)
        Me.Controls.Add(Me.btn2)
        Me.Controls.Add(Me.btn3)
        Me.Controls.Add(Me.btn8)
        Me.Controls.Add(Me.btn7)
        Me.Controls.Add(Me.btn6)
        Me.Controls.Add(Me.btn9)
        Me.Controls.Add(Me.btn0)
        Me.Controls.Add(Me.txtnumberinput)
        Me.Name = "frmmain"
        Me.Text = "Visual Basic Calculator (Design semi-based on Iphone)"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn0 As Button
    Friend WithEvents btn9 As Button
    Friend WithEvents btn6 As Button
    Friend WithEvents btn7 As Button
    Friend WithEvents btn8 As Button
    Friend WithEvents btn3 As Button
    Friend WithEvents btn2 As Button
    Friend WithEvents btn5 As Button
    Friend WithEvents btn4 As Button
    Friend WithEvents btn1 As Button
    Friend WithEvents btnequal As Button
    Friend WithEvents btnmultiply As Button
    Friend WithEvents btndivide As Button
    Friend WithEvents btnadd As Button
    Friend WithEvents btnsubtract As Button
    Friend WithEvents txtnumberinput As TextBox
    Friend WithEvents btnpoint As Button
    Friend WithEvents btnclear As Button
End Class
