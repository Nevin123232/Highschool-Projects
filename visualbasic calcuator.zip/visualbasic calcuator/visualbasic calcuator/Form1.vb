﻿Public Class frmmain
    'Calculator project by Nevin Ndonwi (based on iphone design)

    'This calculator is able to do simple calculations between 2 numbers 

    'these are the 2 numbers that will be used to do the math based on the input of the user

    Dim num1 As Double  'first input of user
    Dim num2 As Double   ' second numerical user input
    Dim operation As String ' operation used to get result    s- subtract, m- multiply, d - divide, a - add
    Dim result As Double ' result
    Private Sub frmmain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        btnadd.BackColor = Color.Orange
        btnsubtract.BackColor = Color.Orange
        btndivide.BackColor = Color.Orange
        btnmultiply.BackColor = Color.Orange

    End Sub

    'clear button

    Private Sub btnclear_Click(sender As Object, e As EventArgs) Handles btnclear.Click
        num1 = 0
        num2 = 0
        txtnumberinput.Text = String.Empty

    End Sub

    'gets the text of the buttons on the textbox

    Private Sub btn0_Click(sender As Object, e As EventArgs) Handles btn0.Click
        txtnumberinput.Text += btn0.Text
    End Sub

    Private Sub btn1_Click(sender As Object, e As EventArgs) Handles btn1.Click
        txtnumberinput.Text += btn1.Text
    End Sub

    Private Sub btn2_Click(sender As Object, e As EventArgs) Handles btn2.Click
        txtnumberinput.Text += btn2.Text
    End Sub

    Private Sub btn3_Click(sender As Object, e As EventArgs) Handles btn3.Click
        txtnumberinput.Text += btn3.Text
    End Sub

    Private Sub btn4_Click(sender As Object, e As EventArgs) Handles btn4.Click
        txtnumberinput.Text += btn4.Text
    End Sub

    Private Sub btn5_Click(sender As Object, e As EventArgs) Handles btn5.Click
        txtnumberinput.Text += btn5.Text
    End Sub

    Private Sub btn6_Click(sender As Object, e As EventArgs) Handles btn6.Click
        txtnumberinput.Text += btn6.Text
    End Sub

    Private Sub btn7_Click(sender As Object, e As EventArgs) Handles btn7.Click
        txtnumberinput.Text += btn7.Text
    End Sub

    Private Sub btn8_Click(sender As Object, e As EventArgs) Handles btn8.Click
        txtnumberinput.Text += btn8.Text
    End Sub

    Private Sub btn9_Click(sender As Object, e As EventArgs) Handles btn9.Click
        txtnumberinput.Text += btn9.Text
    End Sub

    Private Sub btnpoint_Click(sender As Object, e As EventArgs) Handles btnpoint.Click
        txtnumberinput.Text += btnpoint.Text
    End Sub

    Private Sub btnsubtract_Click(sender As Object, e As EventArgs) Handles btnsubtract.Click
        operation = "s"
        Double.TryParse(txtnumberinput.Text, num1)
        txtnumberinput.Text = String.Empty

    End Sub

    Private Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnadd.Click
        operation = "a"
        Double.TryParse(txtnumberinput.Text, num1)
        txtnumberinput.Text = String.Empty

    End Sub

    Private Sub btndivide_Click(sender As Object, e As EventArgs) Handles btndivide.Click

        operation = "d"
        Double.TryParse(txtnumberinput.Text, num1)
        txtnumberinput.Text = String.Empty

    End Sub

    Private Sub btnmultiply_Click(sender As Object, e As EventArgs) Handles btnmultiply.Click
        operation = "m"
        Double.TryParse(txtnumberinput.Text, num1)
        txtnumberinput.Text = String.Empty

    End Sub

    Private Sub btnequal_Click(sender As Object, e As EventArgs) Handles btnequal.Click

        Double.TryParse(txtnumberinput.Text, num2)

        If operation = "a" Then
            result = num1 + num2

        End If

        If operation = "m" Then

            result = num1 * num2
        End If

        If operation = "s" Then

            result = num1 - num2
        End If

        If operation = "d" Then

            result = num1 / num2
        End If



        txtnumberinput.Text = result.ToString


    End Sub
End Class
