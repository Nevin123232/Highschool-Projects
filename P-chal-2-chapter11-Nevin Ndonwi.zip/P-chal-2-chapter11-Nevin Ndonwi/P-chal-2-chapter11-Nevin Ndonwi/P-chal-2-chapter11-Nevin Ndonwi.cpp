// C++ program to check if an Array
// is Palindrome or not using STL

#include <iostream>
using namespace std;

void palindrome(string input, int s)
{
    // Initialise flag to zero.
    int flag = 0;

    string input2 = "";

    //initialize a string and make it a reversed version of the input

    for (int x = input.length(); x > 0; x--) {

        input2 += input[x - 1];



    }


    // Check if the array is Palindrome
    for (int i = 0; i < input.length(); i++)
        if (input[i] != input2[i]) {
            flag = 1;
            break;
        }

    // Print the result
    if (flag == 0)
        cout << "Palindrome\n";
    else
        cout << "Not Palindrome\n";
}

int main()
{
    // Get the string
    string input = "";
    cout << "Input a string:\n";
    cin >> input;


    // Compute the size
    int size = input.length();

    palindrome(input, size);

    return 0;

    system("pause");
}