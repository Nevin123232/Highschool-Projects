#BinDecConv control program for binary-decimal conversion
from Dec2Bin import Dec2Bin
from Bin2Dec import Bin2Dec

def main():
    print("Welcome to the Binary-Decimal Converter\n")

    choice = getChoice()

    while choice != 0:
        if choice == 1:
            #Decimal to Binary Conversion
         
            val = str(input("Enter your decimal value: \n"))
            d2b = Dec2Bin(val)

            if d2b.isValid():
                #Display results of conversion

                #display steps
                for x in d2b.getResultSteps():
                    print(x)

                #display answer
                print("\nTherefore the decimal value" , d2b.getDecimal(), "converted to binary is", d2b.getResult() )


            else:
                print("Conversion error", d2b.getErrorMsg(), "\n" )


        elif choice == 2:
             #Binary to Decimal Conversion
         
            val = str(input("Enter your binary value: \n"))
            b2d = Bin2Dec(val)

            if b2d.isValid():
                #Display results of conversion

                #display steps
                for x in b2d.getResultSteps():
                    print(x)

                #display answer
                print("\nTherefore the binary value" , b2d.getBinary(), "converted to decimal is", b2d.getResult() )


            else:
                print("Conversion error", b2d.getErrorMsg(), "\n" )



        else:
            print("Unknown Conversion Type")

        choice = getChoice()

    print("Thank you for using this converter.\n")
    




def getChoice():
    goodVal = False 
    while not goodVal:
        try:
            choice = int(input("1 = Decimal - Binary, 2 = Binary - Decimal, 0 = quit\n"))
            if choice < 0 or choice > 2:
                print("Unknown Operation: input 1,2,0 only.\n")
            else:
                goodVal = True
        except ValueError:
            print("Illegal input: integers 0,1,2 only\n")
            goodVal = False
    return choice 
 
    





if __name__ == "__main__":
    main()