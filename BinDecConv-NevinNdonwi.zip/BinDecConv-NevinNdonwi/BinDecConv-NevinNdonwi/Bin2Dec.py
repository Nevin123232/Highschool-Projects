from math import pow

class Bin2Dec:
    """Decimal to Binary Converter"""
    
    def __init__(self,binval):
        self.setBinary(binval)
        self._error = ""
        self._result = "" 
        if self.isValid():
            self._steps = []
            self.Convert()
         
       

    def Convert(self):
        
       
        newval = ""
        r = 0

        for x in range(0,len(self._binary)):
            if self._binary[x] == "1":
                val = int(pow(2, len(self._binary) -x-1 ))
                newval = "{:12}".format(val)
                self._steps.insert(0, "There is a " + newval + " (2^" + str(len(self._binary) -x-1 ) + ") in the value. ")
                r = r + val

        self._result = str(int(r))

            


    def setBinary(self,val): #still a string
        self._binary = val

    def getBinary(self):
        return self._binary
   

    def getResult(self):
        return self._result


    def getResultSteps(self):
        return self._steps

    def getErrorMsg(self):
        return self._error


    def isValid(self):
   
        wrong = 0

        #goes through user's input to check if there are only 1s and 0s
        for x in self._binary:
            if x != "0" and  x != "1":
                #increases the amoung of wrong inputs by 1
                wrong += 1 

        #if there are any wrong characters then it returns false
        if wrong > 0:
            self._error = "There should only be 0s and 1s in the input"
            return False

         #if there are no wrong characters then it returns true
        else:
            return True
                


        
        

