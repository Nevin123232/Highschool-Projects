

class Dec2Bin:
    """Decimal to Binary Converter"""
    
    def __init__(self,decval):
        self.setDecimal(decval)
        self._error = ""
        self._result = "" 
        if self.isValid():
            self._steps = []
            self.ConvertByRecursion( self._decval) #parameter becomes local in method 
       #     self.ConvertToBinary()   #regular loop for conversion steps
       

    def ConvertByRecursion(self, val):
        #val is the current value after devisions by 2
        r = val %2
        newval = val //2
        x = "{:12}".format(val)
        y = "{:12}".format(newval)
        self._steps.append( x + " divided by 2 = " + str(y) + " with a remainder of: " + str(r))
       
        #recursive call (If final condition has not been reached )
        if newval > 0:
            self.ConvertByRecursion(newval)

        self._result += str(r)







    def setDecimal(self,val): #still a string
        self._decimal = val

    def getDecimal(self):
        return self._decimal
   

    def getResult(self):
        return self._result


    def getResultSteps(self):
        return self._steps

    def getErrorMsg(self):
        return self._error


    def isValid(self):
        valid = True
        try:
            self._decval = int(self._decimal)
            if self._decval <= 0:
                self._error = "Decimal value must be a positive integer"
                valid = False
           
        except Exception:
            self._error = "Value is not an integer."
            valid = False
        
        return valid

"""
    def ConvertToBinary(self):
        #conversion using simple loop - not recursion 
        print("Converting to Binary")
        wrkval = self._decval #copy of integer form of value 
        while wrkval > 0:
            remainder = wrkval %2
            newval = wrkval //2  #integer devision
            #create step for this iteration.....
            x = "{:12}".format(wrkval)
            y = "{:12}".format(newval)
            self._steps.append(x + " divided by 2 = " + str(y) + " with a remainder of: " + str(remainder))



            #build result 
            self._result = str(remainder) + self._result
            

            #reset wrkval to next value after division by 2
            wrkval = newval

"""
     